import type { AppContext, WorkerEnv } from "../../types";
import { AppError } from "../../middleware/error";
import { fetchWithHttpDebugLog } from "../../httpDebugLog";
import {
	ComflyCreateCharacterResponseSchema,
	SoraVideoDraftResponseSchema,
} from "./sora.schemas";
import { resolveVendorContext } from "../task/task.service";
import { resolvePublicAssetBaseUrl } from "../asset/asset.publicBase";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import {
	createRustfsClient,
	resolveRustfsConfig,
} from "../asset/rustfs.client";
import {
	searchSavedSoraCharacters,
	upsertSavedSoraCharacter,
} from "./sora.saved-characters.repo";
import { upsertVendorTaskRef } from "../task/vendor-task-refs.repo";
import {
	bindTeamCreditsReservationToTaskId,
	requireSufficientTeamCredits,
	releaseTeamCreditsOnFailure,
	settleTeamCreditsOnSuccess,
} from "../team/team.service";
import { resolveTeamCreditsCostForTask } from "../billing/billing.service";
import { hostTaskAssetsInWorker } from "../asset/asset.hosting";

function normalizeBaseUrl(raw: string | null | undefined): string {
	const val = (raw || "").trim();
	if (!val) return "";
	return val.replace(/\/+$/, "");
}

function isGrsaiBaseUrl(url: string): boolean {
	const val = url.toLowerCase();
	// New Sora2API/GRSAI protocol uses chat/completions for character/image.
	// Treat sora2api domain as new protocol base as well.
	return val.includes("grsai") || val.includes("sora2api");
}

type SoraToken = {
	id: string;
	label: string;
	secretToken: string;
	userAgent: string | null;
	shared: boolean;
	providerVendor: string;
	providerBaseUrl: string | null;
};

async function listSoraTokens(
	c: AppContext,
	userId: string,
	vendor: string,
): Promise<SoraToken[]> {
	const sql = `
    SELECT
      t.id,
      t.label,
      t.secret_token as secretToken,
      t.user_agent as userAgent,
      t.shared as shared,
      p.vendor as providerVendor,
      p.base_url as providerBaseUrl
    FROM model_tokens t
    JOIN model_providers p ON p.id = t.provider_id
    WHERE t.enabled = 1
      AND p.vendor = ?
      AND (t.user_id = ? OR t.shared = 1)
    ORDER BY t.created_at ASC
  `;

	const { results } = await c.env.DB.prepare(sql)
		.bind(vendor, userId)
		.all<SoraToken>();
	return results ?? [];
}

async function resolveSoraToken(
	c: AppContext,
	userId: string,
	tokenId?: string | null,
): Promise<SoraToken> {
	const vendor = "sora";
	if (tokenId) {
		const sql = `
      SELECT
        t.id,
        t.label,
        t.secret_token as secretToken,
        t.user_agent as userAgent,
        t.shared as shared,
        p.vendor as providerVendor,
        p.base_url as providerBaseUrl
      FROM model_tokens t
      JOIN model_providers p ON p.id = t.provider_id
      WHERE t.id = ?
        AND t.enabled = 1
        AND p.vendor = ?
        AND (t.user_id = ? OR t.shared = 1)
      LIMIT 1
    `;
		const row = await c.env.DB.prepare(sql)
			.bind(tokenId, vendor, userId)
			.first<SoraToken>();
		if (row) return row;
	}

	const tokens = await listSoraTokens(c, userId, vendor);
	if (!tokens.length) {
		throw new AppError("未找到可用的 Sora Token", {
			status: 400,
			code: "sora_token_missing",
		});
	}
	return tokens[0];
}

// 尝试解析 Sora2API Token（model_providers.vendor = 'sora2api'）
async function resolveSora2ApiToken(
	c: AppContext,
	userId: string,
	tokenId?: string | null,
): Promise<SoraToken> {
	const vendor = "sora2api";
	if (tokenId) {
		const sql = `
      SELECT
        t.id,
        t.label,
        t.secret_token as secretToken,
        t.user_agent as userAgent,
        t.shared as shared,
        p.vendor as providerVendor,
        p.base_url as providerBaseUrl
      FROM model_tokens t
      JOIN model_providers p ON p.id = t.provider_id
      WHERE t.id = ?
        AND t.enabled = 1
        AND p.vendor = ?
        AND (t.user_id = ? OR t.shared = 1)
      LIMIT 1
    `;
		const row = await c.env.DB.prepare(sql)
			.bind(tokenId, vendor, userId)
			.first<SoraToken>();
		if (row) return row;
	}

	const tokens = await listSoraTokens(c, userId, vendor);
	if (!tokens.length) {
		throw new AppError("未找到可用的 Sora2API Token", {
			status: 400,
			code: "sora_token_missing",
		});
	}
	return tokens[0];
}

function getDefaultSoraBase(env: WorkerEnv, vendor?: string | null): string {
	const v = (vendor || "").toLowerCase();
	if (v === "sora2api") {
		const envVal =
			env.SORA2API_BASE_URL ||
			// 兼容早期自定义绑定名称
			((env as any).SORA2API_BASE as string | undefined) ||
			"http://localhost:8000";
		return String(envVal).trim();
	}
	return "https://sora.chatgpt.com";
}

function buildSoraBaseUrl(env: WorkerEnv, token: SoraToken): string {
	return (token.providerBaseUrl ||
		getDefaultSoraBase(env, token.providerVendor)).replace(
		/\/+$/,
		"",
	);
}

function decodeJwtPayload(token: string): any | null {
	const parts = token.split(".");
	if (parts.length < 2) return null;
	const payloadSeg = parts[1];
	try {
		let base64 = payloadSeg.replace(/-/g, "+").replace(/_/g, "/");
		const pad = base64.length % 4;
		if (pad) base64 += "=".repeat(4 - pad);
		const json = atob(base64);
		return JSON.parse(json);
	} catch {
		return null;
	}
}

async function resolveSoraProfileId(
	c: AppContext,
	token: SoraToken,
	baseUrl: string,
): Promise<string> {
	let profileId: string | undefined;

	const payload = decodeJwtPayload(token.secretToken);
	if (payload && typeof payload === "object") {
		const auth = (payload as any)["https://api.openai.com/auth"] || {};
		const uid =
			auth.user_id ||
			(payload as any).user_id ||
			undefined;
		if (typeof uid === "string" && uid.startsWith("user-")) {
			profileId = uid;
		}
	}

	if (!profileId) {
		const sessionUrl = new URL("/api/auth/session", baseUrl).toString();
		const res = await fetchWithHttpDebugLog(
			c,
			sessionUrl,
			{
			method: "GET",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
			},
			},
			{ tag: "sora:session" },
		);
		if (res.ok) {
			try {
				const data: any = await res.json();
				profileId =
					data?.user?.user_id ||
					data?.user?.id ||
					data?.user_id ||
					undefined;
			} catch {
				// ignore parse error
			}
		}
	}

	if (!profileId) {
		throw new AppError("Sora session missing profile user id", {
			status: 502,
			code: "sora_profile_missing",
		});
	}

	return profileId;
}

export async function unwatermarkVideo(c: AppContext, url: string) {
	const soraUrl = url.trim();
	if (!soraUrl) {
		throw new AppError("url is required", {
			status: 400,
			code: "invalid_request",
		});
	}

	const endpoint =
		(c.env as any).SORA_UNWATERMARK_ENDPOINT?.trim() ||
		"https://sorai.me/get-sora-link";

	let res: Response;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			endpoint,
			{
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify({ url: soraUrl }),
			},
			{ tag: "sora:unwatermark" },
		);
	} catch (error: any) {
		throw new AppError("Failed to call unwatermark endpoint", {
			status: 502,
			code: "unwatermark_upstream_error",
			details: {
				message: error?.message ?? String(error),
			},
		});
	}

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok || (data && data.error)) {
		const message =
			(typeof data?.error === "string" && data.error) ||
			`Sora unwatermark failed: ${res.status}`;
		throw new AppError(message, {
			status: 502,
			code: "unwatermark_upstream_error",
			details: {
				upstreamStatus: res.status,
				upstreamBody: data,
			},
		});
	}

	const downloadUrl: unknown = data?.download_link ?? data?.downloadLink;
	if (typeof downloadUrl !== "string" || !downloadUrl.trim()) {
		throw new AppError("解析成功但未返回下载链接", {
			status: 502,
			code: "unwatermark_missing_download_url",
			details: {
				upstreamStatus: res.status,
				upstreamBody: data,
			},
		});
	}

	return {
		downloadUrl: downloadUrl.trim(),
		raw: data,
	};
}

export async function createSoraVideoTask(
	c: AppContext,
	userId: string,
	input: {
		tokenId?: string | null;
		prompt: string;
		orientation: "portrait" | "landscape" | "square";
		size?: string;
		n_frames?: number;
		inpaintFileId?: string | null;
		imageUrl?: string | null;
		remixTargetId?: string | null;
		operation?: string | null;
		title?: string | null;
		model?: string | null;
	},
) {
	const taskKind =
		typeof input.imageUrl === "string" && input.imageUrl.trim()
			? "image_to_video"
			: "text_to_video";
	const model = (() => {
		const raw = (input.model || "").trim();
		if (raw) return raw;
		return "sora-2";
	})();
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind,
		vendor: "sora2api",
		modelKey: model,
	});

	// 新接口：Sora2API /v1/video/sora-video（不再走 /backend/nf/create）
	const vendor: "sora2api" | "grsai" = "sora2api";
	const ctxVendor = await resolveVendorContext(c, userId, vendor);
	const baseUrl =
		normalizeBaseUrl(ctxVendor.baseUrl) ||
		(vendor === "grsai" ? "https://api.grsai.com" : "http://localhost:8000");
	const apiKey = ctxVendor.apiKey?.trim?.() || "";
	if (!apiKey) {
		throw new AppError("未配置 Sora2API API Key", {
			status: 400,
			code: "sora2api_api_key_missing",
		});
	}

	const durationSeconds = (() => {
		if (typeof input.n_frames === "number" && Number.isFinite(input.n_frames)) {
			return Math.max(2, Math.min(15, Math.round(input.n_frames / 30)));
		}
		return 10;
	})();
	const aspectRatio =
		input.orientation === "portrait"
			? "9:16"
			: input.orientation === "square"
				? "1:1"
				: "16:9";

	const body: any = {
		model,
		prompt: input.prompt,
		aspectRatio,
		duration: durationSeconds,
		size: input.size || "small",
		stream: false,
		webHook: "-1",
		shutProgress: false,
	};
	if (input.imageUrl) {
		body.url = input.imageUrl;
	}
	if (input.remixTargetId) {
		body.remixTargetId = input.remixTargetId;
	}

	const endpoints = ["/v1/video/sora-video"];

	let result: Awaited<ReturnType<typeof callSora2ApiWithFallbacks>>;
	try {
		result = await callSora2ApiWithFallbacks(c, userId, endpoints, body, vendor);
	} catch (err) {
		if (reservation) {
			await releaseTeamCreditsOnFailure(c, userId, {
				taskId: reservation.reservationTaskId,
				taskKind,
				vendor: "sora2api",
				modelKey: model,
			});
		}
		throw err;
	}

	if (reservation) {
		await bindTeamCreditsReservationToTaskId(c, userId, {
			teamId: reservation.teamId,
			reservationTaskId: reservation.reservationTaskId,
			taskId: result.id,
		});
	}
	{
		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{
					kind: "video",
					taskId: result.id,
					vendor,
				},
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert sora video ref failed",
				err?.message || err,
			);
		}
	}

	return {
		id: result.id,
		task_id: result.id,
		model,
		status: result.status,
		progress: result.progress,
		raw: result.payload,
		__usedTokenId: null,
		__switchedFromTokenIds: [],
	};
}

export async function listSoraPendingVideos(c: AppContext, userId: string) {
	// Simplified implementation: query pending from the first Sora token if available.
	let token: SoraToken | null = null;
	try {
		token = await resolveSoraToken(c, userId);
	} catch {
		return [];
	}

	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL("/backend/nf/pending", baseUrl).toString();
	const userAgent = token.userAgent || "TapCanvas/1.0";

	try {
		const res = await fetchWithHttpDebugLog(
			c,
			url,
			{
			method: "GET",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": userAgent,
				Accept: "*/*",
			},
			},
			{ tag: "sora:pending" },
		);

		let data: any = null;
		try {
			data = await res.json();
		} catch {
			data = null;
		}

		if (!res.ok) {
			return [];
		}

		if (Array.isArray(data)) return data;
		if (Array.isArray(data?.items)) return data.items;
		return [];
	} catch {
		return [];
	}
}

export async function listSoraDrafts(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; cursor?: string | null; limit?: number },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL("/backend/project_y/profile/drafts", baseUrl);
	const params: Record<string, string> = {};
	if (input.cursor) params.cursor = input.cursor;
	if (typeof input.limit === "number" && !Number.isNaN(input.limit)) {
		params.limit = String(input.limit);
	}
	Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

	const userAgent = token.userAgent || "TapCanvas/1.0";

	const res = await fetchWithHttpDebugLog(
		c,
		url.toString(),
		{
			method: "GET",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": userAgent,
				Accept: "application/json",
			},
		},
		{ tag: "sora:drafts" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora drafts request failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_drafts_failed",
		});
	}

	const rawItems: any[] = Array.isArray(data?.items)
		? data.items
		: Array.isArray(data)
			? data
			: [];
	const items = rawItems.map((item) => {
		const enc = item.encodings || {};
		const rawThumbnail =
			enc.thumbnail?.path ||
			item.preview_image_url ||
			item.thumbnail_url ||
			null;
		const rawVideoUrl =
			item.downloadable_url || item.url || enc.source?.path || null;

		const rawCreated: any = (item as any).created_at;
		let createdAt: number | null = null;
		if (typeof rawCreated === "number" && !Number.isNaN(rawCreated)) {
			createdAt = rawCreated;
		} else if (typeof rawCreated === "string") {
			const ts = Date.parse(rawCreated);
			if (!Number.isNaN(ts)) {
				createdAt = Math.floor(ts / 1000);
			}
		}

		return {
			id: String(item.id),
			kind: item.kind ?? "sora_draft",
			title: item.title ?? null,
			prompt:
				item.prompt ??
					item.creation_config?.prompt ??
					null,
			width: item.width ?? null,
			height: item.height ?? null,
			generationType: item.generation_type ?? null,
			createdAt,
			thumbnailUrl: rawThumbnail,
			videoUrl: rawVideoUrl,
			platform: "sora" as const,
		};
	});

	return {
		items,
		cursor: data?.cursor ?? null,
	};
}

export async function deleteSoraDraft(
	c: AppContext,
	userId: string,
	input: { tokenId: string; draftId: string },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		`/backend/project_y/profile/drafts/${input.draftId}`,
		baseUrl,
	).toString();

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "DELETE",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "*/*",
			},
		},
		{ tag: "sora:deleteDraft" },
	);

	if (!res.ok) {
		throw new AppError("Sora delete draft request failed", {
			status: res.status,
			code: "sora_delete_draft_failed",
		});
	}
}

export async function getSoraVideoDraftByTask(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; taskId: string },
) {
	// Simplified: search across all user's Sora tokens in drafts
	const tokens = await listSoraTokens(c, userId);
	if (!tokens.length) {
		throw new AppError("No Sora tokens available", {
			status: 400,
			code: "sora_token_missing",
		});
	}

	const preferredId = input.tokenId ?? null;
	const orderedTokens = [...tokens];
	if (preferredId) {
		orderedTokens.sort((a, b) => {
			if (a.id === preferredId && b.id !== preferredId) return -1;
			if (a.id !== preferredId && b.id === preferredId) return 1;
			return 0;
		});
	}

	for (const token of orderedTokens) {
		const baseUrl = buildSoraBaseUrl(c.env, token);
		const url = new URL("/backend/project_y/profile/drafts", baseUrl);
		url.searchParams.set("limit", "20");
		const userAgent = token.userAgent || "TapCanvas/1.0";

		try {
			const res = await fetchWithHttpDebugLog(
				c,
				url.toString(),
				{
					method: "GET",
					headers: {
						Authorization: `Bearer ${token.secretToken}`,
						"User-Agent": userAgent,
						Accept: "application/json",
					},
				},
				{ tag: "sora:draftsByTask" },
			);
			let data: any = null;
			try {
				data = await res.json();
			} catch {
				data = null;
			}
			if (!res.ok) {
				continue;
			}
			const items: any[] = Array.isArray(data?.items)
				? data.items
				: Array.isArray(data)
					? data
					: [];
			const needle = String(input.taskId);
			const matched = items.find((item) => {
				try {
					const text = JSON.stringify(item);
					return text.includes(needle);
				} catch {
					return false;
				}
			});
			if (!matched) continue;

			const enc = matched.encodings || {};
			const rawThumbnail =
				enc.thumbnail?.path ||
				matched.preview_image_url ||
				matched.thumbnail_url ||
				null;
			const rawVideoUrl =
				matched.downloadable_url ||
				matched.url ||
				enc.source?.path ||
				null;

			const draft = {
				id: String(matched.id),
				title: matched.title ?? null,
				prompt:
					matched.prompt ??
					matched.creation_config?.prompt ??
					null,
				thumbnailUrl: rawThumbnail,
				videoUrl: rawVideoUrl,
				postId: null,
				status:
					(typeof matched.status === "string" &&
						matched.status) ||
					null,
				progress:
					typeof matched.progress === "number"
						? matched.progress
						: null,
				raw: matched,
			};

			const draftStatus =
				typeof draft.status === "string" ? draft.status.trim().toLowerCase() : "";
			if (
				draftStatus === "failed" ||
				draftStatus === "canceled" ||
				draftStatus === "cancelled"
			) {
				await releaseTeamCreditsOnFailure(c, userId, {
					taskId: input.taskId,
					taskKind: "text_to_video",
					vendor: "sora",
				});
			}

			// Update history when video becomes available
			const videoUrl =
				draft.videoUrl && typeof draft.videoUrl === "string"
					? draft.videoUrl
					: null;
			const thumb =
				draft.thumbnailUrl &&
				typeof draft.thumbnailUrl === "string"
					? draft.thumbnailUrl
					: null;
			const duration =
				typeof (matched as any).duration === "number"
					? (matched as any).duration
					: null;
			const width =
				typeof (matched as any).width === "number"
					? (matched as any).width
					: null;
			const height =
				typeof (matched as any).height === "number"
					? (matched as any).height
					: null;
			const generationId =
				(matched as any).generation_id ||
				(matched as any).id ||
				null;

			if (videoUrl) {
				const modelRow = await c.env.DB.prepare(
					`SELECT model FROM video_generation_histories
           WHERE user_id = ? AND task_id = ?
           LIMIT 1`,
				)
					.bind(userId, input.taskId)
					.first<{ model: string | null }>();
				const modelKey =
					typeof modelRow?.model === "string" && modelRow.model.trim()
						? modelRow.model.trim()
						: null;

				let hostedAssets: any[];
				try {
					hostedAssets = await hostTaskAssetsInWorker({
						c,
						userId,
						assets: [
							{
								type: "video",
								url: videoUrl,
								thumbnailUrl: thumb,
							},
						],
						meta: {
							taskKind: "text_to_video",
							prompt:
								typeof draft.prompt === "string" ? draft.prompt : null,
							vendor: "sora",
							modelKey,
							taskId: input.taskId,
						},
					});
				} catch (err: any) {
					const message =
						typeof err?.message === "string" && err.message.trim()
							? err.message.trim()
							: "OSS 托管失败，稍后重试";
					return SoraVideoDraftResponseSchema.parse({
						...draft,
						videoUrl: null,
						thumbnailUrl: null,
						raw: {
							...(draft.raw ?? null),
							hosting: { status: "pending", message },
						},
					});
				}

				const hostedVideoUrl =
					hostedAssets &&
					hostedAssets[0] &&
					typeof hostedAssets[0].url === "string"
						? hostedAssets[0].url
						: null;
				const hostedThumbUrl =
					hostedAssets &&
					hostedAssets[0] &&
					typeof hostedAssets[0].thumbnailUrl === "string"
						? hostedAssets[0].thumbnailUrl
						: null;

				if (!hostedVideoUrl) {
					return SoraVideoDraftResponseSchema.parse({
						...draft,
						videoUrl: null,
						thumbnailUrl: null,
						raw: {
							...(draft.raw ?? null),
							hosting: { status: "pending", message: "OSS 托管中" },
						},
					});
				}

				const nowIso = new Date().toISOString();
				await c.env.DB.prepare(
					`UPDATE video_generation_histories
           SET status = ?, video_url = ?, thumbnail_url = ?,
               duration = ?, width = ?, height = ?, generation_id = ?, updated_at = ?
           WHERE user_id = ? AND task_id = ?`,
				)
					.bind(
						"success",
						hostedVideoUrl,
						hostedThumbUrl,
						duration,
						width,
						height,
						generationId,
						nowIso,
						userId,
						input.taskId,
					)
					.run();

				const amount = await resolveTeamCreditsCostForTask(c, {
					taskKind: "text_to_video",
					modelKey: modelKey || undefined,
				});
				await settleTeamCreditsOnSuccess(c, userId, {
					taskId: input.taskId,
					taskKind: "text_to_video",
					amount,
					vendor: "sora",
					modelKey,
				});

				return SoraVideoDraftResponseSchema.parse({
					...draft,
					videoUrl: hostedVideoUrl,
					thumbnailUrl: hostedThumbUrl,
				});
			}

			return SoraVideoDraftResponseSchema.parse(draft);
		} catch {
			continue;
		}
	}

	throw new AppError(
		"在所有 Sora 账号的草稿中未找到对应视频，请稍后再试",
		{
			status: 404,
			code: "sora_draft_not_found",
		},
	);
}

export async function listSoraCharacters(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; cursor?: string | null; limit?: number },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const profileId = await resolveSoraProfileId(c, token, baseUrl);
	const url = new URL(
		`/backend/project_y/profile/${profileId}/characters`,
		baseUrl,
	);
	if (input.cursor) url.searchParams.set("cursor", input.cursor);
	if (typeof input.limit === "number" && !Number.isNaN(input.limit)) {
		url.searchParams.set("limit", String(input.limit));
	}

	const res = await fetchWithHttpDebugLog(
		c,
		url.toString(),
		{
			method: "GET",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
			},
		},
		{ tag: "sora:characters" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora characters request failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_characters_failed",
		});
	}

	const items: any[] = Array.isArray(data?.items)
		? data.items
		: Array.isArray(data)
			? data
			: [];

	return {
		items,
		cursor: data?.cursor ?? null,
	};
}

export async function createComflyCharacterFromVideo(
	c: AppContext,
	userId: string,
	input: { url?: string; from_task?: string; timestamps?: string },
) {
	const ctx = await resolveVendorContext(c, userId, "comfly");
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = ctx.apiKey.trim();
	if (!baseUrl || !apiKey) {
		throw new AppError("comfly 代理未配置 Host 或 API Key", {
			status: 400,
			code: "comfly_proxy_misconfigured",
		});
	}

	const timestamps = (input.timestamps || "").trim();
	if (!timestamps) {
		throw new AppError("timestamps is required", {
			status: 400,
			code: "timestamps_missing",
		});
	}

	const body: Record<string, any> = {
		timestamps,
	};
	if (typeof input.url === "string" && input.url.trim()) {
		body.url = input.url.trim();
	}
	if (typeof input.from_task === "string" && input.from_task.trim()) {
		body.from_task = input.from_task.trim();
	}

	let res: Response;
	let data: any = null;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl}/sora/v1/characters`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "comfly:sora:characters:create" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("comfly 创建角色请求失败", {
			status: 502,
			code: "comfly_request_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error || data.msg)) ||
			`comfly 创建角色失败：${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "comfly_request_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	const parsed = ComflyCreateCharacterResponseSchema.safeParse(data);
	if (parsed.success) {
		try {
			const nowIso = new Date().toISOString();
			await upsertSavedSoraCharacter(
				c.env.DB,
				userId,
				{
					characterId: parsed.data.id,
					username: parsed.data.username,
					permalink: parsed.data.permalink,
					profilePictureUrl: parsed.data.profile_picture_url,
					source: "comfly",
				},
				nowIso,
			);
		} catch (err) {
			console.warn("[sora] failed to persist comfly character", {
				userId,
				characterId: parsed.data.id,
				error: err instanceof Error ? err.message : String(err),
			});
		}
		return parsed.data;
	}

	return data;
}

export async function deleteSoraCharacter(
	c: AppContext,
	userId: string,
	input: { tokenId: string; characterId: string },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		`/backend/project_y/characters/${input.characterId}`,
		baseUrl,
	).toString();

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "DELETE",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "*/*",
			},
		},
		{ tag: "sora:deleteCharacter" },
	);

	if (!res.ok) {
		throw new AppError("Sora delete character request failed", {
			status: res.status,
			code: "sora_delete_character_failed",
		});
	}
}

export async function updateSoraCharacter(
	c: AppContext,
	userId: string,
	input: {
		tokenId: string;
		characterId: string;
		username?: string;
		display_name?: string | null;
		profile_asset_pointer?: any;
	},
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		`/backend/project_y/characters/${input.characterId}/update`,
		baseUrl,
	).toString();

	const body: any = {};
	if (typeof input.username === "string") {
		body.username = input.username;
	}
	if ("display_name" in input) {
		body.display_name = input.display_name ?? null;
	}
	if ("profile_asset_pointer" in input) {
		body.profile_asset_pointer = input.profile_asset_pointer ?? null;
	}

	let res: Response;
	let data: any = null;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			url,
			{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			body: JSON.stringify(body),
			},
			{ tag: "sora:updateCharacter" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("Sora update character request failed", {
			status: 502,
			code: "sora_update_character_failed",
			details: {
				message: error?.message ?? String(error),
			},
		});
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora update character failed with status ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_update_character_failed",
			details: {
				upstreamStatus: res.status,
				upstreamData: data ?? null,
			},
		});
	}

	return data;
}

export async function checkCharacterUsername(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; username: string },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		"/backend/project_y/profile/username/check",
		baseUrl,
	).toString();

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "*/*",
				"Content-Type": "application/json",
			},
			body: JSON.stringify({ username: input.username }),
		},
		{ tag: "sora:usernameCheck" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora username check failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_username_check_failed",
		});
	}

	return data;
}

export async function searchSoraMentions(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; username: string; intent?: string; limit?: number },
) {
	const query = (input.username || "").trim();
	const limit =
		typeof input.limit === "number" && Number.isFinite(input.limit)
			? Math.max(1, Math.min(50, Math.floor(input.limit)))
			: 10;

	const localRows = await searchSavedSoraCharacters(c.env.DB, userId, {
		query,
		limit,
	});
	const localItems = localRows.map((row) => ({
		id: row.character_id,
		username: row.username,
		display_name: row.username,
		permalink: row.permalink,
		profile_picture_url: row.profile_picture_url,
		source: row.source,
	}));

	// 优先尝试使用官方 Sora Token；若未配置，则兜底使用 Sora2API Token。
	let token: SoraToken;
	try {
		token = await resolveSoraToken(c, userId, input.tokenId);
	} catch (err: any) {
		const isAppError =
			err instanceof AppError ||
			(!!err &&
				typeof err === "object" &&
				"code" in err &&
				"status" in err);
		const code = isAppError ? (err as any).code : null;
		if (code !== "sora_token_missing") {
			throw err;
		}
		// 没有 Sora Token 时，尝试使用 Sora2API Token 兜底；如果仍然没有，则视为未配置。
		try {
			token = await resolveSora2ApiToken(c, userId, input.tokenId);
		} catch {
			// mentions 属于编辑体验增强：缺少 Token 时退化为“仅本地缓存”。
			return { items: localItems };
		}
	}

	// 若 token 来自 Sora2API，自建服务通常不提供 profile/search_mentions，直接退化为本地缓存。
	if ((token.providerVendor || "").toLowerCase() === "sora2api") {
		return { items: localItems };
	}

	// 空查询时仅返回本地缓存，避免上游 400/无意义请求。
	if (!query) {
		return { items: localItems };
	}

	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		"/backend/project_y/profile/search_mentions",
		baseUrl,
	);
	url.searchParams.set("username", query);
	url.searchParams.set("intent", input.intent || "cameo");
	url.searchParams.set("limit", String(limit));

	try {
		const res = await fetchWithHttpDebugLog(
			c,
			url.toString(),
			{
				method: "GET",
				headers: {
					Authorization: `Bearer ${token.secretToken}`,
					"User-Agent": token.userAgent || "TapCanvas/1.0",
					Accept: "*/*",
				},
			},
			{ tag: "sora:searchMentions" },
		);

		let data: any = null;
		try {
			data = await res.json();
		} catch {
			data = null;
		}

		if (!res.ok) {
			const msg =
				(data && (data.message || data.error)) ||
				`Sora search mentions failed: ${res.status}`;
			throw new AppError(msg, {
				status: res.status,
				code: "sora_mentions_failed",
			});
		}

		const remoteItems: any[] = Array.isArray(data?.items)
			? data.items
			: Array.isArray(data)
				? data
				: [];

		if (localItems.length === 0) return { items: remoteItems };
		if (remoteItems.length === 0) return { items: localItems };

		const seen = new Set<string>();
		const merged: any[] = [];
		for (const item of localItems) {
			const key = String(item?.username || "")
				.replace(/^@/, "")
				.toLowerCase();
			if (!key || seen.has(key)) continue;
			seen.add(key);
			merged.push(item);
		}
		for (const item of remoteItems) {
			const key = String(item?.username || "")
				.replace(/^@/, "")
				.toLowerCase();
			if (!key || seen.has(key)) continue;
			seen.add(key);
			merged.push(item);
		}
		return { items: merged };
	} catch (err) {
		console.warn("[sora] search mentions failed; falling back to local cache", {
			userId,
			query,
			error: err instanceof Error ? err.message : String(err),
		});
		return { items: localItems };
	}
}

export async function getCameoStatus(
	c: AppContext,
	userId: string,
	input: { tokenId: string; id: string },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		`/backend/project_y/cameos/in_progress/${input.id}`,
		baseUrl,
	).toString();

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "GET",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
			},
		},
		{ tag: "sora:cameoStatus" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora cameo status failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_cameo_status_failed",
		});
	}

	return data;
}

export async function setCameoPublic(
	c: AppContext,
	userId: string,
	input: { tokenId: string; cameoId: string },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		`/backend/project_y/cameos/by_id/${input.cameoId}/update_v2`,
		baseUrl,
	).toString();

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			body: JSON.stringify({ visibility: "public" }),
		},
		{ tag: "sora:setCameoPublic" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora set cameo public failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_cameo_public_failed",
		});
	}

	return data;
}

export async function finalizeCharacter(
	c: AppContext,
	userId: string,
	input: {
		tokenId: string;
		cameo_id: string;
		username: string;
		display_name: string;
		profile_asset_pointer: any;
	},
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL("/backend/characters/finalize", baseUrl).toString();

	const body = {
		cameo_id: input.cameo_id,
		username: input.username,
		display_name: input.display_name,
		profile_asset_pointer: input.profile_asset_pointer,
		instruction_set: null,
		safety_instruction_set: null,
	};

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			body: JSON.stringify(body),
		},
		{ tag: "sora:finalizeCharacter" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora finalize character failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_finalize_character_failed",
			details: {
				upstreamStatus: res.status,
				upstreamData: data ?? null,
			},
		});
	}

	return data;
}

async function uploadSoraFile(
	c: AppContext,
	token: SoraToken,
	baseUrl: string,
	file: File,
	useCase: string,
): Promise<any> {
	const url = new URL("/backend/project_y/file/upload", baseUrl).toString();
	const form = new FormData();
	const filename = (file as any).name || "upload.bin";
	form.append("file", file, filename);
	form.append("use_case", useCase);

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
			},
			body: form,
		},
		{ tag: "sora:fileUpload" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const rawMessage = data && (data.message || data.error);
		const msg =
			typeof rawMessage === "string"
				? rawMessage
				: `Sora file upload failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_upload_failed",
			details: {
				upstreamStatus: res.status,
				upstreamData: data ?? null,
			},
		});
	}

	return data;
}

export async function uploadProfileAsset(
	c: AppContext,
	userId: string,
	input: { tokenId: string; file: File },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	return uploadSoraFile(c, token, baseUrl, input.file, "profile");
}

export async function uploadSoraImage(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; file: File },
) {
	// NOTE: 本仓库已废弃上游 Sora 上传服务；该接口只负责把图片上传到 OSS（R2），
	// 并返回一个可公开访问的 URL，供前端作为 referenceImages / imageUrl 使用。
	const rustfs = resolveRustfsConfig(c.env);
	const bucket = (c.env as any).R2_ASSETS as R2Bucket | undefined;
	if (!rustfs && !bucket) {
		throw new AppError("OSS storage is not configured", {
			status: 500,
			code: "oss_not_configured",
		});
	}
	// 生成与 asset.hosting 类似的 key：uploads/sora/<userId>/<yyyymmdd>/<uuid>.<ext>
	const file = input.file;
	const contentType =
		(file.type && String(file.type).split(";")[0].trim()) ||
		"application/octet-stream";

	let ext = "bin";
	const name = (file as any).name as string | undefined;
	if (name && typeof name === "string") {
		const match = name.match(/\.([a-zA-Z0-9]+)$/);
		if (match && match[1]) {
			ext = match[1].toLowerCase();
		}
	}
	if (ext === "bin") {
		if (contentType.startsWith("image/")) {
			ext = contentType.slice("image/".length) || "png";
		} else if (contentType === "video/mp4") {
			ext = "mp4";
		}
	}

	const safeUser = (userId || "anon").replace(/[^a-zA-Z0-9_-]/g, "_");
	const now = new Date();
	const datePrefix = `${now.getUTCFullYear()}${String(
		now.getUTCMonth() + 1,
	).padStart(2, "0")}${String(now.getUTCDate()).padStart(2, "0")}`;
	const random = crypto.randomUUID();
	const key = `uploads/sora/${safeUser}/${datePrefix}/${random}.${ext || "bin"}`;

	if (rustfs) {
		const client = createRustfsClient(c.env);
		await client.send(
			new PutObjectCommand({
				Bucket: rustfs.bucket,
				Key: key,
				Body: file,
				ContentType: contentType,
				CacheControl: "public, max-age=31536000, immutable",
			}),
		);
	} else {
		await bucket!.put(key, file, {
			httpMetadata: {
				contentType,
				cacheControl: "public, max-age=31536000, immutable",
			},
		});
	}

	const publicBase = resolvePublicAssetBaseUrl(c).trim().replace(/\/+$/, "");
	const url = publicBase ? `${publicBase}/${key}` : `/${key}`;

	// 兼容前端期望的字段：file_id + (asset_pointer|azure_asset_pointer|url)
	return {
		file_id: `r2_${key}`,
		url,
		asset_pointer: url,
		azure_asset_pointer: url,
	};
}

export async function uploadCharacterVideo(
	c: AppContext,
	userId: string,
	input: { tokenId: string; file: File; range: [number, number] },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL("/backend/characters/upload", baseUrl).toString();
	const [start, end] = input.range;

	const form = new FormData();
	const filename = (input.file as any).name || "character.mp4";
	form.append("file", input.file, filename);
	form.append("timestamps", `${start},${end}`);

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
			},
			body: form,
		},
		{ tag: "sora:uploadCharacterVideo" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora upload character video failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_upload_character_failed",
		});
	}

	return data;
}

export async function listSoraPublishedVideos(
	c: AppContext,
	userId: string,
	input: { tokenId?: string | null; limit?: number },
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const url = new URL(
		"/backend/project_y/profile_feed/me",
		baseUrl,
	);
	const limit =
		typeof input.limit === "number" && !Number.isNaN(input.limit)
			? input.limit
			: 8;

	url.searchParams.set("limit", String(limit));
	url.searchParams.set("cut", "nf2");

	const res = await fetchWithHttpDebugLog(
		c,
		url.toString(),
		{
			method: "GET",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
			},
		},
		{ tag: "sora:publishedVideos" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Published videos fetch failed with status ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_published_failed",
		});
	}

	const items: any[] = Array.isArray(data?.items)
		? data.items
		: [];

	const processed = items.map((item) => {
		const post = item.post || {};
		const attachments = post.attachments || [];
		const soraAttachment = attachments.find(
			(att: any) => att && att.kind === "sora",
		);

		const rawPostedAt: any = post.posted_at;
		let createdAt: number | null = null;
		if (typeof rawPostedAt === "number" && !Number.isNaN(rawPostedAt)) {
			createdAt = rawPostedAt;
		} else if (typeof rawPostedAt === "string") {
			const ts = Date.parse(rawPostedAt);
			if (!Number.isNaN(ts)) {
				createdAt = Math.floor(ts / 1000);
			}
		}

		if (!soraAttachment) {
			return {
				id: String(post.id),
				kind: "sora_published",
				title: post.text ?? null,
				prompt: post.text ?? null,
				width: null,
				height: null,
				generationType: null,
				createdAt,
				thumbnailUrl: post.preview_image_url ?? null,
				videoUrl: null,
				platform: "sora" as const,
			};
		}

		const enc = soraAttachment.encodings || {};

		const thumbnail =
			enc.thumbnail?.path || post.preview_image_url || null;
		const videoUrl =
			enc.source?.path ||
			soraAttachment.url ||
			soraAttachment.downloadable_url ||
			null;

		return {
			id: String(post.id),
			kind: "sora_published",
			title: post.text ?? null,
			prompt: soraAttachment.prompt ?? post.text ?? null,
			width: soraAttachment.width ?? null,
			height: soraAttachment.height ?? null,
			generationType: null,
			createdAt,
			thumbnailUrl: thumbnail,
			videoUrl,
			platform: "sora" as const,
		};
	});

	return {
		items: processed,
		cursor: data?.cursor ?? null,
	};
}

export async function publishSoraVideo(
	c: AppContext,
	userId: string,
	input: {
		tokenId?: string | null;
		taskId: string;
		postText?: string;
		generationId?: string;
	},
) {
	const token = await resolveSoraToken(c, userId, input.tokenId);
	const baseUrl = buildSoraBaseUrl(c.env, token);
	const finalGenerationId = input.generationId || input.taskId;

	if (!finalGenerationId) {
		throw new AppError("No generation_id provided", {
			status: 400,
			code: "sora_publish_missing_generation",
		});
	}

	let text = (input.postText || "").trim();
	if (!text) {
		throw new AppError("No post text available", {
			status: 400,
			code: "sora_publish_missing_text",
		});
	}

	// Soft truncate to avoid 413 / moderation issues
	const maxLen = 2000;
	if (text.length > maxLen) {
		text = text.slice(0, maxLen);
	}

	const url = new URL("/backend/project_y/post", baseUrl).toString();
	const body = {
		attachments_to_create: [
			{ generation_id: finalGenerationId, kind: "sora" },
		],
		post_text: text,
	};

	const res = await fetchWithHttpDebugLog(
		c,
		url,
		{
			method: "POST",
			headers: {
				Authorization: `Bearer ${token.secretToken}`,
				"User-Agent": token.userAgent || "TapCanvas/1.0",
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			body: JSON.stringify(body),
		},
		{ tag: "sora:publish" },
	);

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error)) ||
			`Sora publish video failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora_publish_failed",
			details: {
				upstreamStatus: res.status,
				upstreamData: data ?? null,
			},
		});
	}

	const postId =
		(typeof data?.id === "string" && data.id) ||
		(typeof data?.post?.id === "string" && data.post.id) ||
		(typeof data?.post_id === "string" && data.post_id) ||
		null;

	if (postId) {
		const nowIso = new Date().toISOString();
		await c.env.DB.prepare(
			`UPDATE video_generation_histories
       SET updated_at = ?, notes = COALESCE(notes, ''), generation_id = COALESCE(generation_id, ?)
       WHERE user_id = ? AND task_id = ?`,
		)
			.bind(nowIso, finalGenerationId, userId, input.taskId)
			.run();
	}

	return {
		success: !!postId,
		postId,
		message: postId
			? "Video published successfully"
			: "Publish succeeded but no postId returned",
	};
}

// ---------- Sora2API / GRSAI Character helpers ----------

type Sora2ApiCharacterPayload = {
	id: string;
	progress?: number | null;
	status?: string | null;
	results?: Array<{ character_id?: string | null }>;
	error?: string | null;
	failure_reason?: string | null;
	msg?: string | null;
};

function mapSora2ApiStatus(status?: string | null): "running" | "succeeded" | "failed" {
	const normalized = (status || "").toLowerCase();
	if (normalized === "succeeded") return "succeeded";
	if (normalized === "failed") return "failed";
	return "running";
}

function clampCharacterProgress(value?: number | null): number | undefined {
	if (typeof value !== "number" || Number.isNaN(value)) return undefined;
	return Math.max(0, Math.min(100, value));
}

function extractProgress(payload: any): number | undefined {
	if (!payload || typeof payload !== "object") return undefined;
	const normalize = (val: any) => {
		if (typeof val !== "number" || Number.isNaN(val)) return undefined;
		// Some providers return 0-1 for *_pct; auto-scale to percentage.
		if (val > 0 && val <= 1) return val * 100;
		return val;
	};
	const candidates: Array<number | undefined> = [
		normalize((payload as any).progress),
		normalize((payload as any).progress_pct),
		normalize((payload as any).progressPct),
		normalize((payload as any).progressPercent),
		normalize((payload as any).progress_percentage),
		normalize((payload as any).progressPercentile),
	];
	if (Array.isArray((payload as any).results) && (payload as any).results.length) {
		const first = (payload as any).results[0];
		candidates.push(
			normalize(first?.progress),
			normalize(first?.progress_pct),
			normalize(first?.progressPct),
			normalize(first?.progressPercent),
		);
	}
	const val = candidates.find((v) => typeof v === "number" && Number.isFinite(v));
	return typeof val === "number" ? clampCharacterProgress(val) : undefined;
}

function extractCharacterId(payload: any): string | null {
	if (!payload || typeof payload !== "object") return null;
	const direct =
		(typeof payload.character_id === "string" && payload.character_id.trim()) ||
		(typeof payload.characterId === "string" && payload.characterId.trim()) ||
		null;
	if (direct) return direct;
	if (Array.isArray(payload.results) && payload.results.length) {
		const first = payload.results[0];
		const nested =
			(typeof first?.character_id === "string" && first.character_id.trim()) ||
			(typeof first?.characterId === "string" && first.characterId.trim()) ||
			null;
		if (nested) return nested;
	}
	return null;
}

async function readFirstEventStreamJson(res: Response, timeoutMs = 15000): Promise<any> {
	const body = res.body;
	if (!body) return null;
	const reader = body.getReader();
	const decoder = new TextDecoder();
	let buffer = "";
	const timeout = setTimeout(() => {
		try {
			reader.cancel();
		} catch {
			// ignore
		}
	}, timeoutMs);
	try {
		// Read until we find a "data:" JSON event or hit timeout/end.
		// Limit buffer to avoid unbounded growth.
		while (true) {
			const { done, value } = await reader.read();
			if (value) {
				buffer += decoder.decode(value, { stream: true });
				if (buffer.length > 64_000) {
					buffer = buffer.slice(-32_000);
				}
				const lines = buffer.split(/\r?\n/).filter(Boolean);
				for (let i = lines.length - 1; i >= 0; i -= 1) {
					const line = lines[i];
					const match = line.match(/^data:\s*(\{.*\})\s*$/);
					if (!match) continue;
					try {
						return JSON.parse(match[1]);
					} catch {
						// keep reading
					}
				}
			}
			if (done) break;
		}
	} catch {
		// ignore stream errors; fallback to null
	} finally {
		clearTimeout(timeout);
		try {
			reader.cancel();
		} catch {
			// ignore
		}
	}
	return null;
}

async function callSora2ApiWithFallbacks(
	c: AppContext,
	userId: string,
	endpoints: string[],
	body: Record<string, any>,
	vendor: "sora2api" | "grsai" = "sora2api",
): Promise<{
	id: string;
	payload: any;
	status: "running" | "succeeded" | "failed";
	progress?: number;
	endpoint: string;
}> {
	const ctx = await resolveVendorContext(c, userId, vendor);
	const baseUrl =
		normalizeBaseUrl(ctx.baseUrl) ||
		(vendor === "grsai" ? "https://api.grsai.com" : "http://localhost:8000");
	const baseLooksLocal =
		/^https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/i.test(baseUrl);
	if (baseLooksLocal && !ctx.baseUrl && !ctx.viaProxyVendor) {
		throw new AppError(
			`未配置 ${vendor} Base URL，请在环境变量 SORA2API_BASE_URL（或 Proxy Provider）中设置可访问的上游地址`,
			{
				status: 400,
				code: "sora2api_base_url_missing",
			},
		);
	}
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(`未配置 ${vendor} API Key`, {
			status: 400,
			code: "sora2api_api_key_missing",
		});
	}

	const normalizeEndpoint = (endpoint: string) => {
		if (!endpoint) return endpoint;
		if (endpoint.startsWith("http")) return endpoint;
		return `${baseUrl}${endpoint.startsWith("/") ? "" : "/"}${endpoint}`;
	};

	let lastError: any = null;
		for (const rawEndpoint of endpoints) {
		const endpoint = normalizeEndpoint(rawEndpoint);
		let res: Response;
		let data: any = null;
		try {
				res = await fetchWithHttpDebugLog(
					c,
					endpoint,
					{
						method: "POST",
						headers: {
							"Content-Type": "application/json",
							Accept: "application/json",
							Authorization: `Bearer ${apiKey}`,
						},
						body: JSON.stringify(body),
					},
					{ tag: `${vendor}:call` },
				);
				const ct = (res.headers.get("content-type") || "").toLowerCase();
				if (ct.includes("text/event-stream")) {
					data = await readFirstEventStreamJson(res);
				} else if (ct.includes("application/json")) {
					try {
						data = await res.json();
					} catch {
						data = null;
					}
			} else {
				try {
					data = await res.text();
				} catch {
					data = null;
				}
			}
		} catch (error: any) {
			lastError = {
				status: 502,
				data: null,
				message: error?.message ?? String(error),
				endpoint,
			};
			continue;
		}

		if (res.status < 200 || res.status >= 300) {
			lastError = {
				status: res.status,
				data,
				message:
					(data &&
						(data.error?.message ||
							data.message ||
							data.error)) ||
					`sora2api 请求失败: ${res.status}`,
				endpoint,
			};
			continue;
		}

		const payload = (() => {
			if (typeof data === "string") {
				const lines = data.split(/\r?\n/).filter(Boolean);
				for (let i = lines.length - 1; i >= 0; i -= 1) {
					const line = lines[i];
					const match = line.match(/^data:\s*(\{.*\})\s*$/);
					if (!match) continue;
					try {
						return JSON.parse(match[1]);
					} catch {
						continue;
					}
				}
				return null;
			}
			return typeof data?.code === "number" && data.code === 0 && data.data
				? data.data
				: data;
		})();
		if (!payload) {
			lastError = {
				status: res.status,
				data,
				message: "sora2api 未返回有效 payload",
				endpoint,
			};
			continue;
		}
		if (typeof data?.code === "number" && data.code !== 0) {
			lastError = {
				status: res.status,
				data,
				message:
					data?.msg ||
					data?.message ||
					data?.error ||
					`sora2api 请求失败: code ${data.code}`,
				endpoint,
			};
			continue;
		}

		const id =
			(typeof payload?.id === "string" && payload.id.trim()) ||
			(typeof payload?.taskId === "string" && payload.taskId.trim()) ||
			null;
		if (!id) {
			// grsai chat/completions character-only flow may return character_id directly
			const directCharacterId =
				(typeof payload?.character_id === "string" && payload.character_id.trim()) ||
				(Array.isArray(payload?.results) && payload.results[0]?.character_id
					? String(payload.results[0].character_id).trim()
					: null) ||
				null;
			if (directCharacterId) {
				return {
					id: directCharacterId,
					payload,
					status: "succeeded",
					progress: 100,
					endpoint,
				};
			}
			lastError = {
				status: res.status,
				data,
				message: "sora2api 未返回任务 ID",
				endpoint,
			};
			continue;
		}

		const status = mapSora2ApiStatus(payload.status || data?.status);
		const progress = clampCharacterProgress(
			typeof payload?.progress === "number"
				? payload.progress
				: typeof payload?.progress_pct === "number"
					? payload.progress_pct * 100
					: undefined,
		);

		return {
			id: id.trim(),
			payload,
			status,
			progress,
			endpoint,
		};
	}

	throw new AppError(lastError?.message || "sora2api 调用失败", {
		status: lastError?.status ?? 502,
		code: "sora2api_request_failed",
		details: {
			upstreamStatus: lastError?.status ?? null,
			upstreamData: lastError?.data ?? null,
			endpointTried: lastError?.endpoint ?? null,
			endpointsRequested: endpoints.map((e) => normalizeEndpoint(e)),
			baseUrl,
			vendor,
			requestBody: body,
		},
	});
}


export async function uploadCharacterViaSora2Api(
	c: AppContext,
	userId: string,
	input: { url: string; timestamps?: string; webHook?: string; shutProgress?: boolean; vendor?: "sora2api" | "grsai" },
) {
	const vendor = input.vendor === "grsai" ? "grsai" : "sora2api";
	const ctx = await resolveVendorContext(c, userId, vendor);
	const baseUrl =
		normalizeBaseUrl(ctx.baseUrl) ||
		(vendor === "grsai" ? "https://api.grsai.com" : "http://localhost:8000");
	const baseLooksLocal =
		/^https?:\/\/(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/i.test(baseUrl);
	if (baseLooksLocal && !ctx.baseUrl && !ctx.viaProxyVendor) {
		throw new AppError(
			`未配置 ${vendor} Base URL，请在环境变量 SORA2API_BASE_URL（或 Proxy Provider）中设置可访问的上游地址`,
			{
				status: 400,
				code: "sora2api_base_url_missing",
			},
		);
	}
	const body = {
		url: input.url,
		...(input.timestamps ? { timestamps: input.timestamps } : {}),
		webHook: typeof input.webHook === "string" ? input.webHook : "-1",
		shutProgress: input.shutProgress === true,
	};
	// Use the non-stream upload endpoints for both sora2api and grsai bases.
	const endpoints = [
		"/v1/video/sora-upload-character",
		"/client/v1/video/sora-upload-character",
		"/client/video/sora-upload-character",
	];
	const result = await callSora2ApiWithFallbacks(c, userId, endpoints, body, vendor);
	const characterId = extractCharacterId(result.payload);
	const status = characterId ? "succeeded" : result.status;
	const progress = characterId ? 100 : result.progress;
	const results = characterId
		? [{ character_id: characterId }]
		: Array.isArray((result.payload as any)?.results)
			? (result.payload as any).results
			: [];
	const failure_reason =
		(typeof (result.payload as any)?.failure_reason === "string" &&
			(result.payload as any).failure_reason.trim()) ||
		(typeof (result.payload as any)?.failureReason === "string" &&
			(result.payload as any).failureReason.trim()) ||
		null;
	const error =
		(typeof (result.payload as any)?.error === "string" &&
			(result.payload as any).error.trim()) ||
		(typeof (result.payload as any)?.message === "string" &&
			(result.payload as any).message.trim()) ||
		(typeof (result.payload as any)?.msg === "string" &&
			(result.payload as any).msg.trim()) ||
		null;
	{
		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{
					kind: "character",
					taskId: result.id,
					vendor,
				},
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert character upload ref failed",
				err?.message || err,
			);
		}
	}
	return {
		...result,
		status,
		progress,
		results,
		failure_reason,
		error,
		characterId: characterId || null,
	};
}


export async function createCharacterFromPidViaSora2Api(
	c: AppContext,
	userId: string,
	input: { pid: string; timestamps?: string; webHook?: string; shutProgress?: boolean; vendor?: "sora2api" | "grsai" },
) {
	const vendor = input.vendor === "grsai" ? "grsai" : "sora2api";
	const body = {
		pid: input.pid,
		timestamps: input.timestamps || "0,3",
		webHook: typeof input.webHook === "string" ? input.webHook : "-1",
		shutProgress: input.shutProgress === true,
	};
	const endpoints = vendor === "grsai"
		? [
				"/v1/video/sora-create-character",
				"/client/v1/video/sora-create-character",
				"/client/video/sora-create-character",
				"/v1/video/characters/create",
				"/client/v1/video/characters/create",
				"/client/video/characters/create",
			]
		: [
				"/v1/video/sora-create-character",
				"/client/v1/video/sora-create-character",
				"/client/video/sora-create-character",
			];
	const result = await callSora2ApiWithFallbacks(c, userId, endpoints, body, vendor);
	const characterId = extractCharacterId(result.payload);
	const status = characterId ? "succeeded" : result.status;
	const progress = characterId ? 100 : result.progress;
	const results = characterId
		? [{ character_id: characterId }]
		: Array.isArray((result.payload as any)?.results)
			? (result.payload as any).results
			: [];
	const failure_reason =
		(typeof (result.payload as any)?.failure_reason === "string" &&
			(result.payload as any).failure_reason.trim()) ||
		(typeof (result.payload as any)?.failureReason === "string" &&
			(result.payload as any).failureReason.trim()) ||
		null;
	const error =
		(typeof (result.payload as any)?.error === "string" &&
			(result.payload as any).error.trim()) ||
		(typeof (result.payload as any)?.message === "string" &&
			(result.payload as any).message.trim()) ||
		(typeof (result.payload as any)?.msg === "string" &&
			(result.payload as any).msg.trim()) ||
		null;
	{
		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{
					kind: "character",
					taskId: result.id,
					vendor,
					pid: input.pid,
				},
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert character pid ref failed",
				err?.message || err,
			);
		}
	}
	return {
		...result,
		status,
		progress,
		results,
		failure_reason,
		error,
		characterId: characterId || null,
	};
}

export async function fetchSora2ApiCharacterResult(
	c: AppContext,
	userId: string,
	taskId: string,
	vendor: "sora2api" | "grsai" = "sora2api",
) {
	const ctx = await resolveVendorContext(c, userId, vendor);
	const baseUrl =
		normalizeBaseUrl(ctx.baseUrl) ||
		(vendor === "grsai" ? "https://api.grsai.com" : "http://localhost:8000");
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(`未配置 ${vendor} API Key`, {
			status: 400,
			code: "sora2api_api_key_missing",
		});
	}

	const endpoints: Array<{
		url: string;
		method: "GET" | "POST";
		body?: any;
	}> =
		vendor === "grsai"
			? [
					{
						url: `${baseUrl}/v1/draw/result`,
						method: "POST",
						body: JSON.stringify({ id: taskId.trim() }),
					},
					{
						url: `${baseUrl}/v1/video/tasks/${encodeURIComponent(
							taskId.trim(),
						)}`,
						method: "GET",
					},
				]
			: [
					{
						url: `${baseUrl}/v1/video/tasks/${encodeURIComponent(
							taskId.trim(),
						)}`,
						method: "GET",
					},
				];

	let lastError: {
		status: number;
		data: any;
		message: string;
		endpoint?: string;
	} | null = null;
	let data: any = null;

	for (const endpoint of endpoints) {
		let res: Response;
		data = null;
		try {
			res = await fetchWithHttpDebugLog(
				c,
				endpoint.url,
				{
					method: endpoint.method,
					headers: {
						Authorization: `Bearer ${apiKey}`,
						...(endpoint.method === "POST"
							? { "Content-Type": "application/json" }
							: {}),
					},
					body: endpoint.body,
				},
				{ tag: `${vendor}:characterResult` },
			);
			try {
				data = await res.json();
			} catch {
				data = null;
			}
		} catch (error: any) {
			lastError = {
				status: 502,
				data: null,
				message: error?.message ?? String(error),
				endpoint: endpoint.url,
			};
			continue;
		}

		if (res.status < 200 || res.status >= 300) {
			lastError = {
				status: res.status,
				data,
				message:
					(data &&
						(data.error?.message ||
							data.message ||
							data.error)) ||
					`${vendor} 任务查询失败: ${res.status}`,
				endpoint: endpoint.url,
			};
			continue;
		}

		lastError = null;
		break;
	}

	if (lastError) {
		throw new AppError(lastError.message || `${vendor} 结果查询失败`, {
			status: lastError.status ?? 502,
			code: "sora2api_result_failed",
			details: {
				upstreamStatus: lastError.status ?? null,
				upstreamData: lastError.data ?? null,
				endpointTried: lastError.endpoint ?? null,
				vendor,
			},
		});
	}

	const payload: Sora2ApiCharacterPayload =
		typeof data?.code === "number" && data.code === 0 && data.data
			? data.data
			: data;

	const status = mapSora2ApiStatus(payload.status);
	const progress = extractProgress(payload);
	const characterId = extractCharacterId(payload);
	const finalStatus = characterId ? "succeeded" : status;
	const finalProgress = characterId ? 100 : progress;
	const results = characterId
		? [{ character_id: characterId }]
		: Array.isArray((payload as any)?.results)
			? (payload as any).results
			: [];
	const failure_reason =
		(typeof (payload as any)?.failure_reason === "string" &&
			(payload as any).failure_reason.trim()) ||
		(typeof (payload as any)?.failureReason === "string" &&
			(payload as any).failureReason.trim()) ||
		null;
	const error =
		(typeof (payload as any)?.error === "string" &&
			(payload as any).error.trim()) ||
		(typeof (payload as any)?.message === "string" &&
			(payload as any).message.trim()) ||
		(typeof (payload as any)?.msg === "string" &&
			(payload as any).msg.trim()) ||
		null;

	return {
		id: payload.id,
		status: finalStatus,
		progress: finalProgress,
		results,
		failure_reason,
		error,
		characterId,
		raw: payload,
	};
}
