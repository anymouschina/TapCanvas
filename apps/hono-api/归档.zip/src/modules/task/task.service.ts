import { AppError } from "../../middleware/error";
import type { AppContext } from "../../types";
import { fetchWithHttpDebugLog } from "../../httpDebugLog";
import type {
	EndpointRow,
	ProviderRow,
	TokenRow,
	ProxyProviderRow,
} from "../model/model.repo";
import {
	TaskAssetSchema,
	TaskResultSchema,
	type TaskRequestDto,
	TaskStatusSchema,
} from "./task.schemas";
import { emitTaskProgress } from "./task.progress";
import { hostTaskAssetsInWorker } from "../asset/asset.hosting";
import { resolvePublicAssetBaseUrl } from "../asset/asset.publicBase";
import { PutObjectCommand } from "@aws-sdk/client-s3";
import {
	createRustfsClient,
	resolveRustfsConfig,
} from "../asset/rustfs.client";
import { ensureModelCatalogSchema } from "../model-catalog/model-catalog.repo";
import {
	buildMappedUpstreamRequest,
	parseMappedTaskResultFromPayload,
	resolveEnabledModelCatalogMappingForTask,
} from "./task.mappings";
import {
	getVendorTaskRefByTaskId,
	upsertVendorTaskRef,
} from "./vendor-task-refs.repo";
import {
	upsertVendorCallLogFinal,
	upsertVendorCallLogStarted,
	ensureVendorCallLogsSchema,
	upsertVendorCallLogPayloads,
} from "./vendor-call-logs.repo";
import {
	bindTeamCreditsReservationToTaskId,
	requireSufficientTeamCredits,
	releaseTeamCreditsOnFailure,
	settleTeamCreditsOnSuccess,
} from "../team/team.service";
import { resolveTeamCreditsCostForTask } from "../billing/billing.service";

type VendorContext = {
	baseUrl: string;
	apiKey: string;
	viaProxyVendor?: string;
};

type TaskResult = ReturnType<typeof TaskResultSchema.parse>;

type TaskStatus = ReturnType<typeof TaskStatusSchema.parse>;

type ProgressContext = {
	nodeId: string;
	nodeKind?: string;
	taskKind: TaskRequestDto["kind"];
	vendor: string;
};

type TeamCreditsReservation = Awaited<
	ReturnType<typeof requireSufficientTeamCredits>
>;

async function releaseReservationOnThrow(
	c: AppContext,
	userId: string,
	reservation: TeamCreditsReservation,
	err: unknown,
): Promise<never> {
	if (reservation) {
		try {
			await releaseTeamCreditsOnFailure(c, userId, {
				taskId: reservation.reservationTaskId,
				taskKind: reservation.taskKind,
				vendor: reservation.vendor,
				modelKey: reservation.modelKey ?? null,
			});
		} catch {
			// ignore
		}
	}
	throw err;
}

async function bindReservationToTaskId(
	c: AppContext,
	userId: string,
	reservation: TeamCreditsReservation,
	taskId: string,
): Promise<void> {
	if (!reservation) return;
	const toTaskId = (taskId || "").trim();
	if (!toTaskId) return;
	try {
		await bindTeamCreditsReservationToTaskId(c, userId, {
			teamId: reservation.teamId,
			reservationTaskId: reservation.reservationTaskId,
			taskId: toTaskId,
		});
	} catch {
		// ignore
	}
}

function pickApiVendorForTask(
	result: TaskResult,
	fallbackVendor: string,
): string {
	const raw: any = result?.raw;
	const rawVendor = typeof raw?.vendor === "string" ? raw.vendor : "";
	const normalized = normalizeVendorKey(rawVendor);
	return normalized || fallbackVendor;
}

function extractProgressContext(
	req: TaskRequestDto,
	vendor: string,
): ProgressContext | null {
	const extras = (req.extras || {}) as Record<string, any>;
	const rawNodeId =
		typeof extras.nodeId === "string" ? extras.nodeId.trim() : "";
	if (!rawNodeId) return null;
	const nodeKind =
		typeof extras.nodeKind === "string" ? extras.nodeKind : undefined;
	return {
		nodeId: rawNodeId,
		nodeKind,
		taskKind: req.kind,
		vendor,
	};
}

function emitProgress(
	userId: string,
	ctx: ProgressContext | null,
	event: {
		status: TaskStatus;
		progress?: number;
		message?: string;
		taskId?: string;
		assets?: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		raw?: unknown;
	},
) {
	if (!ctx) return;
	emitTaskProgress(userId, {
		nodeId: ctx.nodeId,
		nodeKind: ctx.nodeKind,
		taskKind: ctx.taskKind,
		vendor: ctx.vendor,
		status: event.status,
		progress: event.progress,
		message: event.message,
		taskId: event.taskId,
		assets: event.assets,
		raw: event.raw,
	});
}

function normalizeBaseUrl(raw: string | null | undefined): string {
	const val = (raw || "").trim();
	if (!val) return "";
	return val.replace(/\/+$/, "");
}

async function recordVendorCallStarted(
	c: AppContext,
	input: { userId: string; vendor: string; taskId: string; taskKind?: string | null },
): Promise<void> {
	const nowIso = new Date().toISOString();
	try {
		await upsertVendorCallLogStarted(c.env.DB, {
			userId: input.userId,
			vendor: input.vendor,
			taskId: input.taskId,
			taskKind: input.taskKind ?? null,
			nowIso,
		});
	} catch (err: any) {
		console.warn(
			"[vendor-call-logs] upsert started failed",
			err?.message || err,
		);
	}
}

async function recordVendorCallFinal(
	c: AppContext,
	input: {
		userId: string;
		vendor: string;
		taskId: string;
		taskKind?: string | null;
		status: "succeeded" | "failed";
		errorMessage?: string | null;
		durationMs?: number | null;
	},
): Promise<void> {
	const nowIso = new Date().toISOString();
	try {
		await upsertVendorCallLogFinal(c.env.DB, {
			userId: input.userId,
			vendor: input.vendor,
			taskId: input.taskId,
			taskKind: input.taskKind ?? null,
			status: input.status,
			errorMessage: input.errorMessage ?? null,
			durationMs:
				typeof input.durationMs === "number" &&
				Number.isFinite(input.durationMs)
					? Math.max(0, Math.round(input.durationMs))
					: null,
			nowIso,
		});
	} catch (err: any) {
		console.warn(
			"[vendor-call-logs] upsert final failed",
			err?.message || err,
		);
	}
}

async function recordVendorCallPayloads(
	c: AppContext,
	input: {
		userId: string;
		vendor: string;
		taskId: string;
		taskKind?: string | null;
		request?: unknown;
		upstreamResponse?: unknown;
	},
): Promise<void> {
	const nowIso = new Date().toISOString();
	try {
		await upsertVendorCallLogPayloads(c.env.DB, {
			userId: input.userId,
			vendor: input.vendor,
			taskId: input.taskId,
			taskKind: input.taskKind ?? null,
			request: input.request,
			upstreamResponse: input.upstreamResponse,
			nowIso,
		});
	} catch (err: any) {
		console.warn(
			"[vendor-call-logs] upsert payloads failed",
			err?.message || err,
		);
	}
}

async function recordVendorCallFromTaskResult(
	c: AppContext,
	input: {
		userId: string;
		vendor: string;
		taskKind?: string | null;
		result: TaskResult;
		durationMs?: number | null;
	},
): Promise<void> {
	const taskId =
		typeof input.result?.id === "string" ? input.result.id.trim() : "";
	if (!taskId) return;
	const vendorKey = normalizeVendorKey(input.vendor);
	const channelVendor = extractChannelVendor(vendorKey);
	if (input.result.status === "queued" || input.result.status === "running") {
		await recordVendorCallStarted(c, {
			userId: input.userId,
			vendor: vendorKey,
			taskId,
			taskKind: input.taskKind ?? null,
		});
		if (channelVendor && channelVendor !== vendorKey) {
			await recordVendorCallStarted(c, {
				userId: input.userId,
				vendor: channelVendor,
				taskId,
				taskKind: input.taskKind ?? null,
			});
		}
		return;
	}
	if (input.result.status === "succeeded" || input.result.status === "failed") {
		const errorMessage = (() => {
			if (input.result.status !== "failed") return null;
			const raw: any = input.result?.raw as any;
			const candidates = [
				raw?.failureReason,
				raw?.message,
				raw?.error,
				raw?.response?.failureReason,
				raw?.response?.failure_reason,
				raw?.response?.error?.message,
				raw?.response?.error_message,
				raw?.response?.error,
				raw?.response?.message,
			];
			for (const value of candidates) {
				if (typeof value === "string" && value.trim()) {
					return value.trim();
				}
			}
			return null;
		})();

		await recordVendorCallFinal(c, {
			userId: input.userId,
			vendor: vendorKey,
			taskId,
			taskKind: input.taskKind ?? null,
			status: input.result.status,
			errorMessage,
			durationMs: input.durationMs ?? null,
		});
		if (channelVendor && channelVendor !== vendorKey) {
			await recordVendorCallFinal(c, {
				userId: input.userId,
				vendor: channelVendor,
				taskId,
				taskKind: input.taskKind ?? null,
				status: input.result.status,
				errorMessage,
				durationMs: input.durationMs ?? null,
			});
		}

		const resolvedTaskKind =
			typeof input.taskKind === "string" && input.taskKind.trim()
				? input.taskKind.trim()
				: typeof (input.result as any)?.kind === "string" &&
						(input.result as any).kind.trim()
					? (input.result as any).kind.trim()
					: "";
		if (resolvedTaskKind) {
			const resolvedModelKey = (() => {
				const raw: any = input.result?.raw as any;
				const candidates = [
					raw?.model,
					raw?.modelKey,
					raw?.model_key,
					raw?.response?.model,
					raw?.response?.modelKey,
					raw?.response?.model_key,
				];
				for (const v of candidates) {
					if (typeof v === "string" && v.trim()) return v.trim();
				}
				return null;
			})();
			const amount = await resolveTeamCreditsCostForTask(c, {
				taskKind: resolvedTaskKind,
				modelKey: resolvedModelKey || undefined,
			});

			// Team credits: reserved at submit time; settle/release when task ends.
			if (input.result.status === "succeeded") {
				await settleTeamCreditsOnSuccess(c, input.userId, {
					taskId,
					taskKind: resolvedTaskKind,
					amount,
					vendor: vendorKey,
					modelKey: resolvedModelKey,
				});
			} else if (input.result.status === "failed") {
				await releaseTeamCreditsOnFailure(c, input.userId, {
					taskId,
					taskKind: resolvedTaskKind,
					vendor: vendorKey,
					modelKey: resolvedModelKey,
				});
			}
		}
	}
}

function decodeBase64ToBytes(base64: string): Uint8Array {
	const cleaned = (base64 || "").trim();
	if (!cleaned) return new Uint8Array(0);
	const binary = atob(cleaned);
	const bytes = new Uint8Array(binary.length);
	for (let i = 0; i < binary.length; i += 1) {
		bytes[i] = binary.charCodeAt(i);
	}
	return bytes;
}

function detectImageExtensionFromMimeType(contentType: string): string {
	const ct = (contentType || "").toLowerCase();
	if (ct === "image/png") return "png";
	if (ct === "image/jpeg") return "jpg";
	if (ct === "image/webp") return "webp";
	if (ct === "image/gif") return "gif";
	return "bin";
}

function buildInlineAssetR2Key(userId: string, ext: string, prefix: string): string {
	const safeUser = (userId || "anon").replace(/[^a-zA-Z0-9_-]/g, "_");
	const date = new Date();
	const datePrefix = `${date.getUTCFullYear()}${String(
		date.getUTCMonth() + 1,
	).padStart(2, "0")}${String(date.getUTCDate()).padStart(2, "0")}`;
	const random = crypto.randomUUID();
	const dir = prefix ? prefix.replace(/^\/+|\/+$/g, "") : "gen";
	return `${dir}/${safeUser}/${datePrefix}/${random}.${ext || "bin"}`;
}

async function uploadInlineImageToR2(options: {
	c: AppContext;
	userId: string;
	mimeType: string;
	base64: string;
	prefix?: string;
}): Promise<string> {
	const { c, userId, mimeType, base64 } = options;
	const rustfs = resolveRustfsConfig(c.env);
	const bucket = (c.env as any).R2_ASSETS as R2Bucket | undefined;
	if (!rustfs && !bucket) {
		throw new AppError("OSS storage is not configured", {
			status: 500,
			code: "oss_not_configured",
			details: { binding: "R2_ASSETS" },
		});
	}

	const ext = detectImageExtensionFromMimeType(mimeType);
	const key = buildInlineAssetR2Key(userId, ext, options.prefix || "gen/images");
	const bytes = decodeBase64ToBytes(base64);
	if (rustfs) {
		const client = createRustfsClient(c.env);
		await client.send(
			new PutObjectCommand({
				Bucket: rustfs.bucket,
				Key: key,
				Body: bytes,
				ContentType: mimeType || "application/octet-stream",
			}),
		);
	} else {
		await bucket!.put(key, bytes, {
			httpMetadata: {
				contentType: mimeType || "application/octet-stream",
			},
		});
	}

	const publicBase = resolvePublicAssetBaseUrl(c).trim().replace(/\/+$/, "");
	return publicBase ? `${publicBase}/${key}` : `/${key}`;
}

function normalizeVendorKey(vendor: string): string {
	const v = (vendor || "").trim().toLowerCase();
	// Backward/alias compatibility: treat "google" as Gemini.
	if (v === "google") return "gemini";
	// Alias: Hailuo is MiniMax video.
	if (v === "hailuo") return "minimax";
	return v;
}

function extractChannelVendor(
	vendorKey: string,
): "grsai" | "comfly" | "apimart" | "yunwu" | null {
	const v = normalizeVendorKey(vendorKey);
	if (!v) return null;
	if (v === "apimart" || v.startsWith("apimart-") || v.startsWith("apimart:")) {
		return "apimart";
	}
	if (v === "comfly" || v.startsWith("comfly-") || v.startsWith("comfly:")) {
		return "comfly";
	}
	if (v === "grsai" || v.startsWith("grsai-") || v.startsWith("grsai:")) {
		return "grsai";
	}
	if (v === "yunwu" || v.startsWith("yunwu-") || v.startsWith("yunwu:")) {
		return "yunwu";
	}
	return null;
}

function isGrsaiBaseUrl(url: string): boolean {
	const val = url.toLowerCase();
	// New Sora2API/GRSAI protocol uses chat/completions for image/character.
	// Treat both grsai and sora2api domains as the new protocol base.
	return val.includes("grsai") || val.includes("sora2api");
}

function isApimartBaseUrl(url: string): boolean {
	const val = (url || "").toLowerCase();
	return val.includes("apimart.ai");
}

function isYunwuBaseUrl(url: string): boolean {
	const val = (url || "").toLowerCase();
	return val.includes("yunwu.ai");
}

function normalizeYunwuBaseUrl(url: string): string {
	const normalized = normalizeBaseUrl(url);
	return normalized.replace(/\/v1$/i, "");
}

function normalizeApimartBaseUrl(url: string): string {
	const normalized = normalizeBaseUrl(url);
	return normalized.replace(/\/v1$/i, "");
}

function expandProxyVendorKeys(vendor: string): string[] {
	const v = normalizeVendorKey(vendor);
	const keys = [v];
	// 兼容历史配置：面板里使用 "sora" 作为代理目标，但任务里使用 "sora2api"
	if (v === "sora2api") {
		keys.push("sora");
	}
	// 兼容别名：hailuo -> minimax
	if (v === "minimax") {
		keys.push("hailuo");
	}
	return Array.from(new Set(keys));
}

async function resolveProxyForVendor(
	c: AppContext,
	userId: string,
	vendor: string,
): Promise<ProxyProviderRow | null> {
	const keys = expandProxyVendorKeys(vendor);

	// 1) Direct match on vendor (for legacy configs)
	const direct: ProxyProviderRow[] = [];
	for (const key of keys) {
		const res = await c.env.DB.prepare(
			`SELECT * FROM proxy_providers
     WHERE owner_id = ? AND vendor = ? AND enabled = 1`,
		)
			.bind(userId, key)
			.all<ProxyProviderRow>();
		if (res.results?.length) {
			direct.push(...res.results);
		}
	}

	// 2) Match via enabled_vendors JSON (recommended)
	const viaEnabled: ProxyProviderRow[] = [];
	for (const key of keys) {
		const res = await c.env.DB.prepare(
			`SELECT * FROM proxy_providers
     WHERE owner_id = ? AND enabled = 1
       AND enabled_vendors IS NOT NULL
       AND enabled_vendors LIKE ?`,
		)
			.bind(userId, `%"${key}"%`)
			.all<ProxyProviderRow>();
		if (res.results?.length) {
			viaEnabled.push(...res.results);
		}
	}

	const all: ProxyProviderRow[] = [];
	for (const row of direct) {
		all.push(row);
	}
	for (const row of viaEnabled) {
		if (!all.find((r) => r.id === row.id)) {
			all.push(row);
		}
	}
	if (!all.length) return null;

	const readRoutingTaskKind = (): string | null => {
		try {
			const kind = c.get("routingTaskKind");
			return typeof kind === "string" && kind.trim() ? kind.trim() : null;
		} catch {
			return null;
		}
	};

	const readProxyDisabled = (): boolean => {
		try {
			return c.get("proxyDisabled") === true;
		} catch {
			return false;
		}
	};

	const readProxyVendorHint = (): string | null => {
		try {
			const hint = c.get("proxyVendorHint");
			return typeof hint === "string" && hint.trim()
				? hint.trim().toLowerCase()
				: null;
		} catch {
			return null;
		}
	};

	const isPublicApiRequest = (): boolean => {
		try {
			const apiKeyId = c.get("apiKeyId");
			return typeof apiKeyId === "string" && !!apiKeyId.trim();
		} catch {
			return false;
		}
	};

	const parseEpoch = (iso?: string | null) => {
		if (!iso || typeof iso !== "string") return 0;
		const t = Date.parse(iso);
		return Number.isFinite(t) ? t : 0;
	};

	const proxyVendorHint = readProxyVendorHint();
	const candidates = (() => {
		// Public API calls: ignore misconfigured proxies and fall back to direct providers.
		if (!isPublicApiRequest()) return all;
		const eligible = all.filter((p) => {
			const baseUrl = normalizeBaseUrl((p as any).base_url);
			const apiKey = typeof (p as any).api_key === "string" ? (p as any).api_key.trim() : "";
			return !!baseUrl && !!apiKey;
		});
		return eligible;
	})();
	if (!candidates.length) return null;

	if (proxyVendorHint) {
		const matched = candidates.find(
			(p) => (p.vendor || "").trim().toLowerCase() === proxyVendorHint,
		);
		if (matched) return matched;
	}

	// Public API: prefer higher-success proxies when multiple are enabled.
	if (isPublicApiRequest() && candidates.length > 1 && !readProxyDisabled()) {
		const taskKind = readRoutingTaskKind();
		const isVideoTaskKind =
			taskKind === "text_to_video" || taskKind === "image_to_video";
		const sinceIso = !isVideoTaskKind
			? new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
			: null;

		const scoreProxy = async (proxyVendor: string) => {
			const vkey = (proxyVendor || "").trim().toLowerCase();
			if (!vkey) {
				return {
					vendor: proxyVendor,
					success: 0,
					total: 0,
					rate: 0,
					avgMs: Number.POSITIVE_INFINITY,
				};
			}
			try {
				await ensureVendorCallLogsSchema(c.env.DB);
				const where: string[] = [
					"user_id = ?",
					"vendor = ?",
					"status IN ('succeeded','failed')",
					"finished_at IS NOT NULL",
				];
				if (taskKind) {
					where.push("task_kind = ?");
				}
				if (sinceIso) {
					where.push("finished_at >= ?");
				}
				const bindings: unknown[] = [
					userId,
					vkey,
					...(taskKind ? [taskKind] : []),
					...(sinceIso ? [sinceIso] : []),
				];
				const row = await c.env.DB.prepare(
					`
            SELECT
              COUNT(1) AS total,
              SUM(CASE WHEN status = 'succeeded' THEN 1 ELSE 0 END) AS success,
              AVG(CASE WHEN status = 'succeeded' THEN duration_ms ELSE NULL END) AS avg_ms
            FROM vendor_api_call_logs
            WHERE ${where.join(" AND ")}
          `,
				)
					.bind(...bindings)
					.first<any>();
				const total = Number(row?.total ?? 0) || 0;
				const success = Number(row?.success ?? 0) || 0;
				// Laplace smoothing to avoid 0/0 and reduce cold-start noise
				const rate = (success + 1) / (total + 2);
				const avgRaw = Number(row?.avg_ms);
				const avgMs =
					Number.isFinite(avgRaw) && avgRaw >= 0
						? avgRaw
						: Number.POSITIVE_INFINITY;
				return { vendor: proxyVendor, success, total, rate, avgMs };
			} catch {
				return {
					vendor: proxyVendor,
					success: 0,
					total: 0,
					rate: 0,
					avgMs: Number.POSITIVE_INFINITY,
				};
			}
		};

		const scored = await Promise.all(
			candidates.map(async (p) => {
				const stat = await scoreProxy(p.vendor);
				return { proxy: p, ...stat };
			}),
		);

		if (isVideoTaskKind) {
			const MIN_CALLS_PER_VENDOR = 100;
			const isWarm = scored.every((s) => s.total >= MIN_CALLS_PER_VENDOR);

			const randomInt = (maxExclusive: number) => {
				const max = Math.max(0, Math.floor(maxExclusive));
				if (max <= 1) return 0;
				const buf = new Uint32Array(1);
				crypto.getRandomValues(buf);
				return buf[0]! % max;
			};

			if (!isWarm) {
				const idx = randomInt(candidates.length);
				return candidates[idx]!;
			}

			const best = scored.sort((a, b) => {
				if (b.rate !== a.rate) return b.rate - a.rate;
				if (a.avgMs !== b.avgMs) return a.avgMs - b.avgMs;
				if (b.total !== a.total) return b.total - a.total;
				const bt = parseEpoch(b.proxy.updated_at) || parseEpoch(b.proxy.created_at);
				const at = parseEpoch(a.proxy.updated_at) || parseEpoch(a.proxy.created_at);
				return bt - at;
			})[0];
			if (best?.proxy) return best.proxy;
		} else {
			const best = scored.sort((a, b) => {
				if (b.rate !== a.rate) return b.rate - a.rate;
				if (b.total !== a.total) return b.total - a.total;
				const bt = parseEpoch(b.proxy.updated_at) || parseEpoch(b.proxy.created_at);
				const at = parseEpoch(a.proxy.updated_at) || parseEpoch(a.proxy.created_at);
				return bt - at;
			})[0];
			if (best?.proxy) return best.proxy;
		}
	}

	// Default: prefer most recently updated proxy config to make vendor switching predictable
	return [...candidates].sort((a, b) => {
		const bt = parseEpoch(b.updated_at) || parseEpoch(b.created_at);
		const at = parseEpoch(a.updated_at) || parseEpoch(a.created_at);
		return bt - at;
	})[0]!;
}

export async function resolveVendorContext(
	c: AppContext,
	userId: string,
	vendor: string,
): Promise<VendorContext> {
	const v = normalizeVendorKey(vendor);

	// 1) Try user-level proxy config (proxy_providers + enabled_vendors)
	const proxyDisabled = (() => {
		try {
			return c.get("proxyDisabled") === true;
		} catch {
			return false;
		}
	})();
	const proxy = proxyDisabled ? null : await resolveProxyForVendor(c, userId, v);
	const hasUserProxy = !!(proxy && proxy.enabled === 1);

	if (proxy && proxy.enabled === 1) {
		const baseUrl = normalizeBaseUrl(proxy.base_url);
		const apiKey = (proxy.api_key || "").trim();
		if (!baseUrl || !apiKey) {
			throw new AppError("Proxy for vendor is misconfigured", {
				status: 400,
				code: "proxy_misconfigured",
			});
		}
		return { baseUrl, apiKey, viaProxyVendor: proxy.vendor };
	}

	// 2) Fallback to model_providers + model_tokens（含跨用户共享 Token）
	const providers = await c.env.DB.prepare(
		`SELECT * FROM model_providers WHERE owner_id = ? AND vendor = ? ORDER BY created_at ASC`,
	)
		.bind(userId, v)
		.all<ProviderRow>()
		.then((r) => r.results || []);

	let provider: ProviderRow | null = providers[0] ?? null;
	let sharedTokenProvider: ProviderRow | null = null;
	let apiKey = "";

	const envAny = c.env as any;
	const envSora2ApiKey =
		(v === "sora2api" || v === "grsai") &&
		typeof envAny.SORA2API_API_KEY === "string" &&
		envAny.SORA2API_API_KEY.trim()
			? (envAny.SORA2API_API_KEY as string).trim()
			: "";
	const resolveEnvSora2Base = () =>
		(typeof envAny.SORA2API_BASE_URL === "string" && envAny.SORA2API_BASE_URL) ||
		(typeof envAny.SORA2API_BASE === "string" && envAny.SORA2API_BASE) ||
		"http://localhost:8000";
	const envSora2Base = normalizeBaseUrl(resolveEnvSora2Base());
	const envSora2BaseIsLocal =
		!!envSora2Base &&
		/^(https?:\/\/)?(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?$/i.test(envSora2Base);
	let userConfigured = hasUserProxy;
	let preferEnvSora2Base = false;

	if (requiresApiKeyForVendor(v)) {
		let token: TokenRow | null = null;

		// 2.1 优先使用当前用户在该 Provider 下的 Token（自己配置优先）
		if (provider) {
			const ownedRows = await c.env.DB.prepare(
				`SELECT * FROM model_tokens
         WHERE provider_id = ? AND user_id = ? AND enabled = 1
         ORDER BY created_at ASC LIMIT 1`,
			)
				.bind(provider.id, userId)
				.all<TokenRow>();
			token = (ownedRows.results || [])[0] ?? null;

			// 2.2 若没有自己的 Token，尝试该 Provider 下的共享 Token
			if (!token) {
				const nowIso = new Date().toISOString();
				const sharedRows = await c.env.DB.prepare(
					`SELECT * FROM model_tokens
           WHERE provider_id = ? AND shared = 1 AND enabled = 1
             AND (shared_disabled_until IS NULL OR shared_disabled_until < ?)
           ORDER BY updated_at ASC LIMIT 1`,
				)
					.bind(provider.id, nowIso)
					.all<TokenRow>();
				token = (sharedRows.results || [])[0] ?? null;
			}

			if (token && typeof token.secret_token === "string") {
				apiKey = token.secret_token.trim();
				userConfigured = true;
			}
		}

		// 2.3 System-level vendor API key（admin 全局配置，优先于 env/shared token）
		if (!apiKey && !userConfigured) {
			const sys = await resolveSystemVendorApiKeyContext(c, v);
			if (sys && sys.enabled && sys.vendorEnabled) {
				let baseUrl =
					normalizeBaseUrl(sys.baseUrlHint || "") ||
					(v === "sora2api" || v === "grsai" ? envSora2Base : "") ||
					normalizeBaseUrl(defaultBaseUrlForVendor(v) || "");
				if (!baseUrl) {
					throw new AppError(`No base URL configured for vendor ${v}`, {
						status: 400,
						code: "base_url_missing",
					});
				}
				return { baseUrl, apiKey: sys.apiKey };
			}
		}

		// 2.4 对于 sora2api/grsai，只有当用户没有任何 Token/Proxy 配置时才允许使用 Env 级别兜底
		if (!apiKey && envSora2ApiKey && !userConfigured) {
			apiKey = envSora2ApiKey;
			preferEnvSora2Base = true;
		}

		// 2.5 仍未拿到，则从任意用户的共享 Token 中为该 vendor 选择一个（全局共享池）
		if (!apiKey && !userConfigured) {
			const shared = await findSharedTokenForVendor(c, v);
			if (shared && typeof shared.token.secret_token === "string") {
				apiKey = shared.token.secret_token.trim();
				sharedTokenProvider = shared.provider;
				userConfigured = true;
			}
		}

		if (!apiKey) {
			throw new AppError(`No API key configured for vendor ${v}`, {
				status: 400,
				code: "api_key_missing",
			});
		}
	}

	// 2.3b System-level vendor API key（admin 全局配置；支持动态 vendor key）
	// For vendors outside the hard-coded list, allow running purely based on model-catalog vendor config.
	if (!requiresApiKeyForVendor(v) && !userConfigured) {
		const sys = await resolveSystemVendorApiKeyContext(c, v);
		if (sys && sys.enabled && sys.vendorEnabled) {
			const baseUrl = normalizeBaseUrl(sys.baseUrlHint || "");
			if (!baseUrl) {
				throw new AppError(`No base URL configured for vendor ${v}`, {
					status: 400,
					code: "base_url_missing",
				});
			}
			return { baseUrl, apiKey: sys.apiKey };
		}
	}

	// 2.6 若用户自己没有 Provider，但通过共享 Token 找到了 Provider，则使用该 Provider
	if (!provider && sharedTokenProvider) {
		provider = sharedTokenProvider;
	}

	// 2.7 provider 仍不存在时，对于 sora2api/grsai 允许完全依赖 Env 级别配置；其他 vendor 报错
	if (!provider) {
		if ((v === "sora2api" || v === "grsai") && envSora2ApiKey && !userConfigured) {
			const baseUrl = normalizeBaseUrl(resolveEnvSora2Base());
			if (!baseUrl) {
				throw new AppError(`No base URL configured for vendor ${v}`, {
					status: 400,
					code: "base_url_missing",
				});
			}
			return { baseUrl, apiKey: envSora2ApiKey || apiKey };
		}

		throw new AppError(`No provider configured for vendor ${v}`, {
			status: 400,
			code: "provider_not_configured",
		});
	}

	// 2.8 解析 baseUrl：优先 Provider.base_url，其次 shared_base_url，其次系统级 vendor base_url_hint / 默认值
	let baseUrl = normalizeBaseUrl(
		preferEnvSora2Base
			? ""
			: provider.base_url || (await resolveSharedBaseUrl(c, v)) || "",
	);

	if (!baseUrl) {
		if (v === "veo") {
			baseUrl = normalizeBaseUrl("https://api.grsai.com");
		} else if (v === "sora2api" || v === "grsai") {
			baseUrl = envSora2Base;
		}
	}

	if (!baseUrl) {
		const hint = await resolveSystemVendorBaseUrlHint(c, v);
		baseUrl =
			normalizeBaseUrl(hint || "") || normalizeBaseUrl(defaultBaseUrlForVendor(v) || "");
	}

	// Dev-friendly override: when SORA2API_BASE_URL points to localhost,
	// prefer it over a non-local provider/proxy base to avoid self-recursion.
	if (v === "sora2api" && envSora2BaseIsLocal && envSora2Base && envSora2Base !== baseUrl) {
		baseUrl = envSora2Base;
	}

	if (!baseUrl) {
		throw new AppError(`No base URL configured for vendor ${v}`, {
			status: 400,
			code: "base_url_missing",
		});
	}

	return { baseUrl, apiKey };
}

async function resolveSharedBaseUrl(
	c: AppContext,
	vendor: string,
): Promise<string | null> {
	const row = await c.env.DB.prepare(
		`SELECT base_url FROM model_providers
     WHERE vendor = ? AND shared_base_url = 1 AND base_url IS NOT NULL
     ORDER BY updated_at DESC LIMIT 1`,
	)
		.bind(vendor)
		.first<{ base_url: string | null }>();
	return row?.base_url ?? null;
}

type SharedTokenWithProvider = {
	token: TokenRow;
	provider: ProviderRow;
};

async function findSharedTokenForVendor(
	c: AppContext,
	vendor: string,
): Promise<SharedTokenWithProvider | null> {
	const nowIso = new Date().toISOString();
	const row = await c.env.DB.prepare(
		`SELECT
       t.id,
       t.provider_id,
       t.label,
       t.secret_token,
       t.user_agent,
       t.user_id,
       t.enabled,
       t.shared,
       t.shared_failure_count,
       t.shared_last_failure_at,
       t.shared_disabled_until,
       t.created_at,
       t.updated_at,
       p.id   AS p_id,
       p.name AS p_name,
       p.vendor AS p_vendor,
       p.base_url AS p_base_url,
       p.shared_base_url AS p_shared_base_url,
       p.owner_id AS p_owner_id,
       p.created_at AS p_created_at,
       p.updated_at AS p_updated_at
     FROM model_tokens t
     JOIN model_providers p ON p.id = t.provider_id
     WHERE t.shared = 1
       AND t.enabled = 1
       AND p.vendor = ?
       AND (t.shared_disabled_until IS NULL OR t.shared_disabled_until < ?)
     ORDER BY t.updated_at ASC
     LIMIT 1`,
	)
		.bind(vendor, nowIso)
		.first<any>();

	if (!row) return null;

	const token: TokenRow = {
		id: row.id,
		provider_id: row.provider_id,
		label: row.label,
		secret_token: row.secret_token,
		user_agent: row.user_agent,
		user_id: row.user_id,
		enabled: row.enabled,
		shared: row.shared,
		shared_failure_count: row.shared_failure_count,
		shared_last_failure_at: row.shared_last_failure_at,
		shared_disabled_until: row.shared_disabled_until,
		created_at: row.created_at,
		updated_at: row.updated_at,
	};

	const provider: ProviderRow = {
		id: row.p_id,
		name: row.p_name,
		vendor: row.p_vendor,
		base_url: row.p_base_url,
		shared_base_url: row.p_shared_base_url,
		owner_id: row.p_owner_id,
		created_at: row.p_created_at,
		updated_at: row.p_updated_at,
	};

	return { token, provider };
}

function requiresApiKeyForVendor(vendor: string): boolean {
	const v = normalizeVendorKey(vendor);
	return (
		v === "gemini" ||
		v === "qwen" ||
		v === "anthropic" ||
		v === "openai" ||
		v === "apimart" ||
		v === "veo" ||
		v === "sora2api" ||
		v === "grsai" ||
		v === "minimax"
	);
}

function defaultBaseUrlForVendor(vendor: string): string | null {
	const v = normalizeVendorKey(vendor);
	if (v === "openai") return "https://api.openai.com";
	if (v === "gemini") return "https://generativelanguage.googleapis.com";
	if (v === "qwen") return "https://dashscope.aliyuncs.com";
	if (v === "anthropic") return "https://api.anthropic.com/v1";
	if (v === "apimart") return "https://api.apimart.ai";
	if (v === "veo") return "https://api.grsai.com";
	return null;
}

type SystemVendorApiKeyContext = {
	vendorKey: string;
	apiKey: string;
	enabled: boolean;
	vendorEnabled: boolean;
	baseUrlHint: string | null;
};

async function resolveSystemVendorApiKeyContext(
	c: AppContext,
	vendorKey: string,
): Promise<SystemVendorApiKeyContext | null> {
	try {
		await ensureModelCatalogSchema(c.env.DB);
		const row = await c.env.DB.prepare(
			`SELECT
         k.vendor_key AS vendor_key,
         k.api_key AS api_key,
         k.enabled AS key_enabled,
         v.enabled AS vendor_enabled,
         v.base_url_hint AS base_url_hint
       FROM model_catalog_vendor_api_keys k
       JOIN model_catalog_vendors v ON v.key = k.vendor_key
       WHERE k.vendor_key = ?
       LIMIT 1`,
		)
			.bind(vendorKey)
			.first<any>();
		if (!row) return null;
		const apiKey = typeof row.api_key === "string" ? row.api_key.trim() : "";
		if (!apiKey) return null;
		const enabled = Number(row.key_enabled ?? 1) !== 0;
		const vendorEnabled = Number(row.vendor_enabled ?? 1) !== 0;
		const baseUrlHint =
			typeof row.base_url_hint === "string" && row.base_url_hint.trim()
				? row.base_url_hint.trim()
				: null;
		return {
			vendorKey,
			apiKey,
			enabled,
			vendorEnabled,
			baseUrlHint,
		};
	} catch {
		return null;
	}
}

async function resolveSystemVendorBaseUrlHint(
	c: AppContext,
	vendorKey: string,
): Promise<string | null> {
	try {
		await ensureModelCatalogSchema(c.env.DB);
		const row = await c.env.DB.prepare(
			`SELECT base_url_hint, enabled FROM model_catalog_vendors WHERE key = ? LIMIT 1`,
		)
			.bind(vendorKey)
			.first<any>();
		if (!row) return null;
		if (Number(row.enabled ?? 1) === 0) return null;
		const hint =
			typeof row.base_url_hint === "string" ? row.base_url_hint.trim() : "";
		return hint ? hint : null;
	} catch {
		return null;
	}
}

// ---------- VEO ----------

function normalizeVeoModelKey(modelKey?: string | null): string {
	if (!modelKey) return "veo3.1-fast";
	const trimmed = modelKey.trim();
	if (!trimmed) return "veo3.1-fast";
	return trimmed.startsWith("models/") ? trimmed.slice(7) : trimmed;
}

function clampProgress(value?: number | null): number | undefined {
	if (typeof value !== "number" || Number.isNaN(value)) return undefined;
	return Math.max(0, Math.min(100, value));
}

function mapTaskStatus(status?: string | null): "running" | "succeeded" | "failed" {
	const normalized = typeof status === "string" ? status.toLowerCase() : null;
	if (normalized === "failed") return "failed";
	if (normalized === "succeeded") return "succeeded";
	return "running";
}

function extractVeoResultPayload(body: any): any {
	if (!body) return null;
	if (typeof body === "object" && body.data) return body.data;
	return body;
}

type ComflyGenerationStatus =
	| "NOT_START"
	| "SUBMITTED"
	| "QUEUED"
	| "IN_PROGRESS"
	| "SUCCESS"
	| "FAILURE";

function normalizeComflyStatus(value: unknown): ComflyGenerationStatus | null {
	if (typeof value !== "string") return null;
	const upper = value.trim().toUpperCase();
	if (
		upper === "NOT_START" ||
		upper === "SUBMITTED" ||
		upper === "QUEUED" ||
		upper === "IN_PROGRESS" ||
		upper === "SUCCESS" ||
		upper === "FAILURE"
	) {
		return upper as ComflyGenerationStatus;
	}
	return null;
}

function mapComflyStatusToTaskStatus(status: ComflyGenerationStatus | null): TaskStatus {
	if (status === "SUCCESS") return "succeeded";
	if (status === "FAILURE") return "failed";
	if (status === "IN_PROGRESS") return "running";
	return "queued";
}

function parseComflyProgress(value: unknown): number | undefined {
	if (typeof value === "number" && Number.isFinite(value)) {
		return clampProgress(value);
	}
	if (typeof value !== "string") return undefined;
	const raw = value.trim();
	if (!raw) return undefined;
	const percentMatch = raw.match(/^(\d+(?:\.\d+)?)\s*%$/);
	if (percentMatch) {
		const num = Number(percentMatch[1]);
		return clampProgress(Number.isFinite(num) ? num : undefined);
	}
	const num = Number(raw);
	return clampProgress(Number.isFinite(num) ? num : undefined);
}

	function extractComflyOutputUrls(payload: any): string[] {
		const urls: string[] = [];
		const add = (v: any) => {
			if (typeof v === "string" && v.trim()) urls.push(v.trim());
		};
	if (payload?.data) {
		const data = payload.data;
		if (Array.isArray(data?.outputs)) {
			data.outputs.forEach(add);
		}
		add(data?.output);
	}
	if (Array.isArray(payload?.outputs)) {
		payload.outputs.forEach(add);
	}
	add(payload?.output);
		return Array.from(new Set(urls));
	}

	function normalizeSora2OfficialStatus(value: unknown): TaskStatus | null {
		if (typeof value !== "string") return null;
		const normalized = value.trim().toLowerCase();
		if (!normalized) return null;
		if (normalized === "completed" || normalized === "succeeded" || normalized === "success") {
			return "succeeded";
		}
		if (normalized === "failed" || normalized === "failure" || normalized === "error") {
			return "failed";
		}
		if (normalized === "queued" || normalized === "in_progress" || normalized === "running" || normalized === "processing") {
			return "running";
		}
		return null;
	}

	function extractSora2OfficialVideoUrl(payload: any): string | null {
		const pick = (v: any): string | null =>
			typeof v === "string" && v.trim() ? v.trim() : null;
		const fromObjectUrl = (v: any): string | null => {
			if (!v || typeof v !== "object") return null;
			return pick((v as any).url) || null;
		};
		return (
			pick(payload?.video_url) ||
			fromObjectUrl(payload?.video_url) ||
			pick(payload?.videoUrl) ||
			fromObjectUrl(payload?.videoUrl) ||
			pick(payload?.url) ||
			pick(payload?.data?.video_url) ||
			pick(payload?.data?.url) ||
			(Array.isArray(payload?.results) && payload.results.length
				? pick(payload.results[0]?.url) ||
					pick(payload.results[0]?.video_url) ||
					pick(payload.results[0]?.videoUrl)
				: null) ||
			null
		);
	}

		function normalizeComflyNanoBananaModelKey(modelKey?: string | null): string {
			const trimmed = (modelKey || "").trim();
			if (!trimmed) return "nano-banana";
			const bare = trimmed.startsWith("models/") ? trimmed.slice(7) : trimmed;
			const lower = bare.toLowerCase();
			// Comfly 文档：nano-banana 为推荐对接；nano-banana-hd 为 4K 高清版。
			if (lower === "nano-banana-pro") return "nano-banana-hd";
			if (lower === "nano-banana-fast") return "nano-banana";
			return bare;
		}

	async function createComflyVideoTask(
		c: AppContext,
		userId: string,
		req: TaskRequestDto,
	ctx: VendorContext,
	model: string,
	input: {
		aspectRatio?: string | null;
		duration?: number | string | null;
		images?: string[];
		videos?: string[];
		hd?: boolean | null;
		notifyHook?: string | null;
		private?: boolean | null;
		watermark?: boolean | null;
		resolution?: string | null;
		size?: string | null;
	},
	progressCtx: ProgressContext | null,
): Promise<TaskResult> {
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = ctx.apiKey.trim();
	if (!baseUrl || !apiKey) {
		throw new AppError("comfly 代理未配置 Host 或 API Key", {
			status: 400,
			code: "comfly_proxy_misconfigured",
		});
	}

	const body: Record<string, any> = {
		prompt: req.prompt,
		model,
	};
	if (typeof input.duration === "number" && Number.isFinite(input.duration)) {
		body.duration = input.duration;
	} else if (typeof input.duration === "string" && input.duration.trim()) {
		body.duration = input.duration.trim();
	}
	if (typeof input.aspectRatio === "string" && input.aspectRatio.trim()) {
		body.aspect_ratio = input.aspectRatio.trim();
	}
	if (typeof input.hd === "boolean") {
		body.hd = input.hd;
	}
	if (typeof input.notifyHook === "string" && input.notifyHook.trim()) {
		body.notify_hook = input.notifyHook.trim();
	}
	if (typeof input.private === "boolean") {
		body.private = input.private;
	}
	if (typeof input.size === "string" && input.size.trim()) {
		body.size = input.size.trim();
	}
	if (typeof input.resolution === "string" && input.resolution.trim()) {
		body.resolution = input.resolution.trim();
	}
	if (typeof input.watermark === "boolean") {
		body.watermark = input.watermark;
	}
	if (Array.isArray(input.images) && input.images.length) {
		body.images = input.images;
	}
	if (Array.isArray(input.videos) && input.videos.length) {
		body.videos = input.videos;
	}

	let res: Response;
	let data: any = null;
	try {
		emitProgress(userId, progressCtx, { status: "running", progress: 5 });
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl}/v2/videos/generations`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "comfly:videos:create" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("comfly 视频任务创建失败", {
			status: 502,
			code: "comfly_request_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error || data.msg)) ||
			`comfly 视频任务创建失败：${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "comfly_request_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	const taskId =
		typeof data?.task_id === "string" && data.task_id.trim()
			? data.task_id.trim()
			: null;
	if (!taskId) {
		throw new AppError("comfly API 未返回 task_id", {
			status: 502,
			code: "comfly_task_id_missing",
			details: { upstreamData: data ?? null },
		});
	}

	emitProgress(userId, progressCtx, {
		status: "running",
		progress: 10,
		taskId,
		raw: data ?? null,
	});

	return TaskResultSchema.parse({
		id: taskId,
		kind: req.kind,
		status: "running",
		assets: [],
		raw: {
			provider: "comfly",
			model,
			taskId,
			response: data ?? null,
			},
		});
	}

	async function createComflySora2VideoTask(
		c: AppContext,
		userId: string,
		req: TaskRequestDto,
		ctx: VendorContext,
		input: {
			model: string;
			size?: string | null;
			seconds?: number | null;
			watermark?: boolean | null;
			inputReferenceUrl?: string | null;
		},
		progressCtx: ProgressContext | null,
	): Promise<TaskResult> {
		const model = (input.model || "").trim() || "sora-2";
		const isProModel = model.toLowerCase() === "sora-2-pro";
		const extras = (req.extras || {}) as Record<string, any>;

		const aspectRatio = (() => {
			const fromExtras =
				(typeof extras.aspect_ratio === "string" &&
					extras.aspect_ratio.trim()) ||
				(typeof extras.aspectRatio === "string" &&
					extras.aspectRatio.trim()) ||
				"";
			if (fromExtras === "16:9" || fromExtras === "9:16") {
				return fromExtras;
			}
			const raw = typeof input.size === "string" ? input.size.trim() : "";
			if (!raw) return null;
			const match = raw.match(/^(\d+)\s*x\s*(\d+)$/i);
			if (!match) return null;
			const width = Number(match[1]);
			const height = Number(match[2]);
			if (!Number.isFinite(width) || !Number.isFinite(height)) return null;
			return width >= height ? "16:9" : "9:16";
		})();

		const duration = (() => {
			const seconds =
				typeof input.seconds === "number" && Number.isFinite(input.seconds)
					? Math.max(1, Math.floor(input.seconds))
					: 10;
			if (seconds <= 10) return "10";
			if (seconds <= 15) return "15";
			return isProModel ? "25" : "15";
		})();

		const images = (() => {
			const urls: string[] = [];
			const add = (v: any) => {
				if (typeof v === "string" && v.trim()) urls.push(v.trim());
			};
			if (Array.isArray(extras.images)) extras.images.forEach(add);
			if (Array.isArray(extras.urls)) extras.urls.forEach(add);
			add(extras.url);
			add(extras.firstFrameUrl);
			add(input.inputReferenceUrl);
			const deduped = Array.from(new Set(urls));
			return deduped.length ? deduped.slice(0, 8) : undefined;
		})();
		const hd =
			isProModel && typeof extras.hd === "boolean" ? extras.hd : null;
		const notifyHook =
			(typeof extras.notify_hook === "string" &&
				extras.notify_hook.trim()) ||
			(typeof extras.notifyHook === "string" && extras.notifyHook.trim()) ||
			null;
		const isPrivate =
			typeof extras.private === "boolean"
				? extras.private
				: typeof extras.isPrivate === "boolean"
					? extras.isPrivate
					: null;

		return createComflyVideoTask(
			c,
			userId,
			req,
			ctx,
			model,
			{
				aspectRatio,
				duration,
				images,
				hd,
				notifyHook,
				private: isPrivate,
				watermark: input.watermark ?? null,
			},
			progressCtx,
		);
	}

	async function fetchComflySora2VideoTaskResult(
		c: AppContext,
		userId: string,
		taskId: string,
		ctx: VendorContext,
		kind: TaskRequestDto["kind"],
	) {
		return fetchComflyVideoTaskResult(c, userId, taskId, ctx, kind, {
			metaVendor: "sora2api",
			throwOnFailed: false,
		});
	}

	async function fetchComflyVideoTaskResult(
		c: AppContext,
		userId: string,
		taskId: string,
	ctx: VendorContext,
	kind: TaskRequestDto["kind"],
	options?: { metaVendor?: string; throwOnFailed?: boolean },
) {
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = ctx.apiKey.trim();
	if (!baseUrl || !apiKey) {
		throw new AppError("comfly 代理未配置 Host 或 API Key", {
			status: 400,
			code: "comfly_proxy_misconfigured",
		});
	}

	let res: Response;
	let data: any = null;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl}/v2/videos/generations/${encodeURIComponent(taskId.trim())}`,
			{
				method: "GET",
				headers: {
					Authorization: `Bearer ${apiKey}`,
				},
			},
			{ tag: "comfly:videos:result" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("comfly 结果查询失败", {
			status: 502,
			code: "comfly_result_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	if (!res.ok) {
		const msg =
			(data && (data.message || data.error || data.msg)) ||
			`comfly result poll failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "comfly_result_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

		const status = normalizeComflyStatus(data?.status);
		const mappedStatus = mapComflyStatusToTaskStatus(status);
		const progress = parseComflyProgress(data?.progress);
		const metaVendor =
			typeof options?.metaVendor === "string" && options.metaVendor.trim()
				? options.metaVendor.trim()
				: "veo";
		const throwOnFailed = options?.throwOnFailed !== false;

		if (mappedStatus === "failed") {
			const reason =
				(typeof data?.fail_reason === "string" && data.fail_reason.trim()) ||
				(typeof data?.message === "string" && data.message.trim()) ||
				"comfly 视频任务失败";
			if (!throwOnFailed) {
				return TaskResultSchema.parse({
					id: taskId,
					kind,
					status: "failed",
					assets: [],
					raw: {
						provider: "comfly",
						vendor: metaVendor,
						model:
							typeof (data as any)?.model === "string"
								? (data as any).model
								: undefined,
						response: data ?? null,
						progress,
						error: reason,
						message: reason,
					},
				});
			}
			throw new AppError(reason, {
				status: 502,
				code: "comfly_result_failed",
				details: { upstreamData: data ?? null },
			});
		}

		if (mappedStatus !== "succeeded") {
			return TaskResultSchema.parse({
				id: taskId,
				kind,
				status: mappedStatus === "queued" ? "running" : mappedStatus,
				assets: [],
				raw: {
					provider: "comfly",
					vendor: metaVendor,
					model:
						typeof (data as any)?.model === "string"
							? (data as any).model
							: undefined,
					response: data ?? null,
					progress,
				},
			});
		}

	const urls = extractComflyOutputUrls(data);
	if (!urls.length) {
		return TaskResultSchema.parse({
			id: taskId,
			kind,
			status: "running",
			assets: [],
			raw: {
				provider: "comfly",
				vendor: metaVendor,
				model:
					typeof (data as any)?.model === "string"
						? (data as any).model
						: undefined,
				response: data ?? null,
				progress,
			},
		});
	}

	const assets = urls.map((url) =>
		TaskAssetSchema.parse({ type: "video", url, thumbnailUrl: null }),
	);

		let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		try {
			hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets,
				meta: {
					taskKind: kind,
					prompt:
						typeof (data as any)?.prompt === "string"
							? (data as any).prompt
							: null,
					vendor: metaVendor,
					modelKey:
						typeof (data as any)?.model === "string"
							? (data as any).model
							: undefined,
					taskId:
						(typeof (data as any)?.task_id === "string" &&
							(data as any).task_id) ||
						taskId,
				},
			});
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			return TaskResultSchema.parse({
				id:
					(typeof (data as any)?.task_id === "string" &&
						(data as any).task_id) ||
					taskId,
				kind,
				status: "running",
				assets: [],
				raw: {
					provider: "comfly",
					vendor: metaVendor,
					model:
						typeof (data as any)?.model === "string"
							? (data as any).model
							: undefined,
					response: data ?? null,
					progress,
					hosting: { status: "pending", message },
				},
			});
		}

		return TaskResultSchema.parse({
			id:
				(typeof (data as any)?.task_id === "string" &&
					(data as any).task_id) ||
				taskId,
			kind,
			status: "succeeded",
			assets: hostedAssets,
			raw: {
				provider: "comfly",
				vendor: metaVendor,
				model:
					typeof (data as any)?.model === "string"
						? (data as any).model
						: undefined,
				response: data ?? null,
			},
		});
	}

export async function runVeoVideoTask(
		c: AppContext,
		userId: string,
		req: TaskRequestDto,
	): Promise<TaskResult> {
		const extras = (req.extras || {}) as Record<string, any>;
		const model = normalizeVeoModelKey(
			(typeof extras.modelKey === "string" && extras.modelKey) ||
				(req.extras && (req.extras as any).modelKey) ||
				null,
		);
		const required = await resolveTeamCreditsCostForTask(c, {
			taskKind: req.kind,
			modelKey: model,
		});
		const progressCtx = extractProgressContext(req, "veo");

		// New: Veo models can be served via sora2api's OpenAI-compatible chat endpoint (model ids are veo_*)
		if (/^veo_/i.test(model)) {
			const reservation = await requireSufficientTeamCredits(c, userId, {
				required,
				taskKind: req.kind,
				vendor: "veo",
				modelKey: model,
			});
			emitProgress(userId, progressCtx, { status: "queued", progress: 0 });
			try {
				const result = await runSora2ApiChatCompletionsVideoTask(
					c,
					userId,
					req,
					{
						model,
						progressVendor: "veo",
					},
				);
				await bindReservationToTaskId(c, userId, reservation, result.id);
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: "veo",
					taskKind: req.kind,
					result,
				});
				return result;
			} catch (err) {
				return await releaseReservationOnThrow(c, userId, reservation, err);
			}
		}

		const ctx = await resolveVendorContext(c, userId, "veo");
		const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "https://api.grsai.com";
		const isApimartBase =
			isApimartBaseUrl(baseUrl) || ctx.viaProxyVendor === "apimart";
		const channelVendor: "grsai" | "comfly" | "apimart" | null =
			ctx.viaProxyVendor === "comfly"
				? "comfly"
				: isApimartBase
					? "apimart"
					: isGrsaiBaseUrl(baseUrl) || ctx.viaProxyVendor === "grsai"
						? "grsai"
						: null;
		const apiKey = ctx.apiKey.trim();
		if (!apiKey) {
			throw new AppError(isApimartBase ? "未配置 apimart API Key" : "未配置 Veo API Key", {
				status: 400,
				code: "veo_api_key_missing",
			});
		}

		const reservation = await requireSufficientTeamCredits(c, userId, {
			required,
			taskKind: req.kind,
			vendor: "veo",
			modelKey: model,
		});
		emitProgress(userId, progressCtx, { status: "queued", progress: 0 });

		try {
		const aspectRatio =
			typeof extras.aspectRatio === "string" && extras.aspectRatio.trim()
				? extras.aspectRatio.trim()
				: "16:9";

	const urls: string[] = [];
	const appendUrl = (value: any) => {
		if (typeof value === "string" && value.trim()) {
			urls.push(value.trim());
		}
	};
	if (Array.isArray(extras.urls)) extras.urls.forEach(appendUrl);
	if (Array.isArray(extras.referenceImages))
		extras.referenceImages.forEach(appendUrl);
	const referenceImages = Array.from(new Set(urls)).slice(0, 3);

	const firstFrameUrl =
		typeof extras.firstFrameUrl === "string" && extras.firstFrameUrl.trim()
			? extras.firstFrameUrl.trim()
			: undefined;
	const lastFrameUrl =
		typeof extras.lastFrameUrl === "string" && extras.lastFrameUrl.trim()
			? extras.lastFrameUrl.trim()
			: undefined;

		if (isApimartBase) {
			emitProgress(userId, progressCtx, { status: "running", progress: 5 });

			const durationSeconds = (() => {
				const raw =
					typeof extras.durationSeconds === "number"
						? extras.durationSeconds
						: typeof extras.duration === "number"
							? extras.duration
							: null;
				return typeof raw === "number" && Number.isFinite(raw) && raw > 0
					? raw
					: undefined;
			})();

			const imageUrls = (() => {
				const urls: string[] = [];
				const pushAll = (value: any) => {
					const arr = Array.isArray(value) ? value : [value];
					for (const item of arr) {
						if (typeof item === "string" && item.trim()) urls.push(item.trim());
					}
				};
				pushAll((extras as any).image_urls);
				pushAll((extras as any).imageUrls);
				pushAll((extras as any).urls);
				pushAll((extras as any).referenceImages);
				pushAll((extras as any).reference_images);
				if (firstFrameUrl) urls.push(firstFrameUrl);
				if (lastFrameUrl) urls.push(lastFrameUrl);
				return Array.from(new Set(urls)).slice(0, 14);
			})();

			const body: Record<string, any> = {
				model,
				prompt: req.prompt,
				aspect_ratio: aspectRatio,
				...(typeof durationSeconds === "number"
					? { duration: durationSeconds }
					: {}),
				...(typeof extras.private === "boolean" ? { private: extras.private } : {}),
				...(typeof extras.watermark === "boolean"
					? { watermark: extras.watermark }
					: {}),
				...(typeof extras.thumbnail === "boolean"
					? { thumbnail: extras.thumbnail }
					: {}),
				...(imageUrls.length ? { image_urls: imageUrls } : {}),
			};

			const data = await callJsonApi(
				c,
				`${normalizeApimartBaseUrl(baseUrl)}/v1/videos/generations`,
				{
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${apiKey}`,
					},
					body: JSON.stringify(body),
				},
				{ provider: "apimart" },
			);

			if (typeof data?.code === "number" && data.code !== 200) {
				throw new AppError(
					(data?.error?.message ||
						data?.message ||
						`apimart 视频生成失败: code ${data.code}`) as string,
					{
						status: 502,
						code: "apimart_request_failed",
						details: { upstreamData: data ?? null, requestBody: body },
					},
				);
			}

			const first = Array.isArray(data?.data) ? data.data[0] : null;
			const taskId =
				(typeof first?.task_id === "string" && first.task_id.trim()) ||
				(typeof first?.taskId === "string" && first.taskId.trim()) ||
				null;
			if (!taskId) {
				throw new AppError("apimart 未返回 task_id", {
					status: 502,
					code: "apimart_task_id_missing",
					details: { upstreamData: data ?? null, requestBody: body },
				});
			}

			emitProgress(userId, progressCtx, {
				status: "queued",
				progress: 10,
				taskId,
				raw: data ?? null,
			});

			{
				const nowIso = new Date().toISOString();
				try {
					await upsertVendorTaskRef(
						c.env.DB,
						userId,
						{ kind: "video", taskId: taskId.trim(), vendor: "apimart:veo" },
						nowIso,
					);
				} catch (err: any) {
					console.warn(
						"[vendor-task-refs] upsert apimart veo ref failed",
						err?.message || err,
					);
				}
			}

			const vendorForLog = `apimart-${model}`;
			const result = TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "queued",
				assets: [],
				raw: {
					provider: "apimart",
					model,
					taskId,
					status: "queued",
					request: body,
					response: data ?? null,
				},
			});
			await bindReservationToTaskId(c, userId, reservation, taskId);
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: "veo",
				taskKind: req.kind,
				result,
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind: req.kind,
				result,
			});
			if (channelVendor) {
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: channelVendor,
					taskKind: req.kind,
					result,
				});
			}
			return result;
		}

		if (ctx.viaProxyVendor === "comfly") {
			const images = (() => {
				if (firstFrameUrl) {
					const out = [firstFrameUrl];
					if (lastFrameUrl) out.push(lastFrameUrl);
					return out;
				}
				return referenceImages;
			})();
			const result = await createComflyVideoTask(
				c,
				userId,
				req,
				ctx,
				model,
				{
					aspectRatio,
					images: images.length ? images : undefined,
				},
				progressCtx,
			);
			{
				const nowIso = new Date().toISOString();
				try {
					await upsertVendorTaskRef(
						c.env.DB,
						userId,
						{ kind: "video", taskId: result.id, vendor: "comfly:veo" },
						nowIso,
					);
				} catch (err: any) {
					console.warn(
						"[vendor-task-refs] upsert comfly veo ref failed",
						err?.message || err,
					);
				}
			}
			await bindReservationToTaskId(c, userId, reservation, result.id);
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: "veo",
				taskKind: req.kind,
				result,
			});
			if (channelVendor) {
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: channelVendor,
					taskKind: req.kind,
					result,
				});
			}
			return result;
		}

	const body: Record<string, any> = {
		model,
		prompt: req.prompt,
		aspectRatio,
		webHook: "-1",
		shutProgress: extras.shutProgress === false ? false : true,
	};

	if (referenceImages.length) {
		body.urls = referenceImages;
	}
	if (firstFrameUrl) {
		body.firstFrameUrl = firstFrameUrl;
		if (lastFrameUrl) {
			body.lastFrameUrl = lastFrameUrl;
		}
	}

	let res: Response;
	let data: any = null;
	try {
		emitProgress(userId, progressCtx, { status: "running", progress: 5 });
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl}/v1/video/veo`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "veo:create" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("Veo 视频任务创建失败", {
			status: 502,
			code: "veo_request_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	if (res.status < 200 || res.status >= 300) {
		const msg =
			(data && (data.message || data.error || data.msg)) ||
			`Veo 视频任务创建失败：${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "veo_request_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	if (typeof data?.code === "number" && data.code !== 0) {
		const msg = data?.msg || data?.message || "Veo 视频任务创建失败";
		throw new AppError(msg, {
			status: 502,
			code: "veo_request_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	const payload = typeof data?.code === "number" ? data.data : data;
	const taskId = payload?.id;
	if (!taskId || typeof taskId !== "string" || !taskId.trim()) {
		throw new AppError("Veo API 未返回任务 ID", {
			status: 502,
			code: "veo_task_id_missing",
		});
	}

	emitProgress(userId, progressCtx, {
		status: "running",
		progress: 10,
		taskId,
		raw: payload,
	});

	// Worker 侧只做「创建任务 + 返回 running」，结果由 /tasks/veo/result 查询
	const result = TaskResultSchema.parse({
		id: taskId,
		kind: "text_to_video",
		status: "running",
		assets: [],
		raw: {
			provider: "veo",
			model,
			taskId,
			response: payload,
			},
		});
		{
			const nowIso = new Date().toISOString();
			const vendorForRef = channelVendor ? `${channelVendor}:veo` : "direct:veo";
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{ kind: "video", taskId: taskId.trim(), vendor: vendorForRef },
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert veo ref failed",
					err?.message || err,
				);
			}
		}
		await bindReservationToTaskId(c, userId, reservation, taskId);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "veo",
			taskKind: req.kind,
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: req.kind,
				result,
			});
		}
		return result;
		} catch (err) {
			return await releaseReservationOnThrow(c, userId, reservation, err);
		}
}

export async function fetchVeoTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
) {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}
	{
		const refForTask = await (async () => {
			try {
				return await getVendorTaskRefByTaskId(c.env.DB, userId, "video", taskId);
			} catch {
				return null;
			}
		})();
		const raw = typeof refForTask?.vendor === "string" ? refForTask.vendor.trim() : "";
		const hint = extractChannelVendor(raw);
		if (hint) {
			try {
				c.set("proxyVendorHint", hint);
			} catch {
				// ignore
			}
		}
		if (raw.toLowerCase().startsWith("direct")) {
			try {
				c.set("proxyDisabled", true);
			} catch {
				// ignore
			}
		}
	}
	const ctx = await resolveVendorContext(c, userId, "veo");
	if (ctx.viaProxyVendor === "comfly") {
		const result = await fetchComflyVideoTaskResult(
			c,
			userId,
			taskId,
			ctx,
			"text_to_video",
		);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "veo",
			taskKind: "text_to_video",
			result,
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "comfly",
			taskKind: "text_to_video",
			result,
		});
		return result;
	}
	const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "https://api.grsai.com";
	const isApimartBase = isApimartBaseUrl(baseUrl) || ctx.viaProxyVendor === "apimart";
	const channelVendor: "grsai" | "comfly" | "apimart" | null = isApimartBase
		? "apimart"
		: isGrsaiBaseUrl(baseUrl) || ctx.viaProxyVendor === "grsai"
			? "grsai"
			: null;
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(isApimartBase ? "未配置 apimart API Key" : "未配置 Veo API Key", {
			status: 400,
			code: "veo_api_key_missing",
		});
	}

	if (isApimartBase) {
		const wrapper = await callJsonApi(
			c,
			`${normalizeApimartBaseUrl(baseUrl)}/v1/tasks/${encodeURIComponent(taskId.trim())}?language=zh`,
			{
				method: "GET",
				headers: { Authorization: `Bearer ${apiKey}` },
			},
			{ provider: "apimart" },
		);

		if (typeof wrapper?.code === "number" && wrapper.code !== 200) {
			throw new AppError(
				(wrapper?.error?.message ||
					wrapper?.message ||
					`apimart 任务查询失败: code ${wrapper.code}`) as string,
				{
					status: 502,
					code: "apimart_result_failed",
					details: { upstreamData: wrapper ?? null },
				},
			);
		}

		const payload =
			wrapper && typeof wrapper === "object" && wrapper.data
				? wrapper.data
				: wrapper ?? {};
		let status = normalizeApimartTaskStatus(payload?.status);
		const progress = clampProgress(
			typeof payload?.progress === "number" ? payload.progress : undefined,
		);

		const urls = extractApimartMediaUrls(payload, "videos");
		const thumbnailUrl = extractApimartThumbnailUrl(payload);
		if (status === "succeeded" && urls.length === 0) {
			status = "running";
		}

		if (status === "succeeded" && urls.length > 0) {
			const asset = TaskAssetSchema.parse({
				type: "video",
				url: urls[0]!,
				thumbnailUrl: thumbnailUrl,
			});

			let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
			try {
				hostedAssets = await hostTaskAssetsInWorker({
					c,
					userId,
					assets: [asset],
					meta: {
						taskKind: "text_to_video",
						prompt: null,
						vendor: "veo",
						taskId: taskId ?? null,
					},
				});
			} catch (err: any) {
				const message =
					typeof err?.message === "string" && err.message.trim()
						? err.message.trim()
						: "OSS 托管失败，稍后重试";
				const result = TaskResultSchema.parse({
					id: taskId,
					kind: "text_to_video",
					status: "running",
					assets: [],
					raw: {
						provider: "apimart",
						response: payload ?? null,
						progress,
						hosting: { status: "pending", message },
					},
				});
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: "veo",
					taskKind: "text_to_video",
					result,
				});
				if (channelVendor) {
					await recordVendorCallFromTaskResult(c, {
						userId,
						vendor: channelVendor,
						taskKind: "text_to_video",
						result,
					});
				}
				return result;
			}

			const result = TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "succeeded",
				assets: hostedAssets,
				raw: {
					provider: "apimart",
					response: payload,
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: "veo",
				taskKind: "text_to_video",
				result,
			});
			if (channelVendor) {
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: channelVendor,
					taskKind: "text_to_video",
					result,
				});
			}
			return result;
		}

		const failureReasonRaw =
			(typeof payload?.error?.message === "string" &&
				payload.error.message.trim()) ||
			(typeof wrapper?.error?.message === "string" &&
				wrapper.error.message.trim()) ||
			null;

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status,
			assets: [],
			raw: {
				provider: "apimart",
				response: payload,
				progress,
				failureReason: failureReasonRaw,
				wrapper: wrapper ?? null,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "veo",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	let res: Response;
	let data: any = null;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl}/v1/draw/result`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify({ id: taskId.trim() }),
			},
			{ tag: "veo:result" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("Veo 结果查询失败", {
			status: 502,
			code: "veo_result_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	if (res.status < 200 || res.status >= 300) {
		const msg =
			(data && (data.message || data.error || data.msg)) ||
			`Veo result poll failed: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "veo_result_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	const payload = extractVeoResultPayload(data);
	if (!payload) {
		return TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "running",
			assets: [],
			raw: {
				provider: "veo",
				response: data,
			},
		});
	}

	const status = mapTaskStatus(payload.status);
	const progress = clampProgress(payload.progress);

	if (status === "failed") {
		const errMsg =
			payload.failure_reason || payload.error || "Veo 视频任务失败";
		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "failed",
			assets: [],
			raw: {
				provider: "veo",
				model: typeof payload.model === "string" ? payload.model : undefined,
				response: payload,
				progress,
				message: errMsg,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "veo",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	if (status === "succeeded") {
		const videoUrl =
			typeof payload.url === "string" && payload.url.trim()
				? payload.url.trim()
				: null;
		if (!videoUrl) {
			return TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "running",
				assets: [],
				raw: {
					provider: "veo",
					model:
						typeof payload.model === "string" ? payload.model : undefined,
					response: payload,
					progress,
				},
			});
		}
		const asset = TaskAssetSchema.parse({
			type: "video",
			url: videoUrl,
			thumbnailUrl:
				payload.thumbnailUrl || payload.thumbnail_url || null,
		});

		let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		try {
			hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets: [asset],
				meta: {
					taskKind: "text_to_video",
					prompt:
						typeof payload.prompt === "string"
							? payload.prompt
							: null,
					vendor: "veo",
					modelKey:
						typeof payload.model === "string"
							? payload.model
							: undefined,
					taskId: (payload.id || taskId) ?? null,
				},
			});
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			const result = TaskResultSchema.parse({
				id: payload.id || taskId,
				kind: "text_to_video",
				status: "running",
				assets: [],
				raw: {
					provider: "veo",
					model:
						typeof payload.model === "string" ? payload.model : undefined,
					response: payload,
					progress,
					hosting: { status: "pending", message },
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: "veo",
				taskKind: "text_to_video",
				result,
			});
			if (channelVendor) {
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: channelVendor,
					taskKind: "text_to_video",
					result,
				});
			}
			return result;
		}

		const result = TaskResultSchema.parse({
			id: payload.id || taskId,
			kind: "text_to_video",
			status: "succeeded",
			assets: hostedAssets,
			raw: {
				provider: "veo",
				model:
					typeof payload.model === "string" ? payload.model : undefined,
				response: payload,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "veo",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	return TaskResultSchema.parse({
		id: taskId,
		kind: "text_to_video",
		status,
		assets: [],
		raw: {
			provider: "veo",
			model: typeof payload.model === "string" ? payload.model : undefined,
			response: payload,
			progress,
		},
	});
}

// ---------- APIMART ----------

export async function runApimartVideoTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const extras = (req.extras || {}) as Record<string, any>;
	const model = (() => {
		const raw = typeof extras.modelKey === "string" ? extras.modelKey.trim() : "";
		if (!raw) return null;
		return raw.startsWith("models/") ? raw.slice(7) : raw;
	})();
	if (!model) {
		throw new AppError("apimart 需要通过 extras.modelKey 指定模型", {
			status: 400,
			code: "apimart_model_key_missing",
		});
	}

	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const progressCtx = extractProgressContext(req, "apimart");

	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "apimart",
		modelKey: model,
	});
	emitProgress(userId, progressCtx, { status: "queued", progress: 0 });

	try {
		const ctx = await resolveVendorContext(c, userId, "apimart");
		const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "https://api.apimart.ai";
		const apiKey = ctx.apiKey.trim();
		if (!apiKey) {
			throw new AppError("未配置 apimart API Key", {
				status: 400,
				code: "apimart_api_key_missing",
			});
		}

		const aspectRatio =
			typeof extras.aspectRatio === "string" && extras.aspectRatio.trim()
				? extras.aspectRatio.trim()
				: "16:9";
		const durationSeconds = (() => {
			const raw =
				typeof extras.durationSeconds === "number"
					? extras.durationSeconds
					: typeof extras.duration === "number"
						? extras.duration
						: null;
			return typeof raw === "number" && Number.isFinite(raw) && raw > 0
				? raw
				: undefined;
		})();

		const firstFrameUrl =
			typeof extras.firstFrameUrl === "string" && extras.firstFrameUrl.trim()
				? extras.firstFrameUrl.trim()
				: undefined;
		const lastFrameUrl =
			typeof extras.lastFrameUrl === "string" && extras.lastFrameUrl.trim()
				? extras.lastFrameUrl.trim()
				: undefined;

		const imageUrls = (() => {
			const urls: string[] = [];
			const pushAll = (value: any) => {
				const arr = Array.isArray(value) ? value : [value];
				for (const item of arr) {
					if (typeof item === "string" && item.trim()) urls.push(item.trim());
				}
			};
			pushAll((extras as any).image_urls);
			pushAll((extras as any).imageUrls);
			pushAll((extras as any).urls);
			pushAll((extras as any).referenceImages);
			pushAll((extras as any).reference_images);
			if (firstFrameUrl) urls.push(firstFrameUrl);
			if (lastFrameUrl) urls.push(lastFrameUrl);
			return Array.from(new Set(urls)).slice(0, 14);
		})();

		const body: Record<string, any> = {
			model,
			prompt: req.prompt,
			aspect_ratio: aspectRatio,
			...(typeof durationSeconds === "number" ? { duration: durationSeconds } : {}),
			...(typeof extras.private === "boolean" ? { private: extras.private } : {}),
			...(typeof extras.watermark === "boolean" ? { watermark: extras.watermark } : {}),
			...(typeof extras.thumbnail === "boolean" ? { thumbnail: extras.thumbnail } : {}),
			...(imageUrls.length ? { image_urls: imageUrls } : {}),
		};

		emitProgress(userId, progressCtx, { status: "running", progress: 5 });

		const data = await callJsonApi(
			c,
			`${normalizeApimartBaseUrl(baseUrl)}/v1/videos/generations`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ provider: "apimart" },
		);

		if (typeof data?.code === "number" && data.code !== 200) {
			throw new AppError(
				(data?.error?.message ||
					data?.message ||
					`apimart 视频生成失败: code ${data.code}`) as string,
				{
					status: 502,
					code: "apimart_request_failed",
					details: { upstreamData: data ?? null, requestBody: body },
				},
			);
		}

		const first = Array.isArray(data?.data) ? data.data[0] : null;
		const taskId =
			(typeof first?.task_id === "string" && first.task_id.trim()) ||
			(typeof first?.taskId === "string" && first.taskId.trim()) ||
			null;
		if (!taskId) {
			throw new AppError("apimart 未返回 task_id", {
				status: 502,
				code: "apimart_task_id_missing",
				details: { upstreamData: data ?? null, requestBody: body },
			});
		}

		emitProgress(userId, progressCtx, {
			status: "queued",
			progress: 10,
			taskId,
			raw: data ?? null,
		});

		{
			const nowIso = new Date().toISOString();
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{ kind: "video", taskId: taskId.trim(), vendor: "apimart" },
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert apimart ref failed",
					err?.message || err,
				);
			}
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "queued",
			assets: [],
			raw: {
				provider: "apimart",
				model,
				taskId,
				status: "queued",
				request: body,
				response: data ?? null,
			},
		});
		await bindReservationToTaskId(c, userId, reservation, taskId);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "apimart",
			taskKind: req.kind,
			result,
		});
		return result;
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

export async function runApimartImageTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	if (req.kind !== "text_to_image" && req.kind !== "image_edit") {
		throw new AppError("apimart 仅支持 text_to_image/image_edit 或 text_to_video", {
			status: 400,
			code: "invalid_task_kind",
		});
	}

	const extras = (req.extras || {}) as Record<string, any>;
	const rawModelKey =
		typeof extras.modelKey === "string" && extras.modelKey.trim()
			? extras.modelKey.trim()
			: "";
	const modelKey =
		rawModelKey && rawModelKey.startsWith("models/")
			? rawModelKey.slice(7)
			: rawModelKey;

	const normalizedMaybeBanana = normalizeBananaModelKey(modelKey);
	const resolved = (() => {
		if (normalizedMaybeBanana && BANANA_MODELS.has(normalizedMaybeBanana)) {
			return {
				modelForApimart: mapBananaModelToApimartModelKey(normalizedMaybeBanana),
				modelForBilling: normalizedMaybeBanana,
			};
		}
		const fallback = "gemini-2.5-flash-image-preview";
		const trimmed = modelKey.trim();
		return {
			modelForApimart: trimmed || fallback,
			modelForBilling: trimmed || fallback,
		};
	})();

	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: resolved.modelForBilling,
	});
	const progressCtx = extractProgressContext(req, "apimart");

	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "apimart",
		modelKey: resolved.modelForBilling,
	});
	emitProgress(userId, progressCtx, { status: "queued", progress: 0 });

	try {
		const ctx = await resolveVendorContext(c, userId, "apimart");
		const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "https://api.apimart.ai";
		const apiKey = ctx.apiKey.trim();
		if (!apiKey) {
			throw new AppError("未配置 apimart API Key", {
				status: 400,
				code: "apimart_api_key_missing",
			});
		}

		const referenceImages: string[] = Array.isArray(extras.referenceImages)
			? extras.referenceImages
					.map((url: any) => (typeof url === "string" ? url.trim() : ""))
					.filter((url: string) => url.length > 0)
			: [];

		const aspectRatio =
			typeof extras.aspectRatio === "string" && extras.aspectRatio.trim()
				? extras.aspectRatio.trim()
				: "auto";
		const resolvedAspect = (() => {
			const raw =
				typeof aspectRatio === "string" && aspectRatio.trim()
					? aspectRatio.trim()
					: "";
			if (!raw || raw.toLowerCase() === "auto") return null;
			const allowed = new Set([
				"4:3",
				"3:4",
				"16:9",
				"9:16",
				"2:3",
				"3:2",
				"1:1",
				"4:5",
				"5:4",
				"21:9",
			]);
			return allowed.has(raw) ? raw : null;
		})();

		const resolution =
			typeof extras.resolution === "string" && extras.resolution.trim()
				? extras.resolution.trim()
				: typeof (extras as any).imageResolution === "string" &&
						String((extras as any).imageResolution).trim()
					? String((extras as any).imageResolution).trim()
					: null;

		const body: Record<string, any> = {
			model: resolved.modelForApimart,
			prompt: req.prompt,
			n: 1,
			...(resolvedAspect ? { size: resolvedAspect } : {}),
			...(resolution ? { resolution } : {}),
			...(referenceImages.length
				? { image_urls: referenceImages.slice(0, 14) }
				: {}),
		};

		emitProgress(userId, progressCtx, { status: "running", progress: 5 });

		const data = await callJsonApi(
			c,
			`${normalizeApimartBaseUrl(baseUrl)}/v1/images/generations`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ provider: "apimart" },
		);

		if (typeof data?.code === "number" && data.code !== 200) {
			throw new AppError(
				(data?.error?.message ||
					data?.message ||
					`apimart 图像生成失败: code ${data.code}`) as string,
				{
					status: 502,
					code: "apimart_request_failed",
					details: { upstreamData: data ?? null, requestBody: body },
				},
			);
		}

		const first = Array.isArray(data?.data) ? data.data[0] : null;
		const taskId =
			(typeof first?.task_id === "string" && first.task_id.trim()) ||
			(typeof first?.taskId === "string" && first.taskId.trim()) ||
			null;
		if (!taskId) {
			throw new AppError("apimart 未返回 task_id", {
				status: 502,
				code: "apimart_task_id_missing",
				details: { upstreamData: data ?? null, requestBody: body },
			});
		}

		emitProgress(userId, progressCtx, {
			status: "queued",
			progress: 10,
			taskId,
			raw: data ?? null,
		});

		{
			const nowIso = new Date().toISOString();
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{ kind: "image", taskId: taskId.trim(), vendor: "apimart" },
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert apimart image ref failed",
					err?.message || err,
				);
			}
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: req.kind,
			status: "queued",
			assets: [],
			raw: {
				provider: "apimart",
				model: resolved.modelForApimart,
				taskId,
				status: "queued",
				request: body,
				response: data ?? null,
			},
		});
		await bindReservationToTaskId(c, userId, reservation, taskId);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "apimart",
			taskKind: req.kind,
			result,
		});
		return result;
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

export async function fetchApimartTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
	promptFromClient?: string | null,
	options?: { taskKind?: TaskRequestDto["kind"] | null },
) {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}

	const ctx = await resolveVendorContext(c, userId, "apimart");
	const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "https://api.apimart.ai";
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 apimart API Key", {
			status: 400,
			code: "apimart_api_key_missing",
		});
	}

	const wrapper = await callJsonApi(
		c,
		`${normalizeApimartBaseUrl(baseUrl)}/v1/tasks/${encodeURIComponent(taskId.trim())}?language=zh`,
		{
			method: "GET",
			headers: { Authorization: `Bearer ${apiKey}` },
		},
		{ provider: "apimart" },
	);

	if (typeof wrapper?.code === "number" && wrapper.code !== 200) {
		throw new AppError(
			(wrapper?.error?.message ||
				wrapper?.message ||
				`apimart 任务查询失败: code ${wrapper.code}`) as string,
			{
				status: 502,
				code: "apimart_result_failed",
				details: { upstreamData: wrapper ?? null },
			},
		);
	}

	const payload =
		wrapper && typeof wrapper === "object" && wrapper.data ? wrapper.data : wrapper ?? {};
	let status = normalizeApimartTaskStatus(payload?.status);
	const progress = clampProgress(
		typeof payload?.progress === "number" ? payload.progress : undefined,
	);

	const expected = typeof options?.taskKind === "string" ? options.taskKind : null;
	const preferImages =
		expected === "text_to_image" || expected === "image_edit";
	const preferVideos =
		expected === "text_to_video" || expected === "image_to_video";

	const imageUrls = extractApimartMediaUrls(payload, "images");
	const videoUrls = extractApimartMediaUrls(payload, "videos");

	const mediaKey: "images" | "videos" = (() => {
		if (preferImages) return "images";
		if (preferVideos) return "videos";
		if (imageUrls.length > 0 && videoUrls.length === 0) return "images";
		if (videoUrls.length > 0 && imageUrls.length === 0) return "videos";
		return "videos";
	})();

	const urls = mediaKey === "images" ? imageUrls : videoUrls;
	const thumbnailUrl =
		mediaKey === "videos" ? extractApimartThumbnailUrl(payload) : null;
	if (status === "succeeded" && urls.length === 0) {
		status = "running";
	}

	const taskKind: TaskRequestDto["kind"] = (() => {
		if (preferImages) return expected as TaskRequestDto["kind"];
		if (preferVideos) return "text_to_video";
		if (mediaKey === "images") return (expected as any) || "text_to_image";
		return "text_to_video";
	})();

	if (status === "succeeded" && urls.length > 0) {
		const assets =
			mediaKey === "images"
				? urls.map((url) =>
						TaskAssetSchema.parse({ type: "image", url, thumbnailUrl: null }),
					)
				: [
						TaskAssetSchema.parse({
							type: "video",
							url: urls[0]!,
							thumbnailUrl: thumbnailUrl,
						}),
					];

		let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		try {
			hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets,
				meta: {
					taskKind,
					prompt:
						typeof promptFromClient === "string" && promptFromClient.trim()
							? promptFromClient.trim()
							: null,
					vendor: "apimart",
					taskId: taskId ?? null,
				},
			});
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			const result = TaskResultSchema.parse({
				id: taskId,
				kind: taskKind,
				status: "running",
				assets: [],
				raw: {
					provider: "apimart",
					response: payload ?? null,
					progress,
					hosting: { status: "pending", message },
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: "apimart",
				taskKind,
				result,
			});
			return result;
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: taskKind,
			status: "succeeded",
			assets: hostedAssets,
			raw: {
				provider: "apimart",
				response: payload,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "apimart",
			taskKind,
			result,
		});
		return result;
	}

	const failureReasonRaw =
		(typeof payload?.error?.message === "string" && payload.error.message.trim()) ||
		(typeof wrapper?.error?.message === "string" && wrapper.error.message.trim()) ||
		null;

	const result = TaskResultSchema.parse({
		id: taskId,
		kind: taskKind,
		status,
		assets: [],
		raw: {
			provider: "apimart",
			response: payload,
			progress,
			failureReason: failureReasonRaw,
			wrapper: wrapper ?? null,
		},
	});
	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: "apimart",
		taskKind,
		result,
	});
	return result;
}

// ---------- Sora2API ----------

function normalizeSora2ApiModelKey(
	modelKey?: string | null,
	orientation?: "portrait" | "landscape",
	durationSeconds?: number | null,
): string {
	const trimmed = (modelKey || "").trim();
	if (trimmed && /^sora-(image|video)/i.test(trimmed)) {
		return trimmed;
	}
	const duration =
		typeof durationSeconds === "number" && Number.isFinite(durationSeconds)
			? durationSeconds
			: 10;
	const isShort = duration <= 10;
	const orient = orientation === "portrait" ? "portrait" : "landscape";
	if (orient === "portrait") {
		return isShort
			? "sora-video-portrait-10s"
			: "sora-video-portrait-15s";
	}
	return isShort
		? "sora-video-landscape-10s"
		: "sora-video-landscape-15s";
}

export async function runSora2ApiVideoTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const progressCtx = extractProgressContext(req, "sora2api");

	const ctx = await resolveVendorContext(c, userId, "sora2api");
	const baseUrl =
		normalizeBaseUrl(ctx.baseUrl) || "http://localhost:8000";
	const isApimartBase =
		isApimartBaseUrl(baseUrl) || ctx.viaProxyVendor === "apimart";
	const isYunwuBase =
		isYunwuBaseUrl(baseUrl) || ctx.viaProxyVendor === "yunwu";
	const isGrsaiBase =
		isGrsaiBaseUrl(baseUrl) || ctx.viaProxyVendor === "grsai";
	const isComflyProxy = ctx.viaProxyVendor === "comfly";
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(
			isApimartBase
				? "未配置 apimart API Key"
				: isYunwuBase
					? "未配置 yunwu API Key"
					: "未配置 sora2api API Key",
			{
				status: 400,
				code: "sora2api_api_key_missing",
			},
		);
	}

	const extras = (req.extras || {}) as Record<string, any>;
	const orientationRaw =
		(typeof extras.orientation === "string" && extras.orientation.trim()) ||
		(typeof req.extras?.orientation === "string" &&
			(req.extras as any).orientation) ||
		"landscape";
	const orientation =
		orientationRaw === "portrait" ? "portrait" : "landscape";
	const durationSeconds =
		typeof (req as any).durationSeconds === "number" &&
		Number.isFinite((req as any).durationSeconds)
			? (req as any).durationSeconds
			: typeof extras.durationSeconds === "number" &&
					Number.isFinite(extras.durationSeconds)
				? extras.durationSeconds
				: 10;

	const modelKeyRaw =
		typeof extras.modelKey === "string" && extras.modelKey.trim()
			? extras.modelKey.trim()
			: "";
	const model = isComflyProxy
		? modelKeyRaw || "sora-2"
		: isGrsaiBase || isYunwuBase
			? modelKeyRaw || "sora-2"
			: normalizeSora2ApiModelKey(modelKeyRaw || undefined, orientation, durationSeconds);
	const billingModelKey = modelKeyRaw || model;
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: billingModelKey,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "sora2api",
		modelKey: billingModelKey,
	});

	emitProgress(userId, progressCtx, { status: "queued", progress: 0 });
	try {
	const aspectRatio = orientation === "portrait" ? "9:16" : "16:9";
	const webHook =
		typeof extras.webHook === "string" && extras.webHook.trim()
			? extras.webHook.trim()
			: "-1";
	const shutProgress = extras.shutProgress === true;
	const remixTargetId =
		(typeof extras.remixTargetId === "string" &&
			extras.remixTargetId.trim()) ||
		(typeof extras.pid === "string" && extras.pid.trim()) ||
		null;
	const size =
		typeof extras.size === "string" && extras.size.trim()
			? extras.size.trim()
			: "small";
	const characters = Array.isArray(extras.characters)
		? extras.characters
		: undefined;
	const referenceUrl =
		(typeof extras.url === "string" && extras.url.trim()) ||
		(typeof extras.firstFrameUrl === "string" &&
			extras.firstFrameUrl.trim()) ||
		(Array.isArray(extras.urls) && extras.urls[0]
			? String(extras.urls[0]).trim()
			: null) ||
		null;

	if (isComflyProxy) {
		const sizeFromExtras =
			typeof extras.size === "string" && /^\d+\s*x\s*\d+$/i.test(extras.size.trim())
				? extras.size.trim().replace(/\s+/g, "")
				: null;
		const size = sizeFromExtras || (orientation === "portrait" ? "720x1280" : "1280x720");
		const watermark =
			typeof extras.watermark === "boolean" ? extras.watermark : null;
		const result = await createComflySora2VideoTask(
			c,
			userId,
			req,
			ctx,
			{
				model,
				size,
				seconds: durationSeconds,
				watermark,
				inputReferenceUrl: referenceUrl,
			},
			progressCtx,
		);
		await bindReservationToTaskId(c, userId, reservation, result.id);
		{
			const nowIso = new Date().toISOString();
			const vendorForRef = `comfly-${model || "sora-2"}`;
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{
						kind: "video",
						taskId: result.id,
						vendor: vendorForRef,
					},
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert comfly video ref failed",
					err?.message || err,
				);
			}
		}
		{
			const vendorForLog = `comfly-${model || "sora-2"}`;
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	if (isYunwuBase) {
		emitProgress(userId, progressCtx, { status: "running", progress: 5 });

		const imageUrls = (() => {
			const urls: string[] = [];
			const add = (value: any) => {
				if (typeof value === "string" && value.trim()) {
					urls.push(value.trim());
				}
			};
			if (Array.isArray((extras as any).images)) (extras as any).images.forEach(add);
			if (Array.isArray((extras as any).image_urls))
				(extras as any).image_urls.forEach(add);
			if (Array.isArray((extras as any).imageUrls))
				(extras as any).imageUrls.forEach(add);
			if (Array.isArray((extras as any).urls)) (extras as any).urls.forEach(add);
			add((extras as any).url);
			add((extras as any).firstFrameUrl);
			if (referenceUrl) add(referenceUrl);
			return Array.from(new Set(urls)).slice(0, 8);
		})();

		const sizeForYunwu = (() => {
			const raw = typeof extras.size === "string" ? extras.size.trim() : "";
			const lowered = raw.toLowerCase();
			if (lowered === "small" || lowered === "large") return lowered;
			const compact =
				typeof raw === "string" && /^\d+\s*x\s*\d+$/i.test(raw)
					? raw.replace(/\s+/g, "")
					: "";
			if (compact) {
				const [wStr, hStr] = compact.split("x");
				const w = Number(wStr);
				const h = Number(hStr);
				if (Number.isFinite(w) && Number.isFinite(h)) {
					return Math.max(w, h) <= 1280 ? "small" : "large";
				}
			}
			return "small";
		})();

		const durationForYunwu = (() => {
			const n =
				typeof durationSeconds === "number" && Number.isFinite(durationSeconds)
					? durationSeconds
					: 10;
			if (n <= 10) return 10;
			if (n <= 15) return 15;
			return 15;
		})();

		const watermark =
			typeof extras.watermark === "boolean" ? extras.watermark : true;
		const isPrivate =
			typeof extras.private === "boolean"
				? extras.private
				: typeof extras.isPrivate === "boolean"
					? extras.isPrivate
					: false;

		const body: Record<string, any> = {
			images: imageUrls,
			model,
			orientation,
			prompt: req.prompt,
			size: sizeForYunwu,
			duration: durationForYunwu,
			watermark,
			private: isPrivate,
		};

		const data = await callJsonApi(
			c,
			`${normalizeYunwuBaseUrl(baseUrl)}/v1/video/create`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ provider: "yunwu" },
		);

		const createdTaskId =
			(typeof data?.id === "string" && data.id.trim()) ||
			(typeof data?.task_id === "string" && data.task_id.trim()) ||
			(typeof data?.taskId === "string" && data.taskId.trim()) ||
			null;
		if (!createdTaskId) {
			throw new AppError("yunwu 未返回任务 ID", {
				status: 502,
				code: "yunwu_task_id_missing",
				details: { upstreamData: data ?? null, requestBody: body },
			});
		}

		{
			const nowIso = new Date().toISOString();
			const vendorForRef = `yunwu-${model || "sora-2"}`;
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{
						kind: "video",
						taskId: createdTaskId,
						vendor: vendorForRef,
					},
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert yunwu video ref failed",
					err?.message || err,
				);
			}
		}

		const status = normalizeYunwuVideoTaskStatus(data?.status);
		emitProgress(userId, progressCtx, {
			status,
			progress: status === "queued" ? 5 : 10,
			taskId: createdTaskId,
			raw: data ?? null,
		});

		const vendorForLog = `yunwu-${model || "sora-2"}`;
		const result = TaskResultSchema.parse({
			id: createdTaskId,
			kind: "text_to_video",
			status,
			assets: [],
			raw: {
				provider: "yunwu",
				model,
				taskId: createdTaskId,
				status,
				request: body,
				response: data ?? null,
			},
		});
		await bindReservationToTaskId(c, userId, reservation, createdTaskId);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind: "text_to_video",
			result,
		});
		return result;
	}

	if (isApimartBase) {
		emitProgress(userId, progressCtx, { status: "running", progress: 5 });

		const modelForApimart = (() => {
			const raw = (modelKeyRaw || "").trim().toLowerCase();
			if (raw === "sora-2-pro") return "sora-2-pro";
			return "sora-2";
		})();

		const imageUrls = (() => {
			const urls: string[] = [];
			const pushAll = (value: any) => {
				const arr = Array.isArray(value) ? value : [value];
				for (const item of arr) {
					if (typeof item === "string" && item.trim()) urls.push(item.trim());
				}
			};
			pushAll((extras as any).image_urls);
			pushAll((extras as any).imageUrls);
			pushAll((extras as any).urls);
			if (referenceUrl) urls.push(referenceUrl);
			return Array.from(new Set(urls)).slice(0, 14);
		})();

		const body: Record<string, any> = {
			model: modelForApimart,
			prompt: req.prompt,
			duration: durationSeconds,
			aspect_ratio: aspectRatio,
			...(typeof extras.private === "boolean" ? { private: extras.private } : {}),
			...(typeof extras.watermark === "boolean"
				? { watermark: extras.watermark }
				: {}),
			...(typeof extras.thumbnail === "boolean"
				? { thumbnail: extras.thumbnail }
				: {}),
			...(imageUrls.length ? { image_urls: imageUrls } : {}),
		};

		const data = await callJsonApi(
			c,
			`${normalizeApimartBaseUrl(baseUrl)}/v1/videos/generations`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ provider: "apimart" },
		);

		if (typeof data?.code === "number" && data.code !== 200) {
			throw new AppError(
				(data?.error?.message ||
					data?.message ||
					`apimart 视频生成失败: code ${data.code}`) as string,
				{
					status: 502,
					code: "apimart_request_failed",
					details: { upstreamData: data ?? null, requestBody: body },
				},
			);
		}

		const first = Array.isArray(data?.data) ? data.data[0] : null;
		const createdTaskId =
			(typeof first?.task_id === "string" && first.task_id.trim()) ||
			(typeof first?.taskId === "string" && first.taskId.trim()) ||
			null;
		if (!createdTaskId) {
			throw new AppError("apimart 未返回 task_id", {
				status: 502,
				code: "apimart_task_id_missing",
				details: { upstreamData: data ?? null, requestBody: body },
			});
		}

		{
			const nowIso = new Date().toISOString();
			const vendorForRef = `apimart-${modelForApimart}`;
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{
						kind: "video",
						taskId: createdTaskId,
						vendor: vendorForRef,
					},
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert apimart video ref failed",
					err?.message || err,
				);
			}
		}

		const vendorForLog = `apimart-${modelForApimart}`;
		const result = TaskResultSchema.parse({
			id: createdTaskId,
			kind: "text_to_video",
			status: "queued",
			assets: [],
			raw: {
				provider: "apimart",
				model: modelForApimart,
				taskId: createdTaskId,
				status: "queued",
				request: body,
				response: data ?? null,
			},
		});
		await bindReservationToTaskId(c, userId, reservation, createdTaskId);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind: "text_to_video",
			result,
		});
		return result;
	}

	const body: Record<string, any> = isGrsaiBase
		? {
				// grsai / Sora 协议（与 sora2/sora2api 一致）
				model,
				prompt: req.prompt,
				aspectRatio,
				aspect_ratio: aspectRatio,
				orientation,
				duration: durationSeconds,
				webHook,
				shutProgress,
				size,
				// 兼容不同实现：有的服务端使用 remixTargetId，有的使用 pid
				...(remixTargetId ? { remixTargetId, pid: remixTargetId } : {}),
				...(characters ? { characters } : {}),
				...(referenceUrl ? { url: referenceUrl } : {}),
			}
		: {
				// 兼容 sora2api 号池协议
				model,
				prompt: req.prompt,
				durationSeconds,
				orientation,
				duration: durationSeconds,
				aspectRatio,
				aspect_ratio: aspectRatio,
				webHook,
				shutProgress,
				size,
				// 兼容不同实现：有的服务端使用 remixTargetId，有的使用 pid
				...(remixTargetId ? { remixTargetId, pid: remixTargetId } : {}),
				...(characters ? { characters } : {}),
				...(referenceUrl ? { url: referenceUrl } : {}),
			};

	const creationEndpoints = (() => {
		// sora2api 创建任务应优先走 /v1/video/sora-video；当后端不是 grsai/sora2api 域时，仍尝试该路径，再回退 /v1/video/tasks。
		const soraVideoCandidates = [
			`${baseUrl}/v1/video/sora-video`,
			`${baseUrl}/v1/video/sora`,
			`${baseUrl}/client/v1/video/sora-video`,
			`${baseUrl}/client/v1/video/sora`,
			`${baseUrl}/client/video/sora-video`,
			`${baseUrl}/client/video/sora`,
		];
		const legacyTasks = [
			`${baseUrl}/v1/video/tasks`,
			`${baseUrl}/client/v1/video/tasks`,
			`${baseUrl}/client/video/tasks`,
		];
		const seen = new Set<string>();
		const dedupe = (arr: string[]) =>
			arr.filter((url) => {
				if (seen.has(url)) return false;
				seen.add(url);
				return true;
			});

		if (isGrsaiBase) {
			return dedupe(soraVideoCandidates);
		}

		return dedupe([...soraVideoCandidates, ...legacyTasks]);
	})();

	let createdTaskId: string | null = null;
	let createdPayload: any = null;
	let creationStatus: "running" | "succeeded" | "failed" = "running";
	let creationProgress: number | undefined;
	const attemptedEndpoints: Array<{ url: string; status?: number | null }> =
		[];
	let lastError: {
		status: number;
		data: any;
		message: string;
		endpoint?: string;
		requestBody?: any;
	} | null = null;

	emitProgress(userId, progressCtx, { status: "running", progress: 5 });

	for (const endpoint of creationEndpoints) {
		let res: Response;
		let data: any = null;
		try {
			res = await fetchWithHttpDebugLog(
				c,
				endpoint,
				{
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${apiKey}`,
					},
					body: JSON.stringify(body),
				},
				{ tag: "sora2api:createVideo" },
			);
			try {
				data = await res.json();
			} catch {
				data = null;
			}
			attemptedEndpoints.push({ url: endpoint, status: res.status });
		} catch (error: any) {
			lastError = {
				status: 502,
				data: null,
				message: error?.message ?? String(error),
				endpoint,
				requestBody: body,
			};
			attemptedEndpoints.push({ url: endpoint, status: null });
			continue;
		}

		if (res.status < 200 || res.status >= 300) {
			const upstreamMessage =
				(data &&
					(data.error?.message || data.message || data.error)) ||
				`sora2api 调用失败: ${res.status} (${endpoint})`;
			const notFoundHint =
				res.status === 404
					? `；请确认 SORA2API_BASE_URL=${baseUrl} 指向实际的视频任务服务，且存在 /v1/video/sora（或 /v1/video/sora-video）/ /v1/video/tasks 路由`
					: "";
			lastError = {
				status: res.status,
				data,
				message: `${upstreamMessage}${notFoundHint}`,
				endpoint,
				requestBody: body,
			};
			continue;
		}

		const payload =
			typeof data?.code === "number" && data.code === 0 && data.data
				? data.data
				: data;
		if (typeof data?.code === "number" && data.code !== 0) {
			lastError = {
				status: res.status,
				data,
				message:
					data?.msg ||
					data?.message ||
					data?.error ||
					`sora2api 调用失败: code ${data.code}`,
				endpoint,
				requestBody: body,
			};
			break;
		}
		const id =
			(typeof payload?.id === "string" && payload.id.trim()) ||
			(typeof payload?.taskId === "string" && payload.taskId.trim()) ||
			null;
		if (!id) {
			lastError = {
				status: 502,
				data,
				message: "sora2api 未返回任务 ID",
				endpoint,
			};
			continue;
		}

		createdTaskId = id.trim();
		createdPayload = payload;
		creationStatus = mapTaskStatus(payload?.status || "queued");
		creationProgress = clampProgress(
			typeof payload?.progress === "number"
				? payload.progress
				: typeof payload?.progress_pct === "number"
					? payload.progress_pct * 100
					: undefined,
		);
		break;
	}

	if (!createdTaskId) {
		const attemptedReadable = attemptedEndpoints.map((e) =>
			`${e.status ?? "error"} ${e.url}`,
		);
		throw new AppError(lastError?.message || "sora2api 调用失败", {
			status: lastError?.status ?? 502,
			code: "sora2api_request_failed",
			details: {
				upstreamStatus: lastError?.status ?? null,
				upstreamData: lastError?.data ?? null,
				endpointTried: lastError?.endpoint ?? null,
				attemptedEndpoints,
				attemptedEndpointsText: attemptedReadable,
				requestBody: body,
			},
		});
	}

	{
		const normalizedModelForVendor = model.trim().startsWith("models/")
			? model.trim().slice(7)
			: model.trim();
		const vendorForRef = isGrsaiBase
			? `grsai-${normalizedModelForVendor || "sora-2"}`
			: "sora2api";
		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{
					kind: "video",
					taskId: createdTaskId,
					vendor: vendorForRef,
				},
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert video ref failed",
				err?.message || err,
			);
		}
	}

	const normalizedModelForVendor = model.trim().startsWith("models/")
		? model.trim().slice(7)
		: model.trim();
	const vendorForLog = isGrsaiBase
		? `grsai-${normalizedModelForVendor || "sora-2"}`
		: "sora2api";
	const result = TaskResultSchema.parse({
		id: createdTaskId,
		kind: "text_to_video",
		status: creationStatus,
		taskId: createdTaskId,
		assets: [],
		raw: {
			provider: "sora2api",
			model,
			taskId: createdTaskId,
			status: creationStatus,
			progress: creationProgress ?? null,
			response: createdPayload,
		},
	});
	await bindReservationToTaskId(c, userId, reservation, createdTaskId);
	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: vendorForLog,
		taskKind: "text_to_video",
		result,
	});
	return result;
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

export async function fetchSora2ApiTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
	promptFromClient?: string | null,
) {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}
	const refForTask = await (async () => {
		try {
			return await getVendorTaskRefByTaskId(c.env.DB, userId, "video", taskId);
		} catch {
			return null;
		}
	})();
	const refVendorRaw =
		typeof refForTask?.vendor === "string" ? refForTask.vendor.trim() : "";
	{
		const hint = extractChannelVendor(refVendorRaw);
		if (hint) {
			try {
				c.set("proxyVendorHint", hint);
			} catch {
				// ignore
			}
		}
	}
	const vendorForTask: "sora2api" | "grsai" = refVendorRaw
		.toLowerCase()
		.startsWith("grsai")
		? "grsai"
		: "sora2api";
	const vendorForLog = refVendorRaw || vendorForTask;

	const ctx = await resolveVendorContext(c, userId, vendorForTask);
	if (ctx.viaProxyVendor === "comfly") {
		const result = await fetchComflySora2VideoTaskResult(
			c,
			userId,
			taskId,
			ctx,
			"text_to_video",
		);
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind: "text_to_video",
			result,
		});
		return result;
	}
	const baseUrl =
		normalizeBaseUrl(ctx.baseUrl) ||
		(vendorForTask === "grsai" ? "https://api.grsai.com" : "http://localhost:8000");
	const isGrsaiBase =
		isGrsaiBaseUrl(baseUrl) || ctx.viaProxyVendor === "grsai";
	const isApimartBase =
		isApimartBaseUrl(baseUrl) || ctx.viaProxyVendor === "apimart";
	const isYunwuBase =
		isYunwuBaseUrl(baseUrl) || ctx.viaProxyVendor === "yunwu";
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(
			isApimartBase
				? "未配置 apimart API Key"
				: isYunwuBase
					? "未配置 yunwu API Key"
					: "未配置 sora2api API Key",
			{
				status: 400,
				code: "sora2api_api_key_missing",
			},
		);
	}

	if (isYunwuBase) {
		const payload = await callJsonApi(
			c,
			`${normalizeYunwuBaseUrl(baseUrl)}/v1/video/query?id=${encodeURIComponent(
				taskId.trim(),
			)}`,
			{
				method: "GET",
				headers: {
					Accept: "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
			},
			{ provider: "yunwu" },
		);

		let status = normalizeYunwuVideoTaskStatus(payload?.status);
		const videoUrlRaw =
			(typeof payload?.video_url === "string" && payload.video_url.trim()) ||
			(typeof payload?.videoUrl === "string" && payload.videoUrl.trim()) ||
			null;
		const videoUrl = videoUrlRaw ? videoUrlRaw.trim() : null;
		if (status === "succeeded" && !videoUrl) {
			status = "running";
		}

		if (status === "succeeded" && videoUrl) {
			const asset = TaskAssetSchema.parse({
				type: "video",
				url: videoUrl,
				thumbnailUrl: null,
			});

			const promptForAsset = (() => {
				const client =
					typeof promptFromClient === "string" && promptFromClient.trim()
						? promptFromClient.trim()
						: null;
				const enhanced =
					typeof payload?.enhanced_prompt === "string" &&
					payload.enhanced_prompt.trim()
						? payload.enhanced_prompt.trim()
						: null;
				return enhanced || client;
			})();

			let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
			try {
				hostedAssets = await hostTaskAssetsInWorker({
					c,
					userId,
					assets: [asset],
					meta: {
						taskKind: "text_to_video",
						prompt: promptForAsset,
						vendor: vendorForLog,
						modelKey:
							typeof payload?.model === "string"
								? payload.model
								: undefined,
						taskId: taskId ?? null,
					},
				});
			} catch (err: any) {
				const message =
					typeof err?.message === "string" && err.message.trim()
						? err.message.trim()
						: "OSS 托管失败，稍后重试";
				const result = TaskResultSchema.parse({
					id: taskId,
					kind: "text_to_video",
					status: "running",
					assets: [],
					raw: {
						provider: "yunwu",
						response: payload ?? null,
						hosting: { status: "pending", message },
					},
				});
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: vendorForLog,
					taskKind: "text_to_video",
					result,
				});
				return result;
			}

			const result = TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "succeeded",
				assets: hostedAssets,
				raw: {
					provider: "yunwu",
					response: payload ?? null,
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind: "text_to_video",
				result,
			});
			return result;
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status,
			assets: [],
			raw: {
				provider: "yunwu",
				response: payload ?? null,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind: "text_to_video",
			result,
		});
		return result;
	}

	if (isApimartBase) {
		const wrapper = await callJsonApi(
			c,
			`${normalizeApimartBaseUrl(baseUrl)}/v1/tasks/${encodeURIComponent(taskId.trim())}?language=zh`,
			{
				method: "GET",
				headers: { Authorization: `Bearer ${apiKey}` },
			},
			{ provider: "apimart" },
		);

		if (typeof wrapper?.code === "number" && wrapper.code !== 200) {
			throw new AppError(
				(wrapper?.error?.message ||
					wrapper?.message ||
					`apimart 任务查询失败: code ${wrapper.code}`) as string,
				{
					status: 502,
					code: "apimart_result_failed",
					details: { upstreamData: wrapper ?? null },
				},
			);
		}

		const payload =
			wrapper && typeof wrapper === "object" && wrapper.data
				? wrapper.data
				: wrapper ?? {};
		let status = normalizeApimartTaskStatus(payload?.status);
		const progress = clampProgress(
			typeof payload?.progress === "number" ? payload.progress : undefined,
		);

		const urls = extractApimartMediaUrls(payload, "videos");
		const thumbnailUrl = extractApimartThumbnailUrl(payload);
		if (status === "succeeded" && urls.length === 0) {
			status = "running";
		}

		if (status === "succeeded" && urls.length > 0) {
			const asset = TaskAssetSchema.parse({
				type: "video",
				url: urls[0]!,
				thumbnailUrl: thumbnailUrl,
			});

			let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
			try {
				hostedAssets = await hostTaskAssetsInWorker({
					c,
					userId,
					assets: [asset],
					meta: {
						taskKind: "text_to_video",
						prompt:
							typeof promptFromClient === "string" &&
							promptFromClient.trim()
								? promptFromClient.trim()
								: null,
						vendor: vendorForLog,
						taskId: taskId ?? null,
					},
				});
			} catch (err: any) {
				const message =
					typeof err?.message === "string" && err.message.trim()
						? err.message.trim()
						: "OSS 托管失败，稍后重试";
				const result = TaskResultSchema.parse({
					id: taskId,
					kind: "text_to_video",
					status: "running",
					assets: [],
					raw: {
						provider: "apimart",
						vendor: vendorForLog,
						response: payload ?? null,
						progress,
						hosting: { status: "pending", message },
					},
				});
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: vendorForLog,
					taskKind: "text_to_video",
					result,
				});
				return result;
			}

			const result = TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "succeeded",
				assets: hostedAssets,
				raw: {
					provider: "apimart",
					response: payload,
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind: "text_to_video",
				result,
			});
			return result;
		}

		const failureReasonRaw =
			(typeof payload?.error?.message === "string" &&
				payload.error.message.trim()) ||
			(typeof wrapper?.error?.message === "string" &&
				wrapper.error.message.trim()) ||
			null;

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status,
			assets: [],
			raw: {
				provider: "apimart",
				response: payload,
				progress,
				failureReason: failureReasonRaw,
				wrapper: wrapper ?? null,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind: "text_to_video",
			result,
		});
		return result;
	}

	const endpoints: Array<{
		url: string;
		method: "GET" | "POST";
		body?: any;
	}> = isGrsaiBase
		? [
				{
					url: `${baseUrl}/v1/draw/result`,
					method: "POST",
					body: JSON.stringify({ id: taskId.trim() }),
				},
				{
					url: `${baseUrl}/v1/video/tasks/${encodeURIComponent(
						taskId.trim(),
					)}`,
					method: "GET",
				},
			]
		: [
				{
					url: `${baseUrl}/v1/video/tasks/${encodeURIComponent(
						taskId.trim(),
					)}`,
					method: "GET",
				},
			];

	let lastError: {
		status: number;
		data: any;
		message: string;
		endpoint?: string;
	} | null = null;
	let data: any = null;

	for (const endpoint of endpoints) {
		let res: Response;
		data = null;
		try {
			res = await fetchWithHttpDebugLog(
				c,
				endpoint.url,
				{
					method: endpoint.method,
					headers: {
						Authorization: `Bearer ${apiKey}`,
						...(endpoint.method === "POST"
							? { "Content-Type": "application/json" }
							: {}),
					},
					body: endpoint.body,
				},
				{ tag: "sora2api:result" },
			);
			try {
				data = await res.json();
			} catch {
				data = null;
			}
		} catch (error: any) {
			lastError = {
				status: 502,
				data: null,
				message: error?.message ?? String(error),
				endpoint: endpoint.url,
			};
			continue;
		}

		if (res.status < 200 || res.status >= 300) {
			lastError = {
				status: res.status,
				data,
				message:
					(data &&
						(data.error?.message ||
							data.message ||
							data.error)) ||
					`sora2api 任务查询失败: ${res.status}`,
				endpoint: endpoint.url,
			};
			continue;
		}

		const payload = extractVeoResultPayload(data) ?? data ?? {};
		// 部分 sora2api 实现会把 pid/postId 放在最外层，而结果在 data 字段里；这里做一次兼容合并，避免前端拿不到 pid 导致 Remix 无法引用。
		const mergedPayload = (() => {
			if (!payload || typeof payload !== "object") return payload;
			if (!data || typeof data !== "object") return payload;
			// When extractVeoResultPayload unwraps `data`, preserve wrapper-level pid/postId.
			const wrapper = data as any;
			const current = payload as any;
			const existingPid =
				(typeof current.pid === "string" && current.pid.trim()) ||
				(typeof current.postId === "string" && current.postId.trim()) ||
				(typeof current.post_id === "string" && current.post_id.trim()) ||
				null;
			const wrapperPid =
				(typeof wrapper.pid === "string" && wrapper.pid.trim()) ||
				(typeof wrapper.postId === "string" && wrapper.postId.trim()) ||
				(typeof wrapper.post_id === "string" && wrapper.post_id.trim()) ||
				null;
			const resultEntry =
				Array.isArray(current.results) && current.results.length
					? current.results[0]
					: null;
			const resultPid =
				(resultEntry &&
					typeof resultEntry.pid === "string" &&
					resultEntry.pid.trim()) ||
				(resultEntry &&
					typeof resultEntry.postId === "string" &&
					resultEntry.postId.trim()) ||
				(resultEntry &&
					typeof resultEntry.post_id === "string" &&
					resultEntry.post_id.trim()) ||
				null;

			let merged = current;
			if (!existingPid && wrapperPid) {
				merged = { ...merged, pid: wrapperPid };
			}
			if (!existingPid && !wrapperPid && resultPid) {
				merged = { ...merged, pid: resultPid };
			}
			return merged;
		})();

		const pidForRef = (() => {
			const candidate =
				typeof (mergedPayload as any)?.pid === "string"
					? String((mergedPayload as any).pid).trim()
					: typeof (mergedPayload as any)?.postId === "string"
						? String((mergedPayload as any).postId).trim()
						: typeof (mergedPayload as any)?.post_id === "string"
							? String((mergedPayload as any).post_id).trim()
							: "";
			return candidate ? candidate : null;
		})();
		if (pidForRef) {
			const nowIso = new Date().toISOString();
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{
						kind: "video",
						taskId,
						vendor: vendorForLog,
						pid: pidForRef,
					},
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert video pid failed",
					err?.message || err,
				);
			}
		}
		const status = mapTaskStatus(payload.status || data?.status);
		const progress = clampProgress(
			typeof payload.progress === "number"
				? payload.progress
				: typeof payload.progress_pct === "number"
					? payload.progress_pct * 100
					: undefined,
		);

		let assetPayload: any = undefined;
		let promptForAsset: string | null =
			typeof promptFromClient === "string" &&
			promptFromClient.trim()
				? promptFromClient.trim()
				: null;

		if (status === "succeeded") {
			const extractVideoUrl = (value: any): string | null => {
				if (typeof value === "string" && value.trim()) return value.trim();
				if (!value || typeof value !== "object") return null;
				const url =
					typeof (value as any).url === "string" && (value as any).url.trim()
						? String((value as any).url).trim()
						: null;
				return url;
			};

			// 优先从 results 数组解析视频
			const resultEntry =
				Array.isArray(payload.results) && payload.results.length
					? payload.results[0]
					: null;
			const resultUrl =
				(typeof resultEntry?.url === "string" &&
					resultEntry.url.trim()) ||
				null;
			const resultThumb =
				(typeof resultEntry?.thumbnailUrl === "string" &&
					resultEntry.thumbnailUrl.trim()) ||
				(typeof resultEntry?.thumbnail_url === "string" &&
					resultEntry.thumbnail_url.trim()) ||
				null;

			const directVideo =
				extractVideoUrl((payload as any).video_url) ||
				extractVideoUrl((payload as any).videoUrl) ||
				resultUrl ||
				null;
			let videoUrl: string | null = directVideo;

			if (!videoUrl && typeof payload.content === "string") {
				const match = payload.content.match(
					/<video[^>]+src=['"]([^'"]+)['"][^>]*>/i,
				);
				if (match && match[1] && match[1].trim()) {
					videoUrl = match[1].trim();
				}
			}

			if (!videoUrl && typeof payload.content === "string") {
				const images = extractMarkdownImageUrlsFromText(payload.content);
				if (images.length) {
					assetPayload = {
						type: "image",
						url: images[0],
						thumbnailUrl: null,
					};
				}
			} else if (videoUrl) {
				const thumbnail =
					(typeof payload.thumbnail_url === "string" &&
						payload.thumbnail_url.trim()) ||
					(typeof payload.thumbnailUrl === "string" &&
						payload.thumbnailUrl.trim()) ||
					resultThumb ||
					null;
				assetPayload = {
					type: "video",
					url: videoUrl,
					thumbnailUrl: thumbnail,
				};
				const upstreamPrompt =
					(typeof payload.prompt === "string" &&
						payload.prompt.trim()) ||
					(payload.input &&
						typeof (payload.input as any).prompt === "string" &&
						(payload.input as any).prompt.trim()) ||
					"";
				if (upstreamPrompt) {
					promptForAsset = upstreamPrompt;
				}
			}
		}

		if (assetPayload) {
			const asset = TaskAssetSchema.parse(assetPayload);

			let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
			try {
				hostedAssets = await hostTaskAssetsInWorker({
					c,
					userId,
					assets: [asset],
					meta: {
						taskKind: "text_to_video",
						prompt: promptForAsset,
						vendor: "sora2api",
						modelKey:
							typeof payload.model === "string"
								? payload.model
								: undefined,
						taskId: taskId ?? null,
					},
				});
			} catch (err: any) {
				const message =
					typeof err?.message === "string" && err.message.trim()
						? err.message.trim()
						: "OSS 托管失败，稍后重试";
				const result = TaskResultSchema.parse({
					id: taskId,
					kind: "text_to_video",
					status: "running",
					assets: [],
					raw: {
						provider: "sora2api",
						response: mergedPayload,
						progress,
						hosting: { status: "pending", message },
					},
				});
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: vendorForLog,
					taskKind: "text_to_video",
					result,
				});
				return result;
			}

			const result = TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "succeeded",
				assets: hostedAssets,
				raw: {
					provider: "sora2api",
					response: mergedPayload,
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind: "text_to_video",
				result,
			});
			return result;
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status,
			assets: [],
			raw: {
				provider: "sora2api",
				response: mergedPayload,
				progress,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind: "text_to_video",
			result,
		});
		return result;
	}

	throw new AppError(lastError?.message || "sora2api 任务查询失败", {
		status: lastError?.status ?? 502,
		code: "sora2api_result_failed",
		details: {
			upstreamStatus: lastError?.status ?? null,
			upstreamData: lastError?.data ?? null,
			endpointTried: lastError?.endpoint ?? null,
		},
	});
}

function normalizeAsyncDataTaskStatus(value: unknown): TaskStatus {
	if (typeof value !== "string") return "running";
	const normalized = value.trim().toLowerCase();
	if (!normalized) return "running";
	if (
		normalized === "completed" ||
		normalized === "complete" ||
		normalized === "succeeded" ||
		normalized === "success" ||
		normalized === "done"
	) {
		return "succeeded";
	}
	if (
		normalized === "failed" ||
		normalized === "failure" ||
		normalized === "error" ||
		normalized === "cancelled" ||
		normalized === "canceled"
	) {
		return "failed";
	}
	if (normalized === "queued" || normalized === "pending" || normalized === "submitted") {
		return "queued";
	}
	if (
		normalized === "running" ||
		normalized === "processing" ||
		normalized === "generating" ||
		normalized === "in_progress" ||
		normalized === "in-progress"
	) {
		return "running";
	}
	return "running";
}

function looksLikeAsyncDataVideoUrl(url: string): boolean {
	const trimmed = (url || "").trim();
	if (!trimmed) return false;
	if (looksLikeVideoUrl(trimmed)) return true;
	const lower = trimmed.toLowerCase();
	// OpenAI signed URLs may not have an explicit video extension.
	if (lower.includes("videos.openai.com/")) return true;
	return false;
}

export async function fetchAsyncDataTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
	options?: { taskKind?: TaskRequestDto["kind"] | null; promptFromClient?: string | null },
): Promise<TaskResult> {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}

	const taskKind: TaskRequestDto["kind"] =
		typeof options?.taskKind === "string" && options.taskKind.trim()
			? (options.taskKind as TaskRequestDto["kind"])
			: "text_to_video";

	const refForTask = await (async () => {
		try {
			return await getVendorTaskRefByTaskId(c.env.DB, userId, "video", taskId);
		} catch {
			return null;
		}
	})();

	// Enforce per-user task ownership (asyncdata is a public endpoint).
	if (!refForTask) {
		throw new AppError("taskId is not found", {
			status: 404,
			code: "task_not_found",
		});
	}

	const vendorRefRaw =
		typeof refForTask?.vendor === "string" ? refForTask.vendor.trim() : "";
	const vendorForLog = (() => {
		if (!vendorRefRaw) return "asyncdata";
		const head = vendorRefRaw.split(":")[0]?.trim() || "";
		return head || vendorRefRaw;
	})();

	const pid = typeof refForTask?.pid === "string" ? refForTask.pid.trim() : "";
	if (refForTask && !pid && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(taskId.trim())) {
		const result = TaskResultSchema.parse({
			id: taskId.trim(),
			kind: taskKind,
			status: "running",
			assets: [],
			raw: {
				provider: "asyncdata",
				vendor: vendorForLog,
				upstreamTaskId: null,
				waitingUpstreamTaskId: true,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind,
			result,
		});
		return result;
	}

	const upstreamTaskId = pid || taskId.trim();
	const canonicalTaskId = upstreamTaskId;

	const payload = await callJsonApi(
		c,
		`https://pro.asyncdata.net/source/${encodeURIComponent(upstreamTaskId)}`,
		{
			method: "GET",
			headers: { Accept: "application/json" },
		},
		{ provider: "asyncdata" },
	);

	let status = normalizeAsyncDataTaskStatus(payload?.status);
	const progress =
		typeof payload?.progress === "number" && Number.isFinite(payload.progress)
			? Math.max(0, Math.min(100, Math.round(payload.progress)))
			: undefined;

	const pickVideoUrl = (): string | null => {
		const candidates = [
			payload?.url,
			payload?.draft_info?.downloadable_url,
			payload?.draft_info?.download_urls?.no_watermark,
			payload?.draft_info?.download_urls?.watermark,
			payload?.draft_info?.url,
		];
		for (const v of candidates) {
			if (typeof v === "string" && v.trim() && looksLikeAsyncDataVideoUrl(v)) {
				return v.trim();
			}
		}
		for (const v of candidates) {
			if (typeof v === "string" && v.trim()) return v.trim();
		}
		return null;
	};

	const videoUrl = pickVideoUrl();
	const thumbRaw =
		(typeof payload?.thumbnail_url === "string" && payload.thumbnail_url.trim()) ||
		(typeof payload?.thumbnailUrl === "string" && payload.thumbnailUrl.trim()) ||
		(typeof payload?.gif_url === "string" && payload.gif_url.trim()) ||
		(typeof payload?.gifUrl === "string" && payload.gifUrl.trim()) ||
		null;

	if (status === "succeeded" && !videoUrl) {
		status = "running";
	}
	if (status !== "succeeded" && videoUrl) {
		// Some upstreams only populate URLs late; treat presence of a downloadable URL as success.
		status = "succeeded";
	}

	if (status === "succeeded" && videoUrl) {
		const asset = TaskAssetSchema.parse({
			type: "video",
			url: videoUrl,
			thumbnailUrl: thumbRaw ? thumbRaw.trim() : null,
		});

		const promptForAsset =
			typeof options?.promptFromClient === "string" && options.promptFromClient.trim()
				? options.promptFromClient.trim()
				: null;

		let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		try {
			hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets: [asset],
				meta: {
					taskKind,
					prompt: promptForAsset,
					vendor: vendorForLog,
					taskId: canonicalTaskId,
				},
			});
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			const result = TaskResultSchema.parse({
				id: canonicalTaskId,
				kind: taskKind,
				status: "running",
				assets: [],
				raw: {
					provider: "asyncdata",
					vendor: vendorForLog,
					upstreamTaskId,
					requestedTaskId: taskId.trim() !== canonicalTaskId ? taskId.trim() : null,
					response: payload ?? null,
					progress,
					hosting: { status: "pending", message },
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind,
				result,
			});
			return result;
		}

		const result = TaskResultSchema.parse({
			id: canonicalTaskId,
			kind: taskKind,
			status: "succeeded",
			assets: hostedAssets,
			raw: {
				provider: "asyncdata",
				vendor: vendorForLog,
				upstreamTaskId,
				requestedTaskId: taskId.trim() !== canonicalTaskId ? taskId.trim() : null,
				response: payload ?? null,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind,
			result,
		});
		return result;
	}

	const result = TaskResultSchema.parse({
		id: canonicalTaskId,
		kind: taskKind,
		status,
		assets: [],
		raw: {
			provider: "asyncdata",
			vendor: vendorForLog,
			upstreamTaskId,
			requestedTaskId: taskId.trim() !== canonicalTaskId ? taskId.trim() : null,
			response: payload ?? null,
			progress,
		},
	});
	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: vendorForLog,
		taskKind,
		result,
	});
	return result;
}

export async function fetchTuziTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
	options?: { taskKind?: TaskRequestDto["kind"] | null; promptFromClient?: string | null },
): Promise<TaskResult> {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}

	const taskKind: TaskRequestDto["kind"] =
		typeof options?.taskKind === "string" && options.taskKind.trim()
			? (options.taskKind as TaskRequestDto["kind"])
			: "text_to_video";

	const refForTask = await (async () => {
		try {
			return await getVendorTaskRefByTaskId(c.env.DB, userId, "video", taskId);
		} catch {
			return null;
		}
	})();

	// Enforce per-user task ownership.
	if (!refForTask) {
		throw new AppError("taskId is not found", {
			status: 404,
			code: "task_not_found",
		});
	}

	const vendorRefRaw =
		typeof refForTask?.vendor === "string" ? refForTask.vendor.trim() : "";
	const vendorForLog = vendorRefRaw ? vendorRefRaw.split(":")[0]?.trim() || "tuzi" : "tuzi";
	const dispatchTail = vendorRefRaw
		? vendorRefRaw.split(":").slice(-1)[0]?.trim().toLowerCase() || ""
		: "";
	if (dispatchTail === "asyncdata") {
		return fetchAsyncDataTaskResult(c, userId, taskId, options);
	}

	const pid = typeof refForTask?.pid === "string" ? refForTask.pid.trim() : "";
	const upstreamTaskId = pid || taskId.trim();

	const ctx = await resolveVendorContext(c, userId, "tuzi");
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = ctx.apiKey.trim();
	if (!baseUrl || !apiKey) {
		throw new AppError("未配置 Tuzi API Key", {
			status: 400,
			code: "tuzi_api_key_missing",
		});
	}

	const candidates = [
		new URL(`/v1/videos/${encodeURIComponent(upstreamTaskId)}`, baseUrl).toString(),
		new URL(`/v1/videos?task_id=${encodeURIComponent(upstreamTaskId)}`, baseUrl).toString(),
		new URL(`/v1/videos?id=${encodeURIComponent(upstreamTaskId)}`, baseUrl).toString(),
	];

	let payload: any = null;
	let lastError: { status?: number; data?: any; message?: string; url?: string } | null =
		null;

	for (const url of candidates) {
		let res: Response;
		let data: any = null;
		try {
			res = await fetchWithHttpDebugLog(
				c,
				url,
				{
					method: "GET",
					headers: {
						Authorization: `Bearer ${apiKey}`,
						Accept: "application/json",
					},
				},
				{ tag: "tuzi:videos:result" },
			);
			try {
				data = await res.json();
			} catch {
				data = null;
			}
		} catch (err: any) {
			lastError = { message: err?.message ?? String(err), url };
			continue;
		}

		if (!res.ok) {
			lastError = { status: res.status, data, url };
			continue;
		}

		payload = data;
		break;
	}

	if (!payload) {
		const msg =
			(lastError?.data &&
				(lastError.data.error?.message || lastError.data.message || lastError.data.error)) ||
			lastError?.message ||
			"Tuzi 结果查询失败";
		throw new AppError(msg, {
			status: lastError?.status ?? 502,
			code: "tuzi_result_failed",
			details: {
				upstreamStatus: lastError?.status ?? null,
				upstreamData: lastError?.data ?? null,
				endpointTried: lastError?.url ?? null,
			},
		});
	}

	let status = normalizeTuziVideoTaskStatus(
		payload?.status ?? payload?.data?.status ?? payload?.result?.status,
	);
	const progress =
		typeof payload?.progress === "number" && Number.isFinite(payload.progress)
			? Math.max(0, Math.min(100, Math.round(payload.progress)))
			: typeof payload?.data?.progress === "number" && Number.isFinite(payload.data.progress)
				? Math.max(0, Math.min(100, Math.round(payload.data.progress)))
				: undefined;

	const videoUrl =
		extractSora2OfficialVideoUrl(payload) ||
		extractSora2OfficialVideoUrl(payload?.data) ||
		null;
	const thumbRaw =
		(typeof payload?.thumbnail_url === "string" && payload.thumbnail_url.trim()) ||
		(typeof payload?.thumbnailUrl === "string" && payload.thumbnailUrl.trim()) ||
		(typeof payload?.gif_url === "string" && payload.gif_url.trim()) ||
		(typeof payload?.gifUrl === "string" && payload.gifUrl.trim()) ||
		(null as string | null);

	if (status === "succeeded" && !videoUrl) {
		status = "running";
	}
	if (status !== "succeeded" && videoUrl) {
		status = "succeeded";
	}

	if (status === "succeeded" && videoUrl) {
		const asset = TaskAssetSchema.parse({
			type: "video",
			url: videoUrl,
			thumbnailUrl: thumbRaw ? thumbRaw.trim() : null,
		});

		const promptForAsset =
			typeof options?.promptFromClient === "string" && options.promptFromClient.trim()
				? options.promptFromClient.trim()
				: null;

		let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		try {
			hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets: [asset],
				meta: {
					taskKind,
					prompt: promptForAsset,
					vendor: vendorForLog,
					modelKey:
						typeof payload?.model === "string"
							? payload.model
							: typeof payload?.data?.model === "string"
								? payload.data.model
								: undefined,
					taskId: upstreamTaskId || null,
				},
			});
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			const result = TaskResultSchema.parse({
				id: upstreamTaskId,
				kind: taskKind,
				status: "running",
				assets: [],
				raw: {
					provider: "tuzi",
					vendor: vendorForLog,
					upstreamTaskId,
					response: payload ?? null,
					progress,
					hosting: { status: "pending", message },
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind,
				result,
			});
			return result;
		}

		const result = TaskResultSchema.parse({
			id: upstreamTaskId,
			kind: taskKind,
			status: "succeeded",
			assets: hostedAssets,
			raw: {
				provider: "tuzi",
				vendor: vendorForLog,
				upstreamTaskId,
				response: payload ?? null,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind,
			result,
		});
		return result;
	}

	if (status === "failed") {
		const errorMessage = (() => {
			const candidates = [
				payload?.error?.message,
				payload?.error_message,
				payload?.message,
				payload?.error,
				payload?.data?.error?.message,
				payload?.data?.error_message,
				payload?.data?.message,
				payload?.data?.error,
			];
			for (const value of candidates) {
				if (typeof value === "string" && value.trim()) return value.trim();
			}
			return null;
		})();

		const result = TaskResultSchema.parse({
			id: upstreamTaskId,
			kind: taskKind,
			status: "failed",
			assets: [],
			raw: {
				provider: "tuzi",
				vendor: vendorForLog,
				upstreamTaskId,
				response: payload ?? null,
				progress,
				error: errorMessage,
				message: errorMessage,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind,
			result,
		});
		return result;
	}

	const result = TaskResultSchema.parse({
		id: upstreamTaskId,
		kind: taskKind,
		status,
		assets: [],
		raw: {
			provider: "tuzi",
			vendor: vendorForLog,
			upstreamTaskId,
			response: payload ?? null,
			progress,
		},
	});
	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: vendorForLog,
		taskKind,
		result,
	});
	return result;
}

function normalizeGrsaiDrawTaskStatus(value: unknown): TaskStatus {
	if (typeof value !== "string") return "running";
	const normalized = value.trim().toLowerCase();
	if (!normalized) return "running";
	if (
		normalized === "succeeded" ||
		normalized === "success" ||
		normalized === "completed"
	) {
		return "succeeded";
	}
	if (
		normalized === "failed" ||
		normalized === "failure" ||
		normalized === "error"
	) {
		return "failed";
	}
	if (normalized === "queued" || normalized === "submitted") {
		return "queued";
	}
	if (
		normalized === "processing" ||
		normalized === "in_progress" ||
		normalized === "running"
	) {
		return "running";
	}
	return "running";
}

function normalizeApimartTaskStatus(value: unknown): TaskStatus {
	if (typeof value !== "string") return "running";
	const normalized = value.trim().toLowerCase();
	if (!normalized) return "running";
	if (normalized === "submitted" || normalized === "pending") return "queued";
	if (normalized === "processing") return "running";
	if (normalized === "completed") return "succeeded";
	if (normalized === "failed" || normalized === "cancelled") return "failed";
	return "running";
}

function normalizeYunwuVideoTaskStatus(value: unknown): TaskStatus {
	if (typeof value !== "string") return "running";
	const normalized = value.trim().toLowerCase();
	if (!normalized) return "running";
	if (normalized === "pending" || normalized === "submitted" || normalized === "queued") {
		return "queued";
	}
	if (
		normalized === "processing" ||
		normalized === "running" ||
		normalized === "in_progress" ||
		normalized === "in-progress"
	) {
		return "running";
	}
	if (
		normalized === "success" ||
		normalized === "succeeded" ||
		normalized === "completed" ||
		normalized === "done"
	) {
		return "succeeded";
	}
	if (
		normalized === "failed" ||
		normalized === "failure" ||
		normalized === "error" ||
		normalized === "cancelled" ||
		normalized === "canceled"
	) {
		return "failed";
	}
	return "running";
}

function extractApimartMediaUrls(
	payload: any,
	key: "images" | "videos",
): string[] {
	const result = payload && typeof payload === "object" ? payload.result : null;
	const items = Array.isArray(result?.[key]) ? result[key] : [];
	const urls: string[] = [];
	for (const item of items) {
		const value = (item as any)?.url;
		if (typeof value === "string" && value.trim()) {
			urls.push(value.trim());
			continue;
		}
		if (Array.isArray(value)) {
			for (const entry of value) {
				if (typeof entry === "string" && entry.trim()) {
					urls.push(entry.trim());
				}
			}
		}
	}
	return Array.from(new Set(urls));
}

function extractApimartThumbnailUrl(payload: any): string | null {
	if (!payload || typeof payload !== "object") return null;
	const result = (payload as any).result;
	const candidates = [
		result?.thumbnail_url,
		result?.thumbnailUrl,
		(payload as any).thumbnail_url,
		(payload as any).thumbnailUrl,
	];
	for (const value of candidates) {
		if (typeof value === "string" && value.trim()) return value.trim();
	}
	return null;
}

export async function fetchGrsaiDrawTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
	options?: { taskKind?: TaskRequestDto["kind"] | null; promptFromClient?: string | null },
): Promise<TaskResult> {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}

	const refForLog = await (async () => {
		try {
			return await getVendorTaskRefByTaskId(
				c.env.DB,
				userId,
				"image",
				taskId,
			);
		} catch {
			return null;
		}
	})();

	let vendorForLog =
		(typeof refForLog?.vendor === "string" && refForLog.vendor.trim()) ||
		"grsai";
	{
		const hint = extractChannelVendor(vendorForLog);
		if (hint) {
			try {
				c.set("proxyVendorHint", hint);
			} catch {
				// ignore
			}
		}
	}
	const taskKind: TaskRequestDto["kind"] =
		typeof options?.taskKind === "string" && options.taskKind.trim()
			? (options.taskKind as TaskRequestDto["kind"])
			: "text_to_image";
	const pid =
		typeof refForLog?.pid === "string" ? refForLog.pid.trim() : "";
	if (refForLog && !pid) {
		const result = TaskResultSchema.parse({
			id: taskId,
			kind: taskKind,
			status: "running",
			assets: [],
			raw: {
				provider: "grsai",
				vendor: vendorForLog,
				upstreamTaskId: null,
				waitingUpstreamTaskId: true,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind,
			result,
		});
		return result;
	}
	const upstreamTaskId = pid || taskId.trim();

	const ctx = await resolveVendorContext(c, userId, "gemini");
	if (ctx.viaProxyVendor === "comfly") {
		throw new AppError("comfly 代理暂不支持 /v1/draw/result 查询", {
			status: 400,
			code: "draw_result_not_supported",
		});
	}

	const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "https://api.grsai.com";
	const isApimartBase =
		isApimartBaseUrl(baseUrl) || ctx.viaProxyVendor === "apimart";
	if (vendorForLog === "grsai" && isApimartBase) {
		vendorForLog = "apimart";
	}
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(
			isApimartBase ? "未配置 apimart API Key" : "未配置 grsai API Key",
			{
			status: 400,
			code: "banana_api_key_missing",
			},
		);
	}

	if (isApimartBase) {
		const wrapper = await callJsonApi(
			c,
			`${normalizeApimartBaseUrl(baseUrl)}/v1/tasks/${encodeURIComponent(
				upstreamTaskId,
			)}?language=zh`,
			{
				method: "GET",
				headers: { Authorization: `Bearer ${apiKey}` },
			},
			{ provider: "apimart" },
		);

		if (typeof wrapper?.code === "number" && wrapper.code !== 200) {
			throw new AppError(
				(wrapper?.error?.message ||
					wrapper?.message ||
					`apimart 任务查询失败: code ${wrapper.code}`) as string,
				{
					status: 502,
					code: "apimart_result_failed",
					details: { upstreamData: wrapper ?? null },
				},
			);
		}

		const payload =
			wrapper && typeof wrapper === "object" && wrapper.data
				? wrapper.data
				: wrapper ?? {};
		let status = normalizeApimartTaskStatus(payload?.status);
		const progress = clampProgress(
			typeof payload?.progress === "number" ? payload.progress : undefined,
		);

		const urls = extractApimartMediaUrls(payload, "images");
		if (urls.length > 0 && status !== "failed") {
			status = "succeeded";
		}
		if (status === "succeeded" && urls.length === 0) {
			status = "running";
		}

		const failureReasonRaw =
			(typeof payload?.error?.message === "string" &&
				payload.error.message.trim()) ||
			(typeof payload?.error?.type === "string" &&
				payload.error.type.trim()) ||
			(typeof wrapper?.error?.message === "string" &&
				wrapper.error.message.trim()) ||
			null;

		let assets: Array<ReturnType<typeof TaskAssetSchema.parse>> = [];
		if (status === "succeeded" && urls.length > 0) {
			assets = urls.map((url) =>
				TaskAssetSchema.parse({ type: "image", url, thumbnailUrl: null }),
			);
			const promptForAsset =
				(typeof options?.promptFromClient === "string" &&
					options.promptFromClient.trim()) ||
				null;
			try {
				const hostedAssets = await hostTaskAssetsInWorker({
					c,
					userId,
					assets,
					meta: {
						taskKind,
						prompt: promptForAsset,
						vendor: vendorForLog,
						taskId: taskId ?? null,
					},
				});
				assets = hostedAssets;
			} catch (err: any) {
				const message =
					typeof err?.message === "string" && err.message.trim()
						? err.message.trim()
						: "OSS 托管失败，稍后重试";
				const result = TaskResultSchema.parse({
					id: taskId,
					kind: taskKind,
					status: "running",
					assets: [],
					raw: {
						provider: "apimart",
						vendor: vendorForLog,
						upstreamTaskId,
						response: payload,
						progress,
						failureReason: failureReasonRaw,
						wrapper: wrapper ?? null,
						hosting: { status: "pending", message },
					},
				});
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: vendorForLog,
					taskKind,
					result,
				});
				return result;
			}
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: taskKind,
			status,
			assets,
			raw: {
				provider: "apimart",
				vendor: vendorForLog,
				upstreamTaskId,
				response: payload,
				progress,
				failureReason: failureReasonRaw,
				wrapper: wrapper ?? null,
			},
		});

		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: vendorForLog,
			taskKind,
			result,
		});

		return result;
	}

	let res: Response;
	let data: any = null;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl.replace(/\/+$/, "")}/v1/draw/result`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify({ id: upstreamTaskId }),
			},
			{ tag: "grsai:drawResult" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("grsai 任务查询失败", {
			status: 502,
			code: "grsai_result_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	if (res.status < 200 || res.status >= 300) {
		const msg =
			(data &&
				(data.error?.message ||
					data.message ||
					data.error ||
					data.error_message)) ||
			`grsai 任务查询失败: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "grsai_result_failed",
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	const payload =
		data && typeof data === "object" && data.data ? data.data : data ?? {};

	const statusRaw =
		(typeof payload?.status === "string" && payload.status.trim()) ||
		(typeof data?.status === "string" && data.status.trim()) ||
		null;
	let status = normalizeGrsaiDrawTaskStatus(statusRaw);

	const progress = clampProgress(
		typeof payload?.progress === "number"
			? payload.progress <= 1
				? payload.progress * 100
				: payload.progress
			: typeof payload?.progress_pct === "number"
				? payload.progress_pct <= 1
					? payload.progress_pct * 100
					: payload.progress_pct
				: undefined,
	);

	const urls = extractBananaImageUrls(payload);
	if (urls.length > 0 && status !== "failed") {
		status = "succeeded";
	}

	const failureReasonRaw =
		(typeof payload?.failure_reason === "string" &&
			payload.failure_reason.trim()) ||
		(typeof payload?.error === "string" && payload.error.trim()) ||
		(typeof payload?.message === "string" && payload.message.trim()) ||
		(typeof data?.error === "string" && data.error.trim()) ||
		null;

	let assets: Array<ReturnType<typeof TaskAssetSchema.parse>> = [];
	if (status === "succeeded" && urls.length > 0) {
		assets = urls.map((url) =>
			TaskAssetSchema.parse({ type: "image", url, thumbnailUrl: null }),
		);
		const promptForAsset =
			(typeof options?.promptFromClient === "string" &&
				options.promptFromClient.trim()) ||
			(typeof payload?.prompt === "string" && payload.prompt.trim()) ||
			null;
		try {
			const hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets,
				meta: {
					taskKind,
					prompt: promptForAsset,
					vendor: vendorForLog,
					taskId: taskId ?? null,
				},
			});
			assets = hostedAssets;
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			const result = TaskResultSchema.parse({
				id: taskId,
				kind: taskKind,
				status: "running",
				assets: [],
				raw: {
					provider: "grsai",
					vendor: vendorForLog,
					upstreamTaskId,
					response: payload,
					progress,
					failureReason: failureReasonRaw,
					wrapper: data ?? null,
					hosting: { status: "pending", message },
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: vendorForLog,
				taskKind,
				result,
			});
			return result;
		}
	}

	const result = TaskResultSchema.parse({
		id: taskId,
		kind: taskKind,
		status,
		assets,
		raw: {
			provider: "grsai",
			vendor: vendorForLog,
			upstreamTaskId,
			response: payload,
			progress,
			failureReason: failureReasonRaw,
			wrapper: data ?? null,
		},
	});

	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: vendorForLog,
		taskKind,
		result,
	});

	return result;
}

	// ---------- MiniMax / Hailuo ----------

	function normalizeMiniMaxModelKey(modelKey?: string | null): string {
		const trimmed = (modelKey || "").trim();
		if (!trimmed) return "MiniMax-Hailuo-02";
		const lower = trimmed.toLowerCase();
		if (
			lower === "hailuo" ||
			lower === "hailuo-02" ||
			lower === "minimax-hailuo-02" ||
			lower === "minimax_hailuo_02"
		) {
			return "MiniMax-Hailuo-02";
		}
		if (
			lower === "i2v-01-director" ||
			lower === "i2v_01_director" ||
			lower === "i2v-01_director"
		) {
			return "I2V-01-Director";
		}
		if (lower === "i2v-01-live" || lower === "i2v_01_live") {
			return "I2V-01-live";
		}
		if (lower === "i2v-01" || lower === "i2v_01") {
			return "I2V-01";
		}
		return trimmed;
	}

	function normalizeEnumSeconds(
		requestedSeconds: number | null | undefined,
		allowedSeconds: readonly number[],
		fallbackSeconds: number,
	): { seconds: number; changed: boolean } {
		const fallback =
			typeof fallbackSeconds === "number" && Number.isFinite(fallbackSeconds)
				? Math.floor(fallbackSeconds)
				: 10;
		const requested =
			typeof requestedSeconds === "number" && Number.isFinite(requestedSeconds)
				? Math.floor(requestedSeconds)
				: NaN;

		if (!Number.isFinite(requested) || requested <= 0) {
			return { seconds: fallback, changed: true };
		}

		if (!allowedSeconds.length) {
			return { seconds: requested, changed: false };
		}

		let best = allowedSeconds[0]!;
		let bestDiff = Math.abs(requested - best);
		for (const candidate of allowedSeconds) {
			const diff = Math.abs(requested - candidate);
			if (diff < bestDiff || (diff === bestDiff && candidate > best)) {
				best = candidate;
				bestDiff = diff;
			}
		}
		return { seconds: best, changed: best !== requested };
	}

	function extractMiniMaxErrorMessage(data: any): string | null {
		if (!data) return null;
		const candidates = [
			data?.error?.message,
			data?.error?.msg,
			data?.error?.error_message,
			data?.base_resp?.status_msg,
			data?.message,
			data?.msg,
			data?.error,
		];
		for (const value of candidates) {
			if (typeof value === "string" && value.trim()) return value.trim();
		}
		if (data?.error && typeof data.error === "object") {
			try {
				return JSON.stringify(data.error);
			} catch {
				// ignore
			}
		}
		return null;
	}

	export async function runMiniMaxVideoTask(
		c: AppContext,
		userId: string,
		req: TaskRequestDto,
	): Promise<TaskResult> {
		const extras = (req.extras || {}) as Record<string, any>;
		const modelRaw =
			(typeof extras.modelKey === "string" && extras.modelKey.trim()) || "";
		const model = normalizeMiniMaxModelKey(modelRaw);
		const required = await resolveTeamCreditsCostForTask(c, {
			taskKind: req.kind,
			modelKey: model,
		});
		const progressCtx = extractProgressContext(req, "minimax");

		const ctx = await resolveVendorContext(c, userId, "minimax");
		const baseUrl = normalizeBaseUrl(ctx.baseUrl);
		const channelVendor: "grsai" | "comfly" | null =
			ctx.viaProxyVendor === "comfly"
				? "comfly"
				: isGrsaiBaseUrl(baseUrl) || ctx.viaProxyVendor === "grsai"
					? "grsai"
					: null;
		const apiKey = ctx.apiKey.trim();
		if (!baseUrl || !apiKey) {
			throw new AppError("未配置 MiniMax API Key", {
				status: 400,
				code: "minimax_api_key_missing",
			});
		}
		const durationSeconds =
			typeof (req as any).durationSeconds === "number" &&
			Number.isFinite((req as any).durationSeconds)
				? Math.floor((req as any).durationSeconds)
			: typeof extras.durationSeconds === "number" &&
					Number.isFinite(extras.durationSeconds)
				? Math.floor(extras.durationSeconds)
				: null;
		const resolution =
			typeof extras.resolution === "string" && extras.resolution.trim()
				? extras.resolution.trim()
				: null;
		const firstFrameImageRaw =
			(typeof (extras as any).first_frame_image === "string" &&
				String((extras as any).first_frame_image).trim()) ||
			(typeof extras.firstFrameImage === "string" &&
				extras.firstFrameImage.trim()) ||
			(typeof extras.firstFrameUrl === "string" &&
				extras.firstFrameUrl.trim()) ||
			(typeof extras.url === "string" && extras.url.trim()) ||
			null;

		if (!firstFrameImageRaw) {
			throw new AppError(
				"MiniMax 图生视频需要提供首帧图片（first_frame_image）",
				{
					status: 400,
					code: "minimax_first_frame_missing",
				},
			);
		}

			const firstFrameImage = await (async () => {
				const trimmed = String(firstFrameImageRaw).trim();
				if (!trimmed) return trimmed;
				if (/^data:image\//i.test(trimmed)) return trimmed;

				if (/^blob:/i.test(trimmed)) {
					throw new AppError(
						"MiniMax 首帧图片不支持 blob: URL，请先上传为可访问的图片地址",
						{
							status: 400,
							code: "minimax_first_frame_invalid",
						},
					);
				}

				const isHttp = /^https?:\/\//i.test(trimmed);
				const isRelative = trimmed.startsWith("/");
				if (!isHttp && !isRelative) {
					throw new AppError(
						"MiniMax 首帧图片必须是 http(s) URL 或 data:image/*;base64,...",
						{
							status: 400,
							code: "minimax_first_frame_invalid",
							details: { firstFrameImage: trimmed.slice(0, 64) },
						},
					);
				}

				const absolute = isRelative
					? new URL(trimmed, new URL(c.req.url).origin).toString()
					: trimmed;

				try {
					// Prefer inlining as base64 to avoid upstreams failing to fetch private/local URLs.
					return await resolveSora2ApiImageUrl(c, absolute);
				} catch (err: any) {
					if (isHttp) {
						// Fallback: still send URL (may work in some deployments)
						return trimmed;
				}
				throw err;
			}
		})();

		const reservation = await requireSufficientTeamCredits(c, userId, {
			required,
			taskKind: req.kind,
			vendor: "minimax",
			modelKey: model,
		});
		emitProgress(userId, progressCtx, { status: "queued", progress: 0 });
		emitProgress(userId, progressCtx, { status: "running", progress: 5 });

		try {
		const promptOptimizer =
			typeof (extras as any).promptOptimizer === "boolean"
				? (extras as any).promptOptimizer
				: typeof (extras as any).prompt_optimizer === "boolean"
					? (extras as any).prompt_optimizer
					: undefined;

		// MiniMax duration only supports 6s / 10s; normalize to avoid upstream 2013 invalid params.
		const normalizedDuration = normalizeEnumSeconds(
			durationSeconds,
			[6, 10],
			10,
		);

		const body: Record<string, any> = {
			model,
			prompt: req.prompt,
			first_frame_image: firstFrameImage,
			...(typeof normalizedDuration.seconds === "number" &&
			normalizedDuration.seconds > 0
				? { duration: normalizedDuration.seconds }
				: {}),
			...(resolution ? { resolution } : {}),
			...(typeof promptOptimizer === "boolean"
				? { prompt_optimizer: promptOptimizer }
				: {}),
		};

		let res: Response;
		let data: any = null;
		try {
		res = await fetchWithHttpDebugLog(
			c,
			`${baseUrl}/minimax/v1/video_generation`,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "minimax:create" },
		);
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	} catch (error: any) {
		throw new AppError("MiniMax 视频任务创建失败", {
			status: 502,
			code: "minimax_request_failed",
			details: { message: error?.message ?? String(error) },
			});
		}

		if (!res.ok || (typeof data?.base_resp?.status_code === "number" && data.base_resp.status_code !== 0)) {
			const msg =
				extractMiniMaxErrorMessage(data) ||
				`MiniMax 视频任务创建失败：${res.status}`;
			throw new AppError(msg, {
				status:
					typeof data?.base_resp?.status_code === "number" &&
					data.base_resp.status_code !== 0
						? 502
						: res.status,
				code: "minimax_request_failed",
				details: { upstreamStatus: res.status, upstreamData: data ?? null },
			});
		}

	const taskId =
		(typeof data?.task_id === "string" && data.task_id.trim()) ||
		(typeof data?.taskId === "string" && data.taskId.trim()) ||
		(typeof data?.id === "string" && data.id.trim()) ||
		(typeof data?.data?.task_id === "string" && data.data.task_id.trim()) ||
		null;
	if (!taskId) {
		throw new AppError("MiniMax API 未返回 task_id", {
			status: 502,
			code: "minimax_task_id_missing",
			details: { upstreamData: data ?? null },
		});
	}

	emitProgress(userId, progressCtx, {
		status: "running",
		progress: 10,
		taskId,
		raw: data ?? null,
	});

	const result = TaskResultSchema.parse({
		id: taskId,
		kind: req.kind,
		status: "running",
		assets: [],
		raw: {
			provider: "minimax",
			model,
			taskId,
			response: data ?? null,
		},
	});
	await bindReservationToTaskId(c, userId, reservation, taskId);
	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: "minimax",
		taskKind: req.kind,
		result,
	});
	if (channelVendor) {
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: channelVendor,
			taskKind: req.kind,
			result,
		});
	}
	return result;
		} catch (err) {
			return await releaseReservationOnThrow(c, userId, reservation, err);
		}
}

function normalizeTuziVideoTaskStatus(value: unknown): TaskStatus {
	if (typeof value === "string") {
		const normalized = value.trim().toLowerCase();
		if (!normalized) return "running";
		if (
			normalized === "queued" ||
			normalized === "pending" ||
			normalized === "submitted" ||
			normalized === "waiting"
		) {
			return "queued";
		}
		if (
			normalized === "running" ||
			normalized === "processing" ||
			normalized === "generating" ||
			normalized === "in_progress" ||
			normalized === "in-progress"
		) {
			return "running";
		}
		if (
			normalized === "completed" ||
			normalized === "complete" ||
			normalized === "succeeded" ||
			normalized === "success" ||
			normalized === "done"
		) {
			return "succeeded";
		}
		if (
			normalized === "failed" ||
			normalized === "failure" ||
			normalized === "error" ||
			normalized === "cancelled" ||
			normalized === "canceled"
		) {
			return "failed";
		}
		return "running";
	}
	if (typeof value === "number" && Number.isFinite(value)) {
		const code = Math.floor(value);
		if (code === 0) return "queued";
		if (code === 1) return "running";
		if (code === 2) return "succeeded";
		if (code === 3 || code === -1) return "failed";
	}
	return "running";
}

function normalizeTuziVideoSeconds(
	requestedSeconds: number | null | undefined,
	isProModel: boolean,
): string {
	const requested =
		typeof requestedSeconds === "number" && Number.isFinite(requestedSeconds)
			? Math.max(1, Math.floor(requestedSeconds))
			: 10;

	// Explicit opt-in for OpenAI group seconds (4/8/12).
	if (requested === 4 || requested === 8 || requested === 12) {
		return String(requested);
	}
	if (requested <= 10) return "10";
	if (requested <= 15) return "15";
	return isProModel ? "25" : "15";
}

function normalizeTuziVideoSize(input: {
	sizeRaw: unknown;
	orientation: "portrait" | "landscape";
	isProModel: boolean;
}): string {
	const allowed = input.isProModel
		? new Set(["1280x720", "720x1280", "1024x1792", "1792x1024"])
		: new Set(["1280x720", "720x1280"]);
	const raw = typeof input.sizeRaw === "string" ? input.sizeRaw.trim() : "";
	const compact =
		raw && /^\d+\s*x\s*\d+$/i.test(raw) ? raw.replace(/\s+/g, "") : "";
	if (compact && allowed.has(compact)) return compact;

	const wantsHd = (() => {
		const lowered = raw.toLowerCase();
		if (lowered === "large" || lowered === "hd" || lowered === "high") return true;
		return false;
	})();

	if (input.orientation === "portrait") {
		return input.isProModel && wantsHd ? "1024x1792" : "720x1280";
	}
	return input.isProModel && wantsHd ? "1792x1024" : "1280x720";
}

async function runTuziVideoTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const v = "tuzi";
	const ctx = await resolveVendorContext(c, userId, v);
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = (ctx.apiKey || "").trim();
	if (!baseUrl) {
		throw new AppError(`No base URL configured for vendor ${v}`, {
			status: 400,
			code: "base_url_missing",
		});
	}
	if (!apiKey) {
		throw new AppError(`No API key configured for vendor ${v}`, {
			status: 400,
			code: "api_key_missing",
		});
	}

	const explicitModelKey = pickModelKey(req, { modelKey: undefined });
	const modelKeyRaw =
		explicitModelKey ||
		(await resolveDefaultModelKeyFromCatalogForVendor(c, v, "video"));
	const model = modelKeyRaw?.startsWith("models/") ? modelKeyRaw.slice(7) : modelKeyRaw;
	if (!model) {
		throw new AppError(
			"未配置可用的模型（请在 /stats -> 模型管理（系统级）为该厂商添加并启用 video 模型，或在请求里传 extras.modelKey）",
			{
				status: 400,
				code: "model_not_configured",
				details: { vendor: v, taskKind: req.kind },
			},
		);
	}
	const normalizedModel = model.toLowerCase();
	if (normalizedModel !== "sora-2" && normalizedModel !== "sora-2-pro") {
		throw new AppError("Tuzi /v1/videos 仅支持 sora-2 / sora-2-pro", {
			status: 400,
			code: "invalid_model",
			details: { vendor: v, model },
		});
	}
	const isProModel = normalizedModel === "sora-2-pro";

	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: v,
		modelKey: model,
	});

	try {
		const extras = (req.extras || {}) as Record<string, any>;
		const orientation = (() => {
			const raw =
				(typeof extras.orientation === "string" && extras.orientation.trim()) ||
				(typeof extras.videoOrientation === "string" &&
					extras.videoOrientation.trim()) ||
				"";
			if (raw === "portrait" || raw === "landscape") return raw;
			const ratio =
				(typeof extras.aspectRatio === "string" && extras.aspectRatio.trim()) ||
				(typeof extras.aspect_ratio === "string" && extras.aspect_ratio.trim()) ||
				"";
			if (ratio === "9:16") return "portrait";
			if (ratio === "16:9") return "landscape";
			return "landscape";
		})();

		const durationSeconds =
			typeof (req as any).durationSeconds === "number" &&
			Number.isFinite((req as any).durationSeconds)
				? (req as any).durationSeconds
				: typeof extras.durationSeconds === "number" &&
						Number.isFinite(extras.durationSeconds)
					? extras.durationSeconds
					: 10;
		const seconds = normalizeTuziVideoSeconds(durationSeconds, isProModel);
		const size = normalizeTuziVideoSize({
			sizeRaw: extras.size,
			orientation,
			isProModel,
		});

		const inputReferenceRaw =
			(typeof extras.input_reference === "string" &&
				extras.input_reference.trim()) ||
			(typeof extras.inputReference === "string" &&
				extras.inputReference.trim()) ||
			(typeof extras.firstFrameUrl === "string" &&
				extras.firstFrameUrl.trim()) ||
			(typeof extras.url === "string" && extras.url.trim()) ||
			(Array.isArray(extras.urls) && extras.urls[0]
				? String(extras.urls[0]).trim()
				: "") ||
			"";
		const inputReferenceUrl = inputReferenceRaw ? String(inputReferenceRaw).trim() : "";
		if (inputReferenceUrl && /^blob:/i.test(inputReferenceUrl)) {
			throw new AppError("Tuzi input_reference 不支持 blob: URL，请先上传为可访问的图片地址", {
				status: 400,
				code: "tuzi_input_reference_invalid",
			});
		}

		const absoluteInputReference = (() => {
			if (!inputReferenceUrl) return null;
			if (/^https?:\/\//i.test(inputReferenceUrl)) return inputReferenceUrl;
			if (inputReferenceUrl.startsWith("/")) {
				return new URL(inputReferenceUrl, new URL(c.req.url).origin).toString();
			}
			return inputReferenceUrl;
		})();

		const form = new FormData();
		form.append("model", model);
		form.append("prompt", req.prompt);
		form.append("seconds", seconds);
		form.append("size", size);
		if (absoluteInputReference) {
			// NOTE: Tuzi upstream validates `input_reference` as a file part (multipart/form-data).
			// If callers provide a URL, we try to fetch and upload the image bytes; if fetch fails,
			// fall back to sending the URL as a "file" (text/plain) so gateways that accept URL
			// payloads can still work.
			const ref = absoluteInputReference.trim();
			const filePart = await (async (): Promise<{
				blob: Blob;
				filename: string;
				meta: { url: string; mode: "fetched_file" | "url_file" | "data_url_file" };
			}> => {
				const dataUrlMatch = ref.match(/^data:([^;]+);base64,(.+)$/i);
				if (dataUrlMatch) {
					const mimeType = (dataUrlMatch[1] || "").trim() || "application/octet-stream";
					const base64 = (dataUrlMatch[2] || "").trim();
					const bytes = decodeBase64ToBytes(base64);
					const ext = detectImageExtensionFromMimeType(mimeType);
					return {
						blob: new Blob([bytes], { type: mimeType }),
						filename: `input_reference.${ext || "bin"}`,
						meta: { url: ref.slice(0, 64), mode: "data_url_file" },
					};
				}

				if (/^https?:\/\//i.test(ref)) {
					try {
						const res = await fetchWithHttpDebugLog(
							c,
							ref,
							{ method: "GET", headers: { Accept: "image/*,*/*;q=0.8" } },
							{ tag: "tuzi:input_reference:fetch" },
						);
						if (res.ok) {
							const contentType =
								(res.headers.get("content-type") || "").split(";")[0]?.trim() ||
								"application/octet-stream";
							const buf = await res.arrayBuffer();
							const extFromUrl = (() => {
								try {
									const pathname = new URL(ref).pathname || "";
									const m = pathname.match(/\.([a-zA-Z0-9]+)$/);
									return m && m[1] ? m[1].toLowerCase() : null;
								} catch {
									return null;
								}
							})();
							const ext = extFromUrl || detectImageExtensionFromMimeType(contentType);
							return {
								blob: new Blob([buf], { type: contentType }),
								filename: `input_reference.${ext || "bin"}`,
								meta: { url: ref, mode: "fetched_file" },
							};
						}
					} catch {
						// fall through to url-file fallback
					}
				}

				// Fallback: send URL as a file part (some gateways accept URL content).
				return {
					blob: new Blob([ref], { type: "text/plain" }),
					filename: "input_reference.url",
					meta: { url: ref, mode: "url_file" },
				};
			})();

			form.append("input_reference", filePart.blob, filePart.filename);
		}

		const url = new URL("/v1/videos", baseUrl).toString();
		let res: Response;
		let data: any = null;
		try {
			res = await fetchWithHttpDebugLog(
				c,
				url,
				{
					method: "POST",
					headers: {
						Authorization: `Bearer ${apiKey}`,
						Accept: "application/json",
					},
					body: form,
				},
				{ tag: "tuzi:videos:create" },
			);
			try {
				data = await res.json();
			} catch {
				data = null;
			}
		} catch (error: any) {
			throw new AppError("Tuzi 视频任务创建失败", {
				status: 502,
				code: "tuzi_request_failed",
				details: { message: error?.message ?? String(error) },
			});
		}

		if (!res.ok) {
			const msg =
				(data && (data.error?.message || data.message || data.error)) ||
				`Tuzi 视频任务创建失败：${res.status}`;
			throw new AppError(msg, {
				status: res.status,
				code: "tuzi_request_failed",
				details: { upstreamStatus: res.status, upstreamData: data ?? null },
			});
		}

		const taskId =
			(typeof data?.id === "string" && data.id.trim()) ||
			(typeof data?.task_id === "string" && data.task_id.trim()) ||
			(typeof data?.taskId === "string" && data.taskId.trim()) ||
			null;
		if (!taskId) {
			throw new AppError("Tuzi API 未返回任务 ID", {
				status: 502,
				code: "tuzi_task_id_missing",
				details: { upstreamData: data ?? null },
			});
		}

		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{
					kind: "video",
					taskId,
					vendor: "tuzi",
				},
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert tuzi video ref failed",
				err?.message || err,
			);
		}

		await bindReservationToTaskId(c, userId, reservation, taskId);

		const status = normalizeTuziVideoTaskStatus(data?.status);
		return TaskResultSchema.parse({
			id: taskId,
			kind: req.kind,
			status,
			assets: [],
			raw: {
				provider: "tuzi",
				vendor: "tuzi",
				model,
				request: {
					seconds,
					size,
					input_reference: absoluteInputReference,
				},
				response: data ?? null,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

function normalizeMiniMaxStatus(value: unknown): TaskStatus {
	if (typeof value === "string") {
		const normalized = value.trim().toLowerCase();
		if (!normalized) return "running";
		if (
			normalized === "queued" ||
			normalized === "queue" ||
			normalized === "pending" ||
			normalized === "waiting"
		) {
			return "queued";
		}
		if (
			normalized === "running" ||
			normalized === "processing" ||
			normalized === "in_progress" ||
			normalized === "in-progress" ||
			normalized === "generating"
		) {
			return "running";
		}
		if (
			normalized === "success" ||
			normalized === "succeeded" ||
			normalized === "completed" ||
			normalized === "done" ||
			normalized === "finish" ||
			normalized === "finished"
		) {
			return "succeeded";
		}
		if (
			normalized === "fail" ||
			normalized === "failed" ||
			normalized === "failure" ||
			normalized === "error"
		) {
			return "failed";
		}
		return "running";
	}

	// Some MiniMax gateways return numeric status codes:
	// 0=queued, 1=running, 2=succeeded, 3=failed (best-effort mapping).
	if (typeof value === "number" && Number.isFinite(value)) {
		const code = Math.floor(value);
		if (code === 2) return "succeeded";
		if (code === 3 || code === -1) return "failed";
		if (code === 0) return "queued";
		return "running";
	}

	if (typeof value === "boolean") {
		return value ? "succeeded" : "running";
	}

	return "running";
}

function extractMiniMaxVideoUrl(payload: any): string | null {
	const pick = (v: any): string | null =>
		typeof v === "string" && v.trim() ? v.trim() : null;
	const file =
		(payload?.file && typeof payload.file === "object" ? payload.file : null) ||
		(payload?.data?.file && typeof payload.data.file === "object"
			? payload.data.file
			: null) ||
		null;
	return (
		pick(payload?.video_url) ||
		pick(payload?.videoUrl) ||
		pick(payload?.url) ||
		pick(payload?.file_url) ||
		pick(payload?.fileUrl) ||
		pick(payload?.download_url) ||
		pick(payload?.downloadUrl) ||
		pick(file?.download_url) ||
		pick(file?.downloadUrl) ||
		pick(file?.url) ||
		pick(file?.file_url) ||
		pick(file?.fileUrl) ||
		(Array.isArray(payload?.results) && payload.results.length
			? pick(payload.results[0]?.url) ||
				pick(payload.results[0]?.video_url) ||
				pick(payload.results[0]?.videoUrl)
			: null) ||
		null
	);
}

export async function fetchMiniMaxTaskResult(
	c: AppContext,
	userId: string,
	taskId: string,
) {
	if (!taskId || !taskId.trim()) {
		throw new AppError("taskId is required", {
			status: 400,
			code: "task_id_required",
		});
	}

	const ctx = await resolveVendorContext(c, userId, "minimax");
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const channelVendor: "grsai" | "comfly" | null =
		ctx.viaProxyVendor === "comfly"
			? "comfly"
			: isGrsaiBaseUrl(baseUrl) || ctx.viaProxyVendor === "grsai"
				? "grsai"
				: null;
	const apiKey = ctx.apiKey.trim();
	if (!baseUrl || !apiKey) {
		throw new AppError("未配置 MiniMax API Key", {
			status: 400,
			code: "minimax_api_key_missing",
		});
	}

		const makeUrl = (key: string) => {
			const qs = new URLSearchParams();
			qs.append(key, taskId.trim());
			return `${baseUrl}/minimax/v1/query/video_generation?${qs.toString()}`;
		};

		const tryFetch = async (url: string, tag: string) => {
			const res = await fetchWithHttpDebugLog(
				c,
				url,
				{
					method: "GET",
					headers: {
						Authorization: `Bearer ${apiKey}`,
					},
				},
				{ tag },
			);
			let data: any = null;
			try {
				data = await res.json();
			} catch {
				data = null;
			}
			return { res, data };
		};

		let res: Response;
		let data: any = null;
		try {
			({ res, data } = await tryFetch(makeUrl("task_id"), "minimax:result"));
		} catch (error: any) {
			throw new AppError("MiniMax 结果查询失败", {
				status: 502,
				code: "minimax_result_failed",
				details: { message: error?.message ?? String(error) },
			});
		}

		// Some MiniMax gateways expect array-form query params (task_id[]=...).
		if (!res.ok && res.status === 400) {
			try {
				const retry = await tryFetch(makeUrl("task_id[]"), "minimax:result:array");
				if (retry.res.ok) {
					res = retry.res;
					data = retry.data;
				} else {
					// keep original error response for reporting
				}
			} catch {
				// ignore retry errors
			}
		}

		if (!res.ok) {
			const msg =
				extractMiniMaxErrorMessage(data) || `MiniMax 结果查询失败: ${res.status}`;
			throw new AppError(msg, {
				status: res.status,
				code: "minimax_result_failed",
				details: { upstreamStatus: res.status, upstreamData: data ?? null },
			});
		}

	const payload = data?.data ?? data ?? {};
	const status = normalizeMiniMaxStatus(payload?.status ?? data?.status);
	const progress = parseComflyProgress(payload?.progress || data?.progress);
	const videoUrlFromPayload = extractMiniMaxVideoUrl(payload);

	if (status === "failed") {
		const msg =
			(typeof payload?.base_resp?.status_msg === "string" &&
				payload.base_resp.status_msg.trim()) ||
			(typeof payload?.message === "string" && payload.message.trim()) ||
			(typeof payload?.error === "string" && payload.error.trim()) ||
			"MiniMax 视频任务失败";
		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "failed",
			assets: [],
			raw: {
				provider: "minimax",
				model:
					typeof payload?.model === "string" && payload.model.trim()
						? payload.model.trim()
						: undefined,
				response: payload,
				progress,
				message: msg,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "minimax",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	// Some gateways may not provide a reliable `status` field; when a video URL exists,
	// treat the task as succeeded to unblock the frontend polling loop.
	if (videoUrlFromPayload && status !== "failed") {
		const asset = TaskAssetSchema.parse({
			type: "video",
			url: videoUrlFromPayload,
			thumbnailUrl: null,
		});
		let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
		try {
			hostedAssets = await hostTaskAssetsInWorker({
				c,
				userId,
				assets: [asset],
				meta: {
					taskKind: "text_to_video",
					prompt:
						typeof payload?.prompt === "string" && payload.prompt.trim()
							? payload.prompt.trim()
							: null,
					vendor: "minimax",
					modelKey:
						typeof payload?.model === "string" && payload.model.trim()
							? payload.model.trim()
							: undefined,
					taskId,
				},
			});
		} catch (err: any) {
			const message =
				typeof err?.message === "string" && err.message.trim()
					? err.message.trim()
					: "OSS 托管失败，稍后重试";
			const result = TaskResultSchema.parse({
				id: taskId,
				kind: "text_to_video",
				status: "running",
				assets: [],
				raw: {
					provider: "minimax",
					model:
						typeof payload?.model === "string" && payload.model.trim()
							? payload.model.trim()
							: undefined,
					response: payload,
					progress,
					hosting: { status: "pending", message },
				},
			});
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: "minimax",
				taskKind: "text_to_video",
				result,
			});
			if (channelVendor) {
				await recordVendorCallFromTaskResult(c, {
					userId,
					vendor: channelVendor,
					taskKind: "text_to_video",
					result,
				});
			}
			return result;
		}

		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "succeeded",
			assets: hostedAssets,
			raw: {
				provider: "minimax",
				model:
					typeof payload?.model === "string" && payload.model.trim()
						? payload.model.trim()
						: undefined,
				response: payload,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "minimax",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	if (status !== "succeeded") {
		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status,
			assets: [],
			raw: {
				provider: "minimax",
				model:
					typeof payload?.model === "string" && payload.model.trim()
						? payload.model.trim()
						: undefined,
				response: payload,
				progress,
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "minimax",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	const videoUrl = videoUrlFromPayload;
	if (!videoUrl) {
		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "failed",
			assets: [],
			raw: {
				provider: "minimax",
				model:
					typeof payload?.model === "string" && payload.model.trim()
						? payload.model.trim()
						: undefined,
				response: payload,
				progress,
				message:
					"MiniMax 任务已完成但未返回视频链接（缺少 url/video_url）",
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "minimax",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	const asset = TaskAssetSchema.parse({
		type: "video",
		url: videoUrl,
		thumbnailUrl: null,
	});
	let hostedAssets: Array<ReturnType<typeof TaskAssetSchema.parse>>;
	try {
		hostedAssets = await hostTaskAssetsInWorker({
			c,
			userId,
			assets: [asset],
			meta: {
				taskKind: "text_to_video",
				prompt:
					typeof payload?.prompt === "string" && payload.prompt.trim()
						? payload.prompt.trim()
						: null,
				vendor: "minimax",
				modelKey:
					typeof payload?.model === "string" && payload.model.trim()
						? payload.model.trim()
						: undefined,
				taskId,
			},
		});
	} catch (err: any) {
		const message =
			typeof err?.message === "string" && err.message.trim()
				? err.message.trim()
				: "OSS 托管失败，稍后重试";
		const result = TaskResultSchema.parse({
			id: taskId,
			kind: "text_to_video",
			status: "running",
			assets: [],
			raw: {
				provider: "minimax",
				model:
					typeof payload?.model === "string" && payload.model.trim()
						? payload.model.trim()
						: undefined,
				response: payload,
				progress,
				hosting: { status: "pending", message },
			},
		});
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: "minimax",
			taskKind: "text_to_video",
			result,
		});
		if (channelVendor) {
			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: channelVendor,
				taskKind: "text_to_video",
				result,
			});
		}
		return result;
	}

	const result = TaskResultSchema.parse({
		id: taskId,
		kind: "text_to_video",
		status: "succeeded",
		assets: hostedAssets,
		raw: {
			provider: "minimax",
			model:
				typeof payload?.model === "string" && payload.model.trim()
					? payload.model.trim()
					: undefined,
			response: payload,
		},
	});
	await recordVendorCallFromTaskResult(c, {
		userId,
		vendor: "minimax",
		taskKind: "text_to_video",
		result,
	});
	if (channelVendor) {
		await recordVendorCallFromTaskResult(c, {
			userId,
			vendor: channelVendor,
			taskKind: "text_to_video",
			result,
		});
	}
	return result;
}

// ---------- Generic text/image tasks (openai / gemini / qwen / anthropic) ----------

function clamp01(value: number): number {
	if (!Number.isFinite(value)) return 0;
	if (value < 0) return 0;
	if (value > 1) return 1;
	return value;
}

function normalizeTemperature(input: unknown, fallback: number): number {
	if (typeof input !== "number" || Number.isNaN(input)) return fallback;
	return clamp01(input);
}

// ---- OpenAI / Codex responses helpers (align with Nest openaiAdapter) ----

type OpenAIContentPartForTask =
	| { type: "text"; text: string }
	| { type: "image_url"; image_url: { url: string } | string };

type OpenAIChatMessageForTask = {
	role: string;
	content: string | OpenAIContentPartForTask[];
};

function normalizeOpenAIBaseForTask(baseUrl?: string | null): string {
	const raw = (baseUrl || "https://api.openai.com").trim();
	return raw.replace(/\/+$/, "");
}

function buildOpenAIResponsesUrlForTask(baseUrl?: string | null): string {
	const normalized = normalizeOpenAIBaseForTask(baseUrl);
	if (/\/responses$/i.test(normalized)) {
		return normalized;
	}
	const hasVersion = /\/v\d+(?:beta)?$/i.test(normalized);
	return `${normalized}${hasVersion ? "" : "/v1"}/responses`;
}

function buildOpenAIChatCompletionsUrlForTask(baseUrl?: string | null): string {
	const raw = String(baseUrl || "").trim().replace(/\/+$/, "");
	if (!raw) return "https://api.openai.com/v1/chat/completions";
	if (/\/chat\/completions$/i.test(raw)) return raw;
	// If base already contains a version segment (e.g. /v1 or /v1/openai), do not append another /v1.
	const hasVersionSegment = /\/v\d+(?:beta)?(\/|$)/i.test(raw);
	return `${raw}${hasVersionSegment ? "" : "/v1"}/chat/completions`;
}

function buildOpenAIImagesGenerationsUrlForTask(baseUrl?: string | null): string {
	const raw = String(baseUrl || "").trim().replace(/\/+$/, "");
	if (!raw) return "https://api.openai.com/v1/images/generations";
	if (/\/images\/generations$/i.test(raw)) return raw;
	const hasVersionSegment = /\/v\d+(?:beta)?(\/|$)/i.test(raw);
	return `${raw}${hasVersionSegment ? "" : "/v1"}/images/generations`;
}

function normalizeMessageContentForResponses(
	content: string | OpenAIContentPartForTask[],
): OpenAIContentPartForTask[] {
	if (typeof content === "string") {
		return [{ type: "text", text: content }];
	}
	return content;
}

function convertPartForResponses(
	part: OpenAIContentPartForTask,
): { type: string; [key: string]: any } {
	if (part.type === "text") {
		return { type: "input_text", text: (part as any).text ?? "" };
	}
	if (part.type === "image_url") {
		const source =
			typeof (part as any).image_url === "string"
				? (part as any).image_url
				: (part as any).image_url?.url;
		return { type: "input_image", image_url: source || "" };
	}
	return part as any;
}

function convertMessagesToResponsesInput(
	messages: OpenAIChatMessageForTask[],
) {
	return messages.map((msg) => ({
		role: msg.role,
		content: normalizeMessageContentForResponses(
			msg.content,
		).map(convertPartForResponses),
	}));
}

function extractTextFromOpenAIResponseForTask(raw: any): string {
	// 兼容传统 chat.completions 结构
	if (Array.isArray(raw?.choices)) {
		const choice = raw.choices[0];
		const message = choice?.message;
		if (Array.isArray(message?.content)) {
			return message.content
				.map((part: any) =>
					typeof part?.text === "string"
						? part.text
						: part?.content || "",
				)
				.join("")
				.trim();
		}
		if (typeof message?.content === "string") {
			return message.content.trim();
		}
	}

	// 兼容 responses 格式：output / output_text
	const output = raw?.output;
	if (Array.isArray(output)) {
		const buffer: string[] = [];
		output.forEach((entry: any) => {
			if (Array.isArray(entry?.content)) {
				entry.content.forEach((part: any) => {
					if (typeof part?.text === "string") {
						buffer.push(part.text);
					} else if (typeof part?.content === "string") {
						buffer.push(part.content);
					} else if (typeof part?.output_text === "string") {
						buffer.push(part.output_text);
					}
				});
			}
		});
		const merged = buffer.join("").trim();
		if (merged) return merged;
	}

	if (Array.isArray(raw?.output_text)) {
		const merged = raw.output_text
			.filter((v: any) => typeof v === "string")
			.join("")
			.trim();
		if (merged) return merged;
	}

	if (typeof raw?.text === "string") {
		return raw.text.trim();
	}

	return "";
}

function normalizeImagePromptOutputForTask(text: string): string {
	if (!text) return "";
	let normalized = text.trim();

	// Strip common "Prompt" labels and Markdown headings at the beginning.
	normalized = normalized.replace(
		/^\s*\*{0,2}\s*prompt\s*\*{0,2}\s*[-:]\s*/i,
		"",
	);

	// Remove surrounding quotes if the whole output is quoted.
	if (
		(normalized.startsWith('"') && normalized.endsWith('"')) ||
		(normalized.startsWith("'") && normalized.endsWith("'"))
	) {
		normalized = normalized.slice(1, -1).trim();
	}

	return normalized.trim();
}

function pickModelKey(
	req: TaskRequestDto,
	ctx: { modelKey?: string | null },
): string | undefined {
	const extras = (req.extras || {}) as Record<string, any>;
	const explicit =
		typeof extras.modelKey === "string" && extras.modelKey.trim()
			? extras.modelKey.trim()
			: undefined;
	if (explicit) return explicit;
	if (ctx.modelKey && ctx.modelKey.trim()) return ctx.modelKey.trim();
	return undefined;
}

function pickSystemPrompt(
	req: TaskRequestDto,
	defaultPrompt: string,
): string {
	const extras = (req.extras || {}) as Record<string, any>;
	const explicit =
		typeof extras.systemPrompt === "string" && extras.systemPrompt.trim()
			? extras.systemPrompt.trim()
			: null;
	if (explicit) return explicit;
	return defaultPrompt;
}

async function callJsonApi(
	c: AppContext,
	url: string,
	init: RequestInit,
	errorContext: { provider: string },
): Promise<any> {
	let res: Response;
	try {
		res = await fetchWithHttpDebugLog(c, url, init, {
			tag: `${errorContext.provider}:jsonApi`,
		});
	} catch (error: any) {
		throw new AppError(`${errorContext.provider} 请求失败`, {
			status: 502,
			code: `${errorContext.provider}_request_failed`,
			details: { message: error?.message ?? String(error) },
		});
	}

	let data: any = null;
	try {
		data = await res.json();
	} catch {
		data = null;
	}

	if (res.status < 200 || res.status >= 300) {
		const msg =
			(data && (data.error?.message || data.message || data.error)) ||
			`${errorContext.provider} 调用失败: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: `${errorContext.provider}_request_failed`,
			details: { upstreamStatus: res.status, upstreamData: data ?? null },
		});
	}

	return data;
}

function safeParseJsonForTask(data: string): any | null {
	try {
		return JSON.parse(data);
	} catch {
		return null;
	}
}

// 解析通用 SSE 文本，提取最后一个 data: JSON payload
function parseSseJsonPayloadForTask(raw: string): any | null {
	if (typeof raw !== "string" || !raw.trim()) return null;
	const normalized = raw.replace(/\r/g, "");
	const chunks = normalized.split(/\n\n+/);
	let last: any = null;
	for (const chunk of chunks) {
		const trimmedChunk = chunk.trim();
		if (!trimmedChunk) continue;
		const lines = trimmedChunk.split("\n");
		for (const line of lines) {
			const match = line.match(/^\s*data:\s*(.+)$/i);
			if (!match) continue;
			const payload = match[1].trim();
			if (!payload || payload === "[DONE]") continue;
			const parsed = safeParseJsonForTask(payload);
			if (parsed) last = parsed;
		}
	}
	return last;
}

	function extractMarkdownImageUrlsFromText(text: string): string[] {
		if (typeof text !== "string" || !text.trim()) return [];
		const urls = new Set<string>();
		const regex = /!\[[^\]]*]\(([^)]+)\)/g;
		let match: RegExpExecArray | null;
		// eslint-disable-next-line no-cond-assign
		while ((match = regex.exec(text)) !== null) {
			const raw = (match[1] || "").trim();
			const first = raw.split(/\s+/)[0] || "";
			const url = first.replace(/^<(.+)>$/, "$1").trim();
			if (url) urls.add(url);
		}
		return Array.from(urls);
	}

	function extractMarkdownLinkUrlsFromText(text: string): string[] {
		if (typeof text !== "string" || !text.trim()) return [];
		const urls = new Set<string>();
		const regex = /\[[^\]]*]\(([^)]+)\)/g;
		let match: RegExpExecArray | null;
		// eslint-disable-next-line no-cond-assign
		while ((match = regex.exec(text)) !== null) {
			const raw = (match[1] || "").trim();
			const first = raw.split(/\s+/)[0] || "";
			const url = first.replace(/^<(.+)>$/, "$1").trim();
			if (url) urls.add(url);
		}
		return Array.from(urls);
	}

	function extractHtmlVideoUrlsFromText(text: string): string[] {
		if (typeof text !== "string" || !text.trim()) return [];
		const urls = new Set<string>();
		const regexes = [
			/<video[^>]*\ssrc=['"]([^'"]+)['"][^>]*>/gi,
			/<source[^>]*\ssrc=['"]([^'"]+)['"][^>]*>/gi,
		];
		for (const regex of regexes) {
			let match: RegExpExecArray | null;
			// eslint-disable-next-line no-cond-assign
			while ((match = regex.exec(text)) !== null) {
				const url = (match[1] || "").trim();
				if (url) urls.add(url);
			}
		}
		return Array.from(urls);
	}

	function looksLikeVideoUrl(url: string): boolean {
		const lower = (url || "").toLowerCase();
		if (!lower) return false;
		if (/\.(mp4|webm|mov|m4v)(\?|#|$)/.test(lower)) return true;
		// sora2api cache may return local /tmp/* links without extensions.
		if (lower.includes("/tmp/")) return true;
		return false;
	}

	type AsyncDataTaskRef = {
		id: string;
		webUrl: string | null;
		sourceUrl: string | null;
	};

	function extractAsyncDataTaskRefFromText(text: string): AsyncDataTaskRef | null {
		if (typeof text !== "string" || !text.trim()) return null;

		const normalized = text.trim();
		const uuid =
			/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

		const refsById = new Map<string, { webUrl: string | null; sourceUrl: string | null }>();

		const linkRegex =
			/https?:\/\/[^\s)]+asyncdata\.net\/(web|source)\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/gi;
		let match: RegExpExecArray | null;
		// eslint-disable-next-line no-cond-assign
		while ((match = linkRegex.exec(normalized)) !== null) {
			const kind = (match[1] || "").toLowerCase();
			const id = (match[2] || "").toLowerCase();
			if (!id) continue;

			const url = match[0].trim();
			const current = refsById.get(id) || { webUrl: null, sourceUrl: null };
			if (kind === "web") current.webUrl = current.webUrl || url;
			if (kind === "source") current.sourceUrl = current.sourceUrl || url;
			refsById.set(id, current);
		}

		if (refsById.size > 0) {
			// Prefer IDs that have both web + source links.
			for (const [id, ref] of refsById.entries()) {
				if (ref.webUrl && ref.sourceUrl) {
					return { id, webUrl: ref.webUrl, sourceUrl: ref.sourceUrl };
				}
			}
			const first = refsById.entries().next().value as
				| [string, { webUrl: string | null; sourceUrl: string | null }]
				| undefined;
			if (first) {
				return { id: first[0], webUrl: first[1].webUrl, sourceUrl: first[1].sourceUrl };
			}
		}

		// Fallback: "ID: <uuid>" pattern (with or without backticks).
		{
			const m =
				normalized.match(
					new RegExp(
						`\\bID\\s*[:：]\\s*` +
							"`?" +
							`(${uuid.source})` +
							"`?",
						"i",
					),
				) || null;
			const id = m?.[1] ? String(m[1]).toLowerCase() : "";
			if (id) return { id, webUrl: null, sourceUrl: null };
		}

		// Last resort: if the text mentions asyncdata, try to grab any UUID.
		if (/asyncdata/i.test(normalized)) {
			const m = normalized.match(uuid);
			const id = m?.[0] ? String(m[0]).toLowerCase() : "";
			if (id) return { id, webUrl: null, sourceUrl: null };
		}

		return null;
	}

	function extractProgressPercentFromText(text: string): number | null {
		if (typeof text !== "string" || !text.trim()) return null;

		const idx = (() => {
			const m = text.search(/(进度|progress)/i);
			return m >= 0 ? m : -1;
		})();
		if (idx < 0) return null;

		const slice = text.slice(idx, idx + 160);
		const nums = slice.match(/\b\d{1,3}\b/g) || [];
		const values = nums
			.map((n) => Number.parseInt(n, 10))
			.filter((n) => Number.isFinite(n) && n >= 0 && n <= 100);
		if (!values.length) return null;
		return Math.max(...values);
	}

	function arrayBufferToBase64(buf: ArrayBuffer): string {
		const bytes = new Uint8Array(buf);
		let binary = "";
		const chunkSize = 0x2000;
		for (let i = 0; i < bytes.length; i += chunkSize) {
			const chunk = bytes.subarray(i, i + chunkSize);
			binary += String.fromCharCode(...chunk);
		}
		return btoa(binary);
	}

	async function resolveSora2ApiImageUrl(
		c: AppContext,
		url: string,
	): Promise<string> {
		const trimmed = (url || "").trim();
		if (!trimmed) return trimmed;
		if (/^data:image\//i.test(trimmed)) return trimmed;
		if (/^blob:/i.test(trimmed)) {
			throw new AppError(
				"blob: URL 无法在 Worker 侧下载，请先上传为可访问的图片地址",
				{
					status: 400,
					code: "invalid_image_url",
					details: { url: trimmed.slice(0, 64) },
				},
			);
		}

		let resolved = trimmed;
		if (resolved.startsWith("/")) {
			try {
				resolved = new URL(resolved, new URL(c.req.url).origin).toString();
			} catch {
				return trimmed;
			}
		}

		if (!/^https?:\/\//i.test(resolved)) return trimmed;

		const MAX_BYTES = 8 * 1024 * 1024;
		const res = await fetchWithHttpDebugLog(
			c,
			resolved,
			{ method: "GET" },
			{ tag: "sora2api:imageFetch" },
		);
		if (!res.ok) {
			throw new AppError(`参考图下载失败: ${res.status}`, {
				status: 502,
				code: "image_fetch_failed",
				details: { upstreamStatus: res.status, url: resolved },
			});
		}

		const ct = (res.headers.get("content-type") || "").toLowerCase();
		if (!ct.startsWith("image/")) {
			throw new AppError("参考图不是 image/* 内容", {
				status: 400,
				code: "invalid_image_content_type",
				details: { contentType: ct, url: resolved },
			});
		}

		const lenHeader = res.headers.get("content-length");
		const len =
			typeof lenHeader === "string" && /^\d+$/.test(lenHeader)
				? Number(lenHeader)
				: null;
		if (typeof len === "number" && Number.isFinite(len) && len > MAX_BYTES) {
			throw new AppError("参考图过大，无法转换为 base64", {
				status: 400,
				code: "image_too_large",
				details: { contentLength: len, maxBytes: MAX_BYTES, url: resolved },
			});
		}

		const buf = await res.arrayBuffer();
		if (buf.byteLength > MAX_BYTES) {
			throw new AppError("参考图过大，无法转换为 base64", {
				status: 400,
				code: "image_too_large",
				details: {
					contentLength: buf.byteLength,
					maxBytes: MAX_BYTES,
					url: resolved,
				},
			});
		}

		const base64 = arrayBufferToBase64(buf);
		return `data:${ct};base64,${base64}`;
	}

// 解析 Codex / OpenAI Responses SSE 文本，提取最终的 completed response
function parseSseResponseForTask(raw: string): any | null {
	if (typeof raw !== "string" || !raw.trim()) return null;
	const chunks = raw.split(/\n\n+/);
	let completedResponse: any = null;
	let aggregatedText = "";

	chunks.forEach((chunk) => {
		const trimmed = chunk.trim();
		if (!trimmed) return;

		const dataLines = trimmed
			.split("\n")
			.filter((line) => line.startsWith("data:"))
			.map((line) => line.slice(5).trim())
			.filter(Boolean);
		if (!dataLines.length) return;

		const payload = safeParseJsonForTask(dataLines.join("\n"));
		if (!payload || typeof payload !== "object") return;

		if (payload.type === "response.completed" && payload.response) {
			completedResponse = payload.response;
			return;
		}

		if (
			payload.type === "response.output_text.delta" &&
			typeof payload.delta === "string"
		) {
			aggregatedText += payload.delta;
		}

		if (!aggregatedText) {
			if (
				payload.type === "response.output_text.done" &&
				typeof payload.text === "string"
			) {
				aggregatedText = payload.text;
			} else if (
				payload.type === "response.content_part.done" &&
				payload.part &&
				typeof payload.part.text === "string"
			) {
				aggregatedText = payload.part.text;
			}
		}
	});

	if (completedResponse) return completedResponse;
	if (aggregatedText) {
		return {
			text: aggregatedText,
			output_text: [aggregatedText],
		};
	}
	return null;
}

// 专用于 OpenAI/Codex responses 端点，保留原始文本以便调试和前端展示
async function callOpenAIResponsesForTask(
	c: AppContext,
	url: string,
	apiKey: string,
	body: Record<string, any>,
): Promise<{ parsed: any; rawBody: string }> {
	let res: Response;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			url,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "openai:responses" },
		);
	} catch (error: any) {
		throw new AppError("openai 请求失败", {
			status: 502,
			code: "openai_request_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	let rawText = "";
	try {
		rawText = await res.text();
	} catch {
		rawText = "";
	}

	let parsed: any = null;
	if (rawText && rawText.trim()) {
		// 优先尝试按 SSE 流解析（Codex 默认），失败再退回普通 JSON。
		parsed = parseSseResponseForTask(rawText) || safeParseJsonForTask(rawText);
	}

	if (res.status < 200 || res.status >= 300) {
		const msg =
			(parsed &&
				(parsed.error?.message ||
					parsed.message ||
					parsed.error)) ||
			`openai 调用失败: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "openai_request_failed",
			details: {
				upstreamStatus: res.status,
				upstreamData: parsed ?? rawText ?? null,
			},
		});
	}

	return { parsed, rawBody: rawText };
}

type ModelCatalogVendorAuthForTask = {
	authType: "none" | "bearer" | "x-api-key" | "query";
	authHeader: string | null;
	authQueryParam: string | null;
};

async function resolveModelCatalogVendorAuthForTask(
	c: AppContext,
	vendorKey: string,
): Promise<ModelCatalogVendorAuthForTask | null> {
	const vk = normalizeVendorKey(vendorKey);
	if (!vk) return null;
	try {
		await ensureModelCatalogSchema(c.env.DB);
		const row = await c.env.DB.prepare(
			`SELECT auth_type, auth_header, auth_query_param FROM model_catalog_vendors WHERE key = ? LIMIT 1`,
		)
			.bind(vk)
			.first<any>();
		if (!row) return null;
		const authTypeRaw =
			typeof row?.auth_type === "string" ? row.auth_type.trim().toLowerCase() : "";
		const authType =
			authTypeRaw === "none" ||
			authTypeRaw === "bearer" ||
			authTypeRaw === "x-api-key" ||
			authTypeRaw === "query"
				? (authTypeRaw as ModelCatalogVendorAuthForTask["authType"])
				: "bearer";
		const authHeader =
			typeof row?.auth_header === "string" && row.auth_header.trim()
				? row.auth_header.trim()
				: null;
		const authQueryParam =
			typeof row?.auth_query_param === "string" && row.auth_query_param.trim()
				? row.auth_query_param.trim()
				: null;
		return { authType, authHeader, authQueryParam };
	} catch {
		return null;
	}
}

async function resolveDefaultModelKeyFromCatalogForVendor(
	c: AppContext,
	vendorKey: string,
	kind: "text" | "image" | "video",
): Promise<string | null> {
	const vk = normalizeVendorKey(vendorKey);
	if (!vk) return null;
	try {
		await ensureModelCatalogSchema(c.env.DB);
		const row = await c.env.DB.prepare(
			`SELECT model_key
       FROM model_catalog_models
       WHERE vendor_key = ? AND kind = ? AND enabled = 1
       ORDER BY updated_at DESC, created_at DESC, model_key ASC
       LIMIT 1`,
		)
			.bind(vk, kind)
			.first<any>();
		const modelKey =
			typeof row?.model_key === "string" && row.model_key.trim()
				? row.model_key.trim()
				: null;
		return modelKey;
	} catch {
		return null;
	}
}

async function runOpenAiCompatibleTextTaskForVendor(
	c: AppContext,
	userId: string,
	vendorKey: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const v = normalizeVendorKey(vendorKey);
	const ctx = await resolveVendorContext(c, userId, v);
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = (ctx.apiKey || "").trim();
	if (!baseUrl) {
		throw new AppError(`No base URL configured for vendor ${v}`, {
			status: 400,
			code: "base_url_missing",
		});
	}
	if (!apiKey) {
		throw new AppError(`No API key configured for vendor ${v}`, {
			status: 400,
			code: "api_key_missing",
		});
	}

	const explicitModelKey = pickModelKey(req, { modelKey: undefined });
	const modelKeyRaw =
		explicitModelKey ||
		(await resolveDefaultModelKeyFromCatalogForVendor(c, v, "text"));
	const model = modelKeyRaw?.startsWith("models/") ? modelKeyRaw.slice(7) : modelKeyRaw;
	if (!model) {
		throw new AppError(
			"未配置可用的模型（请在 /stats -> 模型管理（系统级）为该厂商添加并启用 text 模型，或在请求里传 extras.modelKey）",
			{
				status: 400,
				code: "model_not_configured",
				details: { vendor: v, taskKind: req.kind },
			},
		);
	}

	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: v,
		modelKey: model,
	});

	try {
		const systemPrompt =
			req.kind === "prompt_refine"
				? pickSystemPrompt(
						req,
						"你是一个提示词修订助手。请在保持原意的前提下优化并返回脚本正文。",
					)
				: pickSystemPrompt(req, "请用中文回答。");

		const extras = (req.extras || {}) as Record<string, any>;
		const temperature = normalizeTemperature(extras.temperature, 0.7);

		const messages: OpenAIChatMessageForTask[] = [];
		if (systemPrompt) messages.push({ role: "system", content: systemPrompt });
		messages.push({ role: "user", content: req.prompt });

		let url = buildOpenAIChatCompletionsUrlForTask(baseUrl);
		const headers: Record<string, string> = {
			"Content-Type": "application/json",
			Accept: "application/json",
		};

		const auth = await resolveModelCatalogVendorAuthForTask(c, v);
		if (auth?.authType === "none") {
			// no-op
		} else if (auth?.authType === "query") {
			const param = auth.authQueryParam || "api_key";
			const u = new URL(url);
			u.searchParams.set(param, apiKey);
			url = u.toString();
		} else if (auth?.authType === "x-api-key") {
			const header = auth.authHeader || "X-API-Key";
			headers[header] = apiKey;
		} else {
			const header = auth?.authHeader || "Authorization";
			headers[header] = `Bearer ${apiKey}`;
		}

		const body = {
			model,
			messages,
			stream: false,
			temperature,
		};

		const data = await callJsonApi(
			c,
			url,
			{
				method: "POST",
				headers,
				body: JSON.stringify(body),
			},
			{ provider: v },
		);

		const text = extractTextFromOpenAIResponseForTask(data);
		const id =
			(typeof data?.id === "string" && data.id.trim()) ||
			`${v}-${Date.now().toString(36)}`;

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status: "succeeded",
			assets: [],
			raw: {
				provider: "openai_compat",
				vendor: v,
				model,
				response: data,
				text: text || "调用成功",
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

async function runOpenAiCompatibleImageTaskForVendor(
	c: AppContext,
	userId: string,
	vendorKey: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const v = normalizeVendorKey(vendorKey);
	const ctx = await resolveVendorContext(c, userId, v);
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = (ctx.apiKey || "").trim();
	if (!baseUrl) {
		throw new AppError(`No base URL configured for vendor ${v}`, {
			status: 400,
			code: "base_url_missing",
		});
	}
	if (!apiKey) {
		throw new AppError(`No API key configured for vendor ${v}`, {
			status: 400,
			code: "api_key_missing",
		});
	}

	const explicitModelKey = pickModelKey(req, { modelKey: undefined });
	const modelKeyRaw =
		explicitModelKey ||
		(await resolveDefaultModelKeyFromCatalogForVendor(c, v, "image"));
	const model = modelKeyRaw?.startsWith("models/") ? modelKeyRaw.slice(7) : modelKeyRaw;
	if (!model) {
		throw new AppError(
			"未配置可用的模型（请在 /stats -> 模型管理（系统级）为该厂商添加并启用 image 模型，或在请求里传 extras.modelKey）",
			{
				status: 400,
				code: "model_not_configured",
				details: { vendor: v, taskKind: req.kind },
			},
		);
	}

	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: v,
		modelKey: model,
	});

	try {
		const auth = await resolveModelCatalogVendorAuthForTask(c, v);
		const headers: Record<string, string> = {
			"Content-Type": "application/json",
			Accept: "application/json",
		};

		let url = buildOpenAIImagesGenerationsUrlForTask(baseUrl);
		const logUrl = url;
		if (auth?.authType === "none") {
			// no-op
		} else if (auth?.authType === "query") {
			const param = auth.authQueryParam || "api_key";
			const u = new URL(url);
			u.searchParams.set(param, apiKey);
			url = u.toString();
		} else if (auth?.authType === "x-api-key") {
			const header = auth.authHeader || "X-API-Key";
			headers[header] = apiKey;
		} else {
			const header = auth?.authHeader || "Authorization";
			headers[header] = `Bearer ${apiKey}`;
		}

		const body: Record<string, any> = {
			model,
			prompt: req.prompt,
		};
		if (typeof req.width === "number" && typeof req.height === "number") {
			const w = Math.max(1, Math.round(req.width));
			const h = Math.max(1, Math.round(req.height));
			body.size = `${w}x${h}`;
		}

		const data = await callJsonApi(
			c,
			url,
			{
				method: "POST",
				headers,
				body: JSON.stringify(body),
			},
			{ provider: v },
		);

		const urls = extractBananaImageUrls(data);
		const assets = urls.map((u) =>
			TaskAssetSchema.parse({ type: "image", url: u, thumbnailUrl: null }),
		);
		const id =
			(typeof data?.id === "string" && data.id.trim()) ||
			(typeof data?.task_id === "string" && data.task_id.trim()) ||
			(typeof data?.taskId === "string" && data.taskId.trim()) ||
			`${v}-img-${Date.now().toString(36)}`;
		const status: "succeeded" | "failed" = assets.length ? "succeeded" : "failed";

		await recordVendorCallPayloads(c, {
			userId,
			vendor: v,
			taskId: id,
			taskKind: req.kind,
			request: { url: logUrl, body },
			upstreamResponse: { url: logUrl, data },
		});

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status,
			assets,
			raw: {
				provider: "openai_compat",
				vendor: v,
				model,
				response: data,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

async function runOpenAiCompatibleVideoTaskForVendor(
	c: AppContext,
	userId: string,
	vendorKey: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const v = normalizeVendorKey(vendorKey);
	const ctx = await resolveVendorContext(c, userId, v);
	const baseUrl = normalizeBaseUrl(ctx.baseUrl);
	const apiKey = (ctx.apiKey || "").trim();
	if (!baseUrl) {
		throw new AppError(`No base URL configured for vendor ${v}`, {
			status: 400,
			code: "base_url_missing",
		});
	}
	if (!apiKey) {
		throw new AppError(`No API key configured for vendor ${v}`, {
			status: 400,
			code: "api_key_missing",
		});
	}

	const explicitModelKey = pickModelKey(req, { modelKey: undefined });
	const modelKeyRaw =
		explicitModelKey ||
		(await resolveDefaultModelKeyFromCatalogForVendor(c, v, "video"));
	const model = modelKeyRaw?.startsWith("models/") ? modelKeyRaw.slice(7) : modelKeyRaw;
	if (!model) {
		throw new AppError(
			"未配置可用的模型（请在 /stats -> 模型管理（系统级）为该厂商添加并启用 video 模型，或在请求里传 extras.modelKey）",
			{
				status: 400,
				code: "model_not_configured",
				details: { vendor: v, taskKind: req.kind },
			},
		);
	}

	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: v,
		modelKey: model,
	});

	try {
		const messages: OpenAIChatMessageForTask[] = [{ role: "user", content: req.prompt }];

		const auth = await resolveModelCatalogVendorAuthForTask(c, v);
		const headers: Record<string, string> = {
			"Content-Type": "application/json",
			Accept: "application/json",
		};

		let url = buildOpenAIChatCompletionsUrlForTask(baseUrl);
		if (auth?.authType === "none") {
			// no-op
		} else if (auth?.authType === "query") {
			const param = auth.authQueryParam || "api_key";
			const u = new URL(url);
			u.searchParams.set(param, apiKey);
			url = u.toString();
		} else if (auth?.authType === "x-api-key") {
			const header = auth.authHeader || "X-API-Key";
			headers[header] = apiKey;
		} else {
			const header = auth?.authHeader || "Authorization";
			headers[header] = `Bearer ${apiKey}`;
		}

		const body: any = {
			model,
			messages,
			stream: false,
		};

		const data = await callJsonApi(
			c,
			url,
			{
				method: "POST",
				headers,
				body: JSON.stringify(body),
			},
			{ provider: v },
		);

		const urls = (() => {
			const collected = new Set<string>();

			const appendFromText = (value: any) => {
				if (!value) return;
				if (typeof value === "string") {
					extractHtmlVideoUrlsFromText(value).forEach((u) => collected.add(u));
					extractMarkdownLinkUrlsFromText(value)
						.filter(looksLikeVideoUrl)
						.forEach((u) => collected.add(u));
					return;
				}
				if (Array.isArray(value)) {
					value.forEach((part) => {
						if (!part) return;
						if (typeof part === "string") {
							extractHtmlVideoUrlsFromText(part).forEach((u) => collected.add(u));
							extractMarkdownLinkUrlsFromText(part)
								.filter(looksLikeVideoUrl)
								.forEach((u) => collected.add(u));
							return;
						}
						if (typeof part === "object" && typeof (part as any).text === "string") {
							const text = (part as any).text;
							extractHtmlVideoUrlsFromText(text).forEach((u) => collected.add(u));
							extractMarkdownLinkUrlsFromText(text)
								.filter(looksLikeVideoUrl)
								.forEach((u) => collected.add(u));
						}
					});
				}
			};

			appendFromText((data as any)?.content);
			if (Array.isArray((data as any)?.choices)) {
				for (const choice of (data as any).choices) {
					appendFromText(choice?.message?.content);
					appendFromText(choice?.delta?.content);
					appendFromText(choice?.content);
				}
			}
			appendFromText(extractTextFromOpenAIResponseForTask(data));

			return Array.from(collected);
		})();

		const assets = urls.map((u) =>
			TaskAssetSchema.parse({ type: "video", url: u, thumbnailUrl: null }),
		);
		const id =
			(typeof data?.id === "string" && data.id.trim()) ||
			(typeof (data as any)?.task_id === "string" && (data as any).task_id.trim()) ||
			(typeof (data as any)?.taskId === "string" && (data as any).taskId.trim()) ||
			`${v}-vid-${Date.now().toString(36)}`;
		if (!assets.length) {
			const text = extractTextFromOpenAIResponseForTask(data) || "";
			const asyncdata = extractAsyncDataTaskRefFromText(text);
			if (asyncdata) {
				const progress = extractProgressPercentFromText(text);
				const status: "queued" | "running" =
					typeof progress === "number" && progress > 0 ? "running" : "queued";

				const nowIso = new Date().toISOString();
				const vendorForRef = `${v}:asyncdata`;
				const chatCompletionId = id;
				const createdTaskId = asyncdata.id;
				try {
					// Primary: use asyncdata UUID as the taskId for polling; store a back-reference
					// from chat.completion id -> asyncdata UUID for compatibility/debugging.
					await upsertVendorTaskRef(
						c.env.DB,
						userId,
						{
							kind: "video",
							taskId: createdTaskId,
							vendor: vendorForRef,
						},
						nowIso,
					);
					await upsertVendorTaskRef(
						c.env.DB,
						userId,
						{
							kind: "video",
							taskId: chatCompletionId,
							vendor: vendorForRef,
							pid: createdTaskId,
						},
						nowIso,
					);
				} catch (err: any) {
					console.warn(
						"[vendor-task-refs] upsert asyncdata video ref failed",
						err?.message || err,
					);
				}

				await bindReservationToTaskId(c, userId, reservation, createdTaskId);

				return TaskResultSchema.parse({
					id: createdTaskId,
					kind: req.kind,
					status,
					assets: [],
					raw: {
						provider: "openai_compat",
						vendor: v,
						model,
						chatCompletionId,
						response: data,
						asyncdata: {
							id: createdTaskId,
							webUrl: asyncdata.webUrl,
							sourceUrl: asyncdata.sourceUrl,
							progress,
						},
					},
				});
			}
		}

		const status: "succeeded" | "failed" = assets.length ? "succeeded" : "failed";

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status,
			assets,
			raw: {
				provider: "openai_compat",
				vendor: v,
				model,
				response: data,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

// ---- OpenAI text (chat / prompt_refine) ----

async function runOpenAiTextTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
	): Promise<TaskResult> {
		const ctx = await resolveVendorContext(c, userId, "openai");
		const responsesUrl = buildOpenAIResponsesUrlForTask(ctx.baseUrl);
		const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 OpenAI API Key", {
			status: 400,
			code: "openai_api_key_missing",
		});
	}

	const model =
		pickModelKey(req, { modelKey: undefined }) ||
		"gpt-5.2";
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "openai",
		modelKey: model,
	});

	try {
		const extras = (req.extras || {}) as Record<string, any>;

		const systemPrompt =
			req.kind === "prompt_refine"
				? pickSystemPrompt(
						req,
						"你是一个提示词修订助手。请在保持原意的前提下优化并返回脚本正文。",
					)
				: pickSystemPrompt(req, "请用中文回答。");

		const temperature = normalizeTemperature(extras.temperature, 0.7);

		const messages: OpenAIChatMessageForTask[] = [];
		if (systemPrompt) {
			messages.push({ role: "system", content: systemPrompt });
		}
		messages.push({ role: "user", content: req.prompt });

		const input = convertMessagesToResponsesInput(messages);
		const body = {
			model,
			input,
			max_output_tokens: 800,
			stream: false,
			temperature,
		};

		const { parsed, rawBody } = await callOpenAIResponsesForTask(
			c,
			responsesUrl,
			apiKey,
			body,
		);

		const text =
			extractTextFromOpenAIResponseForTask(parsed) ||
			(typeof rawBody === "string" ? rawBody.trim() : "");

		const id =
			(typeof parsed?.id === "string" && parsed.id.trim()) ||
			`openai-${Date.now().toString(36)}`;

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status: "succeeded",
			assets: [],
			raw: {
				provider: "openai",
				model,
				response: parsed,
				rawBody,
				text,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

// ---- OpenAI image_to_prompt ----

async function runOpenAiImageToPromptTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
	): Promise<TaskResult> {
	const ctx = await resolveVendorContext(c, userId, "openai");
	const responsesUrl = buildOpenAIResponsesUrlForTask(ctx.baseUrl);
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 OpenAI API Key", {
			status: 400,
			code: "openai_api_key_missing",
		});
	}

	const extras = (req.extras || {}) as Record<string, any>;
	const imageData =
		typeof extras.imageData === "string" && extras.imageData.trim()
			? extras.imageData.trim()
			: null;
	const imageUrl =
		typeof extras.imageUrl === "string" && extras.imageUrl.trim()
			? extras.imageUrl.trim()
			: null;

	if (!imageData && !imageUrl) {
		throw new AppError("imageUrl 或 imageData 必须提供一个", {
			status: 400,
			code: "image_source_missing",
		});
	}

	const model =
		pickModelKey(req, { modelKey: undefined }) ||
		"gpt-5.2";
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "openai",
		modelKey: model,
	});

	try {
		const userPrompt =
			req.prompt?.trim() ||
			"Describe this image in rich detail and output a single, well-structured English prompt that can be used to recreate it. Do not add any explanations, headings, markdown formatting, or non-English text.";

		const systemPrompt = pickSystemPrompt(
			req,
			"You are an expert prompt engineer. When a user provides an image, you must return a single detailed English prompt that can be used to recreate it. Describe subjects, environment, composition, camera, lighting, and style cues. Do not add explanations, headings, markdown, or any non-English text; output only the final English prompt.",
		);

		const parts: any[] = [];
		if (systemPrompt) {
			parts.push({ type: "text", text: systemPrompt });
		}
		parts.push({ type: "text", text: userPrompt });
		const imageSource = imageData || imageUrl!;
		parts.push({
			type: "image_url",
			image_url: { url: imageSource },
		});

		const messages: OpenAIChatMessageForTask[] = [
			{
				role: "user",
				content: parts,
			},
		];

		const input = convertMessagesToResponsesInput(messages);
		const body = {
			model,
			input,
			max_output_tokens: 800,
			stream: false,
			temperature: 0.2,
		};

		const { parsed, rawBody } = await callOpenAIResponsesForTask(
			c,
			responsesUrl,
			apiKey,
			body,
		);

		const rawText =
			extractTextFromOpenAIResponseForTask(parsed) ||
			(typeof rawBody === "string" ? rawBody.trim() : "");

		const text = normalizeImagePromptOutputForTask(rawText);

		const id =
			(typeof parsed?.id === "string" && parsed.id.trim()) ||
			`openai-img-${Date.now().toString(36)}`;

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: "image_to_prompt",
			status: "succeeded",
			assets: [],
			raw: {
				provider: "openai",
				model,
				response: parsed,
				rawBody,
				text,
				imageSource,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

// ---- Gemini / Banana 文案 ----

async function runGeminiTextTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const ctx = await resolveVendorContext(c, userId, "gemini");
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 Gemini API Key", {
			status: 400,
			code: "gemini_api_key_missing",
		});
	}

	const base = normalizeBaseUrl(ctx.baseUrl) ||
		"https://generativelanguage.googleapis.com";
	const extras = (req.extras || {}) as Record<string, any>;
	const modelKey =
		pickModelKey(req, { modelKey: undefined }) || "models/gemini-2.5-flash";
	const model = modelKey.startsWith("models/")
		? modelKey
		: `models/${modelKey}`;
	const modelId = model.startsWith("models/") ? model.slice(7) : model;
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: modelId,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "gemini",
		modelKey: modelId,
	});

	try {
		const systemPrompt =
			req.kind === "prompt_refine"
				? pickSystemPrompt(
						req,
						"你是一个提示词修订助手。请在保持原意的前提下优化并返回脚本正文。",
					)
				: pickSystemPrompt(req, "请用中文回答。");

		const contents: any[] = [];
		if (systemPrompt) {
			contents.push({
				role: "user",
				parts: [{ text: systemPrompt }],
			});
		}
		contents.push({
			role: "user",
			parts: [{ text: req.prompt }],
		});

	const endpointBase = `${base.replace(/\/+$/, "")}/v1beta/${model}:generateContent`;
	const url =
		ctx.viaProxyVendor === "comfly"
			? endpointBase
			: `${endpointBase}?key=${encodeURIComponent(apiKey)}`;

	const data = await callJsonApi(
		c,
		url,
		{
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...(ctx.viaProxyVendor === "comfly"
					? { Authorization: `Bearer ${apiKey}` }
					: {}),
			},
			body: JSON.stringify({ contents }),
		},
		{ provider: "gemini" },
	);

	const firstCandidate = Array.isArray(data?.candidates)
		? data.candidates[0]
		: null;
	const parts = Array.isArray(firstCandidate?.content?.parts)
		? firstCandidate.content.parts
		: [];
	const text = parts
		.map((p: any) =>
			typeof p?.text === "string" ? p.text : "",
		)
		.join("")
		.trim();

	const id = `gemini-${Date.now().toString(36)}`;
	const vendorForLog = (() => {
		const raw = (modelId || "").trim();
		if (!raw) return "gemini";
		return raw.toLowerCase().startsWith("gemini-") ? raw : `gemini-${raw}`;
	})();

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status: "succeeded",
			assets: [],
			raw: {
			provider: "gemini",
			vendor: vendorForLog,
			model: modelId,
			response: data,
			text,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

// ---- Gemini / Banana 图像（text_to_image / image_edit） ----

const BANANA_MODELS = new Set([
	"nano-banana",
	"nano-banana-fast",
	"nano-banana-pro",
]);

function normalizeBananaModelKey(modelKey?: string | null): string | null {
	if (!modelKey) return null;
	const trimmed = modelKey.trim();
	if (!trimmed) return null;
	const raw = trimmed.startsWith("models/") ? trimmed.slice(7) : trimmed;
	const normalized = raw.trim().toLowerCase();
	if (!normalized) return null;
	// Backward compatibility: "nanobanana-fast" -> "nano-banana-fast"
	if (normalized === "nanobanana") return "nano-banana";
	if (normalized.startsWith("nanobanana-")) {
		return `nano-banana-${normalized.slice("nanobanana-".length)}`;
	}
	return normalized;
}

function mapBananaModelToApimartModelKey(model: string): string {
	const m = (model || "").trim().toLowerCase();
	if (m === "nano-banana-pro") return "gemini-3-pro-image-preview";
	return "gemini-2.5-flash-image-preview";
}

function parseBananaSseEvents(raw: string): any[] {
	if (!raw || typeof raw !== "string") return [];
	const normalized = raw.replace(/\r/g, "");
	const chunks = normalized.split(/\n\n+/);
	const events: any[] = [];
	for (const chunk of chunks) {
		const trimmedChunk = chunk.trim();
		if (!trimmedChunk) continue;
		const lines = trimmedChunk.split("\n");
		for (const line of lines) {
			const match = line.match(/^\s*data:\s*(.+)$/i);
			if (!match) continue;
			const payload = match[1].trim();
			if (!payload || payload === "[DONE]") continue;
			try {
				events.push(JSON.parse(payload));
			} catch {
				// ignore malformed lines
			}
		}
	}
	return events;
}

function normalizeBananaResponse(data: any): {
	payload: any;
	events: any[];
	raw: any;
} {
	if (data === null || data === undefined) {
		return { payload: null, events: [], raw: data };
	}

	const tryParseJson = (value: string) => {
		try {
			return JSON.parse(value);
		} catch {
			return null;
		}
	};

	if (typeof data === "string") {
		const events = parseBananaSseEvents(data);
		if (events.length) {
			return { payload: events[events.length - 1], events, raw: data };
		}
		const parsed = tryParseJson(data);
		return { payload: parsed, events: [], raw: data };
	}

	if (typeof data === "object") {
		if (typeof data.data === "string") {
			const events = parseBananaSseEvents(data.data);
			if (events.length) {
				return {
					payload: events[events.length - 1],
					events,
					raw: data.data,
				};
			}
			const parsed = tryParseJson(data.data);
			return { payload: parsed, events: [], raw: data.data };
		}
		if (data.data && typeof data.data === "object") {
			return { payload: data.data, events: [], raw: data };
		}
	}

	return { payload: data, events: [], raw: data };
}

	function extractBananaImageUrls(payload: any): string[] {
		if (!payload || typeof payload !== "object") return [];
		const urls = new Set<string>();
		const enqueue = (value: any) => {
			if (!value) return;
		const arr = Array.isArray(value) ? value : [value];
		for (const item of arr) {
			const candidate = (() => {
				if (!item) return null;
				if (typeof item === "string") return item.trim();
				if (typeof item !== "object") return null;
				const urlKeys = [
					"url",
					"uri",
					"href",
					"imageUrl",
					"image_url",
					"image",
					"image_path",
					"path",
					"resultUrl",
					"result_url",
					"fileUrl",
					"file_url",
					"cdn",
				];
				for (const key of urlKeys) {
					const val = (item as any)[key];
					if (typeof val === "string" && val.trim()) {
						return val.trim();
					}
				}
				const base64Keys = ["base64", "b64_json", "image_base64"];
				for (const key of base64Keys) {
					const val = (item as any)[key];
					if (typeof val === "string" && val.trim()) {
						return `data:image/png;base64,${val.trim()}`;
					}
				}
				return null;
			})();
			if (candidate) {
				urls.add(candidate);
			}
		}
	};

		const candidates = [
			// OpenAI/DALL·E-compatible shapes: { data: [{ url | b64_json }] }
			payload?.data,
			payload?.results,
			payload?.images,
			payload?.imageUrls,
			payload?.image_urls,
			payload?.image_paths,
			payload?.outputs,
			payload?.output?.data,
			payload?.output?.results,
			payload?.output?.images,
			payload?.output?.imageUrls,
			payload?.output?.image_urls,
		];
		candidates.forEach(enqueue);

	enqueue(payload);
	enqueue(payload?.output);

	const directValues = [
		payload?.url,
		payload?.imageUrl,
		payload?.image_url,
		payload?.resultUrl,
		payload?.result_url,
		payload?.fileUrl,
		payload?.file_url,
	];
	directValues.forEach((value) => {
		if (typeof value === "string" && value.trim()) {
			urls.add(value.trim());
		}
	});

	return Array.from(urls);
}

async function runGeminiBananaImageTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const ctx = await resolveVendorContext(c, userId, "gemini");
	const baseUrl =
		normalizeBaseUrl(ctx.baseUrl) || "https://api.grsai.com";
	const isApimartBase =
		isApimartBaseUrl(baseUrl) || ctx.viaProxyVendor === "apimart";
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError(
			isApimartBase ? "未配置 apimart API Key" : "未配置 grsai API Key",
			{
				status: 400,
				code: "banana_api_key_missing",
			},
		);
	}

	const extras = (req.extras || {}) as Record<string, any>;
	const modelKeyOverride =
		typeof extras.modelKey === "string" ? extras.modelKey : undefined;
	const normalizedModel =
		normalizeBananaModelKey(modelKeyOverride) ||
		"nano-banana-fast";

	if (!BANANA_MODELS.has(normalizedModel)) {
		throw new AppError("当前模型不支持 Banana 图片接口", {
			status: 400,
			code: "banana_model_not_supported",
		});
	}
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: normalizedModel,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "gemini",
		modelKey: normalizedModel,
	});

	try {
	const endpoint = isApimartBase
		? `${normalizeApimartBaseUrl(baseUrl)}/v1/images/generations`
		: `${baseUrl}/v1/draw/nano-banana`;
	const vendorKeyForLog =
		ctx.viaProxyVendor === "comfly"
			? `comfly-${normalizedModel}`
			: isApimartBase
				? `apimart-${mapBananaModelToApimartModelKey(normalizedModel)}`
				: `grsai-${normalizedModel}`;
	const localTaskId = `banana-${Date.now().toString(36)}-${crypto
		.randomUUID()
		.slice(0, 8)}`;
	{
		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{ kind: "image", taskId: localTaskId, vendor: vendorKeyForLog },
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert image ref failed",
				err?.message || err,
			);
		}
	}
	await recordVendorCallStarted(c, {
		userId,
		vendor: vendorKeyForLog,
		taskId: localTaskId,
		taskKind: req.kind,
	});

	const referenceImages: string[] = Array.isArray(extras.referenceImages)
		? extras.referenceImages
				.map((url: any) =>
					typeof url === "string" ? url.trim() : "",
				)
				.filter((url: string) => url.length > 0)
		: [];

	const aspectRatio =
		typeof extras.aspectRatio === "string" && extras.aspectRatio.trim()
			? extras.aspectRatio.trim()
			: "auto";

		const imageSize =
			typeof extras.imageSize === "string" && extras.imageSize.trim()
				? extras.imageSize.trim()
				: undefined;

		if (ctx.viaProxyVendor === "comfly") {
			const model = normalizeComflyNanoBananaModelKey(normalizedModel);
			const resolvedAspect = (() => {
				const raw =
					typeof aspectRatio === "string" && aspectRatio.trim()
						? aspectRatio.trim()
						: "";
				if (!raw || raw.toLowerCase() === "auto") return null;
				const allowed = new Set([
					"4:3",
					"3:4",
					"16:9",
					"9:16",
					"2:3",
					"3:2",
					"1:1",
					"4:5",
					"5:4",
					"21:9",
				]);
				return allowed.has(raw) ? raw : null;
			})();

			const inputImages = (() => {
				const items: string[] = [];
				for (const ref of referenceImages.slice(0, 4)) {
					if (typeof ref !== "string") continue;
					const trimmed = ref.trim();
					if (!trimmed) continue;
					// Comfly 文档：image 支持 url 或 b64_json（不带 data: 前缀）
					const dataMatch = trimmed.match(/^data:[^;]+;base64,(.+)$/i);
					if (dataMatch) {
						const b64 = (dataMatch[1] || "").trim();
						if (b64) items.push(b64);
						continue;
					}
					items.push(trimmed);
				}
				return items;
			})();

			const body: any = {
				model,
				prompt: req.prompt,
				response_format: "url",
				...(resolvedAspect ? { aspect_ratio: resolvedAspect } : {}),
				...(inputImages.length ? { image: inputImages } : {}),
			};

			// Doc: image_size 仅 nano-banana-2 支持；避免在其它模型上触发严格校验失败。
			if (/^nano-banana-2$/i.test(model)) {
				if (typeof imageSize === "string" && imageSize.trim()) {
					const val = imageSize.trim();
					if (val === "1K" || val === "2K" || val === "4K") {
						body.image_size = val;
					}
				}
				}

				const url = `${baseUrl.replace(/\/+$/, "")}/v1/images/generations`;
				await recordVendorCallPayloads(c, {
					userId,
					vendor: vendorKeyForLog,
					taskId: localTaskId,
					taskKind: req.kind,
					request: { url, body },
				});
				const data = await callJsonApi(
					c,
					url,
					{
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${apiKey}`,
					},
					body: JSON.stringify(body),
				},
					{ provider: "comfly" },
				);
				await recordVendorCallPayloads(c, {
					userId,
					vendor: vendorKeyForLog,
					taskId: localTaskId,
					taskKind: req.kind,
					upstreamResponse: { url, data },
				});

				// Comfly OpenAI/DALL·E 风格返回：优先拿 url，若返回 b64_json 则上传到 R2。
				const resolvedUrls: string[] = [];
			const extracted = extractBananaImageUrls(data);
			for (const item of extracted.slice(0, 4)) {
				const raw = typeof item === "string" ? item.trim() : "";
				if (!raw) continue;

				const dataMatch = raw.match(/^data:([^;]+);base64,(.+)$/i);
				if (dataMatch) {
					const mimeType = (dataMatch[1] || "").trim() || "image/png";
					const b64 = (dataMatch[2] || "").trim();
					if (!b64) continue;
					// eslint-disable-next-line no-await-in-loop
					const hosted = await uploadInlineImageToR2({
						c,
						userId,
						mimeType,
						base64: b64,
						prefix: "gen/images",
					});
					resolvedUrls.push(hosted);
					continue;
				}

				// Handle possibly-relative urls.
				if (raw.startsWith("/")) {
					resolvedUrls.push(`${baseUrl.replace(/\/+$/, "")}${raw}`);
					continue;
				}
				if (raw.startsWith("//")) {
					resolvedUrls.push(`https:${raw}`);
					continue;
				}
				resolvedUrls.push(raw);
			}

			const assets = resolvedUrls.map((url) =>
				TaskAssetSchema.parse({ type: "image", url, thumbnailUrl: null }),
			);

			const result = TaskResultSchema.parse({
				id: localTaskId,
				kind: req.kind,
				status: assets.length ? "succeeded" : "failed",
				assets,
				raw: {
					provider: "comfly",
					vendor: vendorKeyForLog,
					model,
					request: body,
					response: data ?? null,
				},
			});
			await bindReservationToTaskId(c, userId, reservation, localTaskId);
			return result;
		}

	if (isApimartBase) {
		const model = mapBananaModelToApimartModelKey(normalizedModel);
		const resolvedAspect = (() => {
			const raw =
				typeof aspectRatio === "string" && aspectRatio.trim()
					? aspectRatio.trim()
					: "";
			if (!raw || raw.toLowerCase() === "auto") return null;
			const allowed = new Set([
				"4:3",
				"3:4",
				"16:9",
				"9:16",
				"2:3",
				"3:2",
				"1:1",
				"4:5",
				"5:4",
				"21:9",
			]);
			return allowed.has(raw) ? raw : null;
		})();
		const resolution =
			typeof extras.resolution === "string" && extras.resolution.trim()
				? extras.resolution.trim()
				: typeof (extras as any).imageResolution === "string" &&
						String((extras as any).imageResolution).trim()
					? String((extras as any).imageResolution).trim()
					: null;

			const body: Record<string, any> = {
				model,
				prompt: req.prompt,
				n: 1,
			...(resolvedAspect ? { size: resolvedAspect } : {}),
			...(resolution ? { resolution } : {}),
			...(referenceImages.length
				? { image_urls: referenceImages.slice(0, 14) }
					: {}),
			};

			await recordVendorCallPayloads(c, {
				userId,
				vendor: vendorKeyForLog,
				taskId: localTaskId,
				taskKind: req.kind,
				request: { url: endpoint, body },
			});
			const data = await callJsonApi(
				c,
				endpoint,
				{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
				{ provider: "apimart" },
			);
			await recordVendorCallPayloads(c, {
				userId,
				vendor: vendorKeyForLog,
				taskId: localTaskId,
				taskKind: req.kind,
				upstreamResponse: { url: endpoint, data },
			});

			if (typeof data?.code === "number" && data.code !== 200) {
				throw new AppError(
					(data?.error?.message ||
					data?.message ||
					`apimart 图像生成失败: code ${data.code}`) as string,
				{
					status: 502,
					code: "apimart_request_failed",
					details: { upstreamData: data ?? null, requestBody: body },
				},
			);
		}

		const first = Array.isArray(data?.data) ? data.data[0] : null;
		const upstreamTaskId =
			(typeof first?.task_id === "string" && first.task_id.trim()) ||
			(typeof first?.taskId === "string" && first.taskId.trim()) ||
			null;
		if (!upstreamTaskId) {
			throw new AppError("apimart 未返回 task_id", {
				status: 502,
				code: "apimart_task_id_missing",
				details: { upstreamData: data ?? null, requestBody: body },
			});
		}

		{
			const nowIso = new Date().toISOString();
			try {
				await upsertVendorTaskRef(
					c.env.DB,
					userId,
					{
						kind: "image",
						taskId: localTaskId,
						vendor: vendorKeyForLog,
						pid: upstreamTaskId,
					},
					nowIso,
				);
			} catch (err: any) {
				console.warn(
					"[vendor-task-refs] upsert apimart image pid failed",
					err?.message || err,
				);
			}
		}

		const result = TaskResultSchema.parse({
			id: localTaskId,
			kind: req.kind,
			status: "queued",
			assets: [],
			raw: {
				provider: "apimart",
				vendor: vendorKeyForLog,
				model,
				taskId: localTaskId,
				upstreamTaskId,
				request: body,
				response: data ?? null,
			},
		});
		await bindReservationToTaskId(c, userId, reservation, localTaskId);
		return result;
	}

	const coerceTaskId = (value: any): string | null => {
		if (typeof value === "string" && value.trim()) return value.trim();
		if (typeof value === "number" && Number.isFinite(value)) return String(value);
		return null;
	};
	const extractUpstreamTaskId = (value: any): string | null => {
		if (!value || typeof value !== "object") return null;
		const candidates = [
			(value as any).id,
			(value as any).task_id,
			(value as any).taskId,
			(value as any).request_id,
			(value as any).requestId,
			(value as any).pid,
			(value as any).postId,
			(value as any).post_id,
			(value as any).data?.id,
			(value as any).data?.task_id,
			(value as any).data?.taskId,
			(value as any).data?.request_id,
			(value as any).data?.requestId,
			(value as any).data?.pid,
			(value as any).data?.postId,
			(value as any).data?.post_id,
		];
		for (const candidate of candidates) {
			const coerced = coerceTaskId(candidate);
			if (coerced) return coerced;
		}
		return null;
	};

	// 对齐前端「创建任务 → 轮询结果」协议：返回本地 taskId，上游 taskId 到来后写入 pid 供轮询使用。
	const body: any = {
		model: normalizedModel,
		prompt: req.prompt,
		aspectRatio,
		// 部分实现只会在 SSE 事件中返回 taskId；这里开启进度流以便抓取上游 taskId。
		shutProgress: false,
	};
	if (imageSize) {
		body.imageSize = imageSize;
	}
	if (referenceImages.length) {
		body.urls = referenceImages;
	}
		if (typeof extras.webHook === "string" && extras.webHook.trim()) {
			body.webHook = extras.webHook.trim();
		}

		await recordVendorCallPayloads(c, {
			userId,
			vendor: vendorKeyForLog,
			taskId: localTaskId,
			taskKind: req.kind,
			request: { url: endpoint, body },
		});

		let res: Response;
		let data: any = null;
		try {
			res = await fetchWithHttpDebugLog(
			c,
			endpoint,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "text/event-stream,application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "banana:image" },
		);
	} catch (error: any) {
		throw new AppError("Banana 图像生成请求失败", {
			status: 502,
			code: "banana_request_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	const ct = (res.headers.get("content-type") || "").toLowerCase();
	if (ct.includes("application/json")) {
		try {
			data = await res.json();
		} catch {
			data = null;
		}
	}

	if (!res.ok || (typeof data?.code === "number" && data.code !== 0)) {
		if (!res.ok && data === null) {
			try {
				data = await res.text();
			} catch {
				data = null;
			}
		}
		const normalizedError = normalizeBananaResponse(data);
		const msg =
			(normalizedError.payload &&
				(normalizedError.payload.msg ||
					normalizedError.payload.message ||
					normalizedError.payload.error ||
					normalizedError.payload.error_message)) ||
			(data &&
				(data.msg ||
					data.message ||
					data.error ||
					data.error_message)) ||
			`Banana 图像生成失败: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "banana_request_failed",
			details: {
				upstreamStatus: res.status,
				upstreamData: normalizedError.payload ?? data ?? null,
				upstreamRaw: normalizedError.raw ?? data ?? null,
				upstreamEvents:
					normalizedError.events && normalizedError.events.length
						? normalizedError.events
						: undefined,
			},
		});
		}

		const normalized = normalizeBananaResponse(data);
		await recordVendorCallPayloads(c, {
			userId,
			vendor: vendorKeyForLog,
			taskId: localTaskId,
			taskKind: req.kind,
			upstreamResponse: { url: endpoint, status: res.status, contentType: ct, data: normalized.payload ?? data },
		});
		let upstreamTaskId: string | null = null;
		if (!ct.includes("application/json")) {
			const resolveUpstreamFromSse = async (): Promise<{
			upstreamTaskId: string | null;
			firstEvent: any | null;
		}> => {
			const reader = res.body?.getReader();
			if (!reader) return { upstreamTaskId: null, firstEvent: null };
			const decoder = new TextDecoder();
			let buf = "";
			let bytes = 0;
			const deadline = Date.now() + 15_000;
			const maxBytes = 256 * 1024;
			let firstEvent: any | null = null;
			let found: string | null = null;
			try {
				while (Date.now() < deadline && bytes < maxBytes && !found) {
					const chunk = await reader.read();
					if (chunk.done) break;
					if (chunk.value) {
						bytes += chunk.value.byteLength;
						buf += decoder.decode(chunk.value, { stream: true });
					}
					const lines = buf.split(/\r?\n/);
					buf = lines.pop() || "";
					for (const line of lines) {
						const match = line.match(/^\s*data:\s*(.+)$/i);
						if (!match) continue;
						const payloadText = match[1]?.trim();
						if (!payloadText || payloadText === "[DONE]") continue;
						let eventObj: any = null;
						try {
							eventObj = JSON.parse(payloadText);
						} catch {
							continue;
						}
						if (!firstEvent) firstEvent = eventObj;
						const candidate =
							extractUpstreamTaskId(eventObj) ||
							extractUpstreamTaskId((eventObj as any)?.data) ||
							null;
						if (candidate) {
							found = candidate;
							break;
						}
					}
				}
			} catch (err: any) {
				console.warn(
					"[banana:image] resolve upstream taskId from SSE failed",
					err?.message || err,
				);
			} finally {
				try {
					await reader.cancel();
				} catch {
					// ignore
				}
			}

			if (found) {
				const nowIso = new Date().toISOString();
				try {
					await upsertVendorTaskRef(
						c.env.DB,
						userId,
						{
							kind: "image",
							taskId: localTaskId,
							vendor: vendorKeyForLog,
							pid: found,
						},
						nowIso,
					);
				} catch (err: any) {
					console.warn(
						"[vendor-task-refs] upsert image pid failed",
						err?.message || err,
					);
				}
			}

			return { upstreamTaskId: found, firstEvent };
		};

		const ssePromise = resolveUpstreamFromSse();
		const execCtx = (c as any)?.executionCtx;
		if (execCtx && typeof execCtx.waitUntil === "function") {
			execCtx.waitUntil(ssePromise);
			try {
				const quick = await Promise.race([
					ssePromise,
					new Promise<null>((r) =>
						setTimeout(() => r(null), 250),
					),
				]);
				if (quick && quick.upstreamTaskId) upstreamTaskId = quick.upstreamTaskId;
			} catch {
				// ignore
			}
		} else {
			const resolved = await ssePromise;
			if (resolved.upstreamTaskId) upstreamTaskId = resolved.upstreamTaskId;
		}
	}

	const payload = normalized.payload ?? {};
	if (!upstreamTaskId) {
		upstreamTaskId =
			extractUpstreamTaskId(payload) ||
			extractUpstreamTaskId(data) ||
			null;
		const events = Array.isArray((normalized as any)?.events)
			? ((normalized as any).events as any[])
			: [];
		for (const event of events) {
			if (upstreamTaskId) break;
			upstreamTaskId = extractUpstreamTaskId(event);
		}
	}

	const imageUrls = extractBananaImageUrls(payload);
	const assets = imageUrls.map((url) =>
		TaskAssetSchema.parse({
			type: "image",
			url,
			thumbnailUrl: null,
		}),
	);

	const statusRaw =
		(typeof (payload as any)?.status === "string" &&
			String((payload as any).status).trim()) ||
		(typeof (data as any)?.status === "string" &&
			String((data as any).status).trim()) ||
		"queued";
	let creationStatus = normalizeGrsaiDrawTaskStatus(statusRaw);
	// 创建接口即使返回 succeeded，也统一走轮询以保证耗时统计与前端一致（仅在能轮询时生效）。
	if (upstreamTaskId && creationStatus === "succeeded") {
		creationStatus = "running";
	}
	// 如果上游直接返回图片，则视为已完成（除非明确 failed）。
	if (assets.length > 0 && creationStatus !== "failed") {
		creationStatus = "succeeded";
	}

	const creationProgress = clampProgress(
		typeof (payload as any)?.progress === "number"
			? (payload as any).progress <= 1
				? (payload as any).progress * 100
				: (payload as any).progress
			: typeof (payload as any)?.progress_pct === "number"
				? (payload as any).progress_pct <= 1
					? (payload as any).progress_pct * 100
					: (payload as any).progress_pct
				: undefined,
	);

	if (upstreamTaskId) {
		const nowIso = new Date().toISOString();
		try {
			await upsertVendorTaskRef(
				c.env.DB,
				userId,
				{
					kind: "image",
					taskId: localTaskId,
					vendor: vendorKeyForLog,
					pid: upstreamTaskId,
				},
				nowIso,
			);
		} catch (err: any) {
			console.warn(
				"[vendor-task-refs] upsert image pid failed",
				err?.message || err,
			);
		}
	}

	const waitingUpstreamTaskId =
		!upstreamTaskId &&
		assets.length === 0 &&
		creationStatus !== "failed" &&
		creationStatus !== "succeeded";
	const failureReasonRaw =
		(typeof (payload as any)?.failure_reason === "string" &&
			String((payload as any).failure_reason).trim()) ||
		(typeof (payload as any)?.error === "string" &&
			String((payload as any).error).trim()) ||
		(typeof (payload as any)?.message === "string" &&
			String((payload as any).message).trim()) ||
		(waitingUpstreamTaskId ? "等待上游返回任务 ID" : null);

	const result = TaskResultSchema.parse({
		id: localTaskId,
		kind: req.kind,
		status: creationStatus,
		assets: creationStatus === "succeeded" ? assets : [],
		raw: {
			provider: "gemini",
			vendor: vendorKeyForLog,
			model: normalizedModel,
			taskId: localTaskId,
			upstreamTaskId: upstreamTaskId ?? null,
			status: creationStatus,
			progress: creationProgress ?? null,
			response: payload ?? data,
			failureReason: failureReasonRaw,
			events:
				normalized.events && normalized.events.length
					? normalized.events
					: undefined,
			raw: normalized.raw ?? data,
		},
	});
	await bindReservationToTaskId(c, userId, reservation, localTaskId);
	return result;
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

// ---- Qwen 文生图（简化版） ----

async function runQwenTextToImageTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const ctx = await resolveVendorContext(c, userId, "qwen");
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 Qwen API Key", {
			status: 400,
			code: "qwen_api_key_missing",
		});
	}

	const base =
		normalizeBaseUrl(ctx.baseUrl) || "https://dashscope.aliyuncs.com";

	const model =
		pickModelKey(req, { modelKey: undefined }) || "qwen-image-plus";
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "qwen",
		modelKey: model,
	});

	try {
		const width = req.width || 1328;
		const height = req.height || 1328;

	const body = {
		model,
		input: {
			prompt: req.prompt,
		},
		parameters: {
			size: `${width}*${height}`,
			n: 1,
			prompt_extend: true,
			watermark: true,
		},
	};

	const url = `${base.replace(
		/\/+$/,
		"",
	)}/api/v1/services/aigc/text2image/image-synthesis`;

	const data = await callJsonApi(
		c,
		url,
		{
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`,
				"X-DashScope-Async": "enable",
			},
			body: JSON.stringify(body),
		},
		{ provider: "qwen" },
	);

	const results = Array.isArray(data?.output?.results)
		? data.output.results
		: [];

	const assets = results
		.map((r: any) => {
			const urlVal =
				(typeof r?.url === "string" && r.url.trim()) ||
				(typeof r?.image_url === "string" && r.image_url.trim()) ||
				"";
			if (!urlVal) return null;
			return TaskAssetSchema.parse({
				type: "image",
				url: urlVal,
				thumbnailUrl: null,
			});
		})
		.filter(Boolean) as Array<ReturnType<typeof TaskAssetSchema.parse>>;

	const id =
		(typeof data?.request_id === "string" && data.request_id.trim()) ||
		(typeof data?.output?.task_id === "string" &&
			data.output.task_id.trim()) ||
		`qwen-img-${Date.now().toString(36)}`;

	const status: "succeeded" | "failed" =
		assets.length > 0 ? "succeeded" : "failed";

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: "text_to_image",
			status,
			assets,
			raw: {
				provider: "qwen",
				model,
				response: data,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

// ---- Sora2API 图像（text_to_image / image_edit） ----

	function normalizeSora2ApiImageModelKey(modelKey?: string | null): string {
		const trimmed = (modelKey || "").trim();
		if (!trimmed) return "gemini-2.5-flash-image-landscape";
		const normalized = trimmed.startsWith("models/")
			? trimmed.slice(7)
			: trimmed;

		if (/^nano-banana-pro/i.test(normalized)) return "gemini-3.0-pro-image-landscape";
		if (/^nano-banana/i.test(normalized)) return "gemini-2.5-flash-image-landscape";

		// Sora2API is a unified OpenAI-compatible gateway; accept known image-capable model ids.
		if (
			/^sora-image/i.test(normalized) ||
			/^gemini-.*-image($|-(landscape|portrait)$)/i.test(normalized) ||
			/^imagen-.*($|-(landscape|portrait)$)/i.test(normalized)
		) {
			return normalized;
		}

		return "gemini-2.5-flash-image-landscape";
	}

	async function runSora2ApiImageTask(
		c: AppContext,
		userId: string,
		req: TaskRequestDto,
		progressVendor: string = "sora2api",
	): Promise<TaskResult> {
		const progressCtx = extractProgressContext(req, progressVendor);
		emitProgress(userId, progressCtx, { status: "queued", progress: 0 });

	const ctx = await resolveVendorContext(c, userId, "sora2api");
	const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "http://localhost:8000";
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 sora2api API Key", {
			status: 400,
			code: "sora2api_api_key_missing",
		});
	}

	const extras = (req.extras || {}) as Record<string, any>;
	const modelKeyRaw = typeof extras.modelKey === "string" ? extras.modelKey.trim() : "";
	const defaultGeminiModelKey = (() => {
		const isPortrait = (() => {
			if (typeof req.width === "number" && typeof req.height === "number") return req.height > req.width;
			const ar = typeof extras.aspectRatio === "string" ? extras.aspectRatio.toLowerCase().trim() : "";
			if (ar.includes("portrait")) return true;
			if (ar.includes("landscape")) return false;
			const ratio = ar.match(/(\d+(?:\.\d+)?)\s*[:x\/\*]\s*(\d+(?:\.\d+)?)/);
			if (ratio) {
				const w = Number(ratio[1]);
				const h = Number(ratio[2]);
				if (Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0) return h > w;
			}
			return false;
		})();
		return "gemini-2.5-flash-image-" + (isPortrait ? "portrait" : "landscape");
	})();
	const model = normalizeSora2ApiImageModelKey(modelKeyRaw || defaultGeminiModelKey);
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "sora2api",
		modelKey: model,
	});

	try {
	const promptParts: Array<{ type: string; text?: string; image_url?: { url: string } }> = [
		{ type: "text", text: req.prompt },
	];
	const referenceImages: string[] = Array.isArray(extras.referenceImages)
		? extras.referenceImages
				.map((url: any) =>
					typeof url === "string" ? url.trim() : "",
				)
				.filter((url: string) => url.length > 0)
		: [];
		if (referenceImages.length) {
			// sora2api 兼容 OpenAI chat.completions 的 image_url 内容格式
			const dataUrl = await resolveSora2ApiImageUrl(c, referenceImages[0]!);
			promptParts.push({
				type: "image_url",
				image_url: { url: dataUrl },
			});
		}

	const body: any = {
		model,
		messages: [
			{
				role: "user",
				content: promptParts.length === 1 ? req.prompt : promptParts,
			},
		],
		stream: true,
	};

	emitProgress(userId, progressCtx, { status: "running", progress: 5 });

	let res: Response;
	let rawText = "";
	const url = `${baseUrl.replace(/\/+$/, "")}/v1/chat/completions`;
	try {
		res = await fetchWithHttpDebugLog(
			c,
			url,
			{
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Accept: "text/event-stream,application/json",
					Authorization: `Bearer ${apiKey}`,
				},
				body: JSON.stringify(body),
			},
			{ tag: "sora2api:chatCompletions" },
		);
		rawText = await res.text().catch(() => "");
	} catch (error: any) {
		throw new AppError("sora2api 图片请求失败", {
			status: 502,
			code: "sora2api_request_failed",
			details: { message: error?.message ?? String(error) },
		});
	}

	const ct = (res.headers.get("content-type") || "").toLowerCase();
	const parsedBody = (() => {
		if (ct.includes("application/json")) {
			return safeParseJsonForTask(rawText) || null;
		}
		return parseSseJsonPayloadForTask(rawText) || safeParseJsonForTask(rawText);
	})();

	if (res.status < 200 || res.status >= 300) {
		const msg =
			(parsedBody &&
				(parsedBody.error?.message ||
					parsedBody.message ||
					parsedBody.error)) ||
			`sora2api 图像调用失败: ${res.status}`;
		throw new AppError(msg, {
			status: res.status,
			code: "sora2api_request_failed",
			details: { upstreamStatus: res.status, upstreamData: parsedBody ?? rawText },
		});
	}

	const payload = parsedBody;
	const urls = (() => {
		const collected = new Set<string>();
		extractBananaImageUrls(payload).forEach((url) => collected.add(url));

		const appendFromText = (value: any) => {
			if (!value) return;
			if (typeof value === "string") {
				extractMarkdownImageUrlsFromText(value).forEach((url) =>
					collected.add(url),
				);
				return;
			}
			if (Array.isArray(value)) {
				value.forEach((part) => {
					if (!part) return;
					if (typeof part === "string") {
						extractMarkdownImageUrlsFromText(part).forEach((url) =>
							collected.add(url),
						);
						return;
					}
					if (typeof part === "object" && typeof part.text === "string") {
						extractMarkdownImageUrlsFromText(part.text).forEach((url) =>
							collected.add(url),
						);
					}
				});
			}
		};

		appendFromText(payload?.content);
		if (Array.isArray(payload?.choices)) {
			for (const choice of payload.choices) {
				appendFromText(choice?.delta?.content);
				appendFromText(choice?.message?.content);
				appendFromText(choice?.content);
			}
		}

		// Fallback: parse URLs from the raw SSE buffer when payload-only parsing fails.
		if (collected.size === 0 && typeof rawText === "string" && rawText.trim()) {
			extractMarkdownImageUrlsFromText(rawText).forEach((url) =>
				collected.add(url),
			);
		}

		return Array.from(collected);
	})();
	const assets = urls.map((url) =>
		TaskAssetSchema.parse({ type: "image", url, thumbnailUrl: null }),
	);

	const id =
		(typeof payload?.id === "string" && payload.id.trim()) ||
		`sd-img-${Date.now().toString(36)}`;
	const status: "succeeded" | "failed" = assets.length ? "succeeded" : "failed";
	const vendorForLog = ctx.viaProxyVendor === "grsai" ? "grsai" : "sora2api";
	await recordVendorCallPayloads(c, {
		userId,
		vendor: vendorForLog,
		taskId: id,
		taskKind: req.kind,
		request: { url, body },
		upstreamResponse: { status: res.status, contentType: ct, parsedBody: payload, rawBody: rawText },
	});

	emitProgress(userId, progressCtx, {
		status: status === "succeeded" ? "succeeded" : "failed",
		progress: 100,
		assets,
		raw: { response: payload },
	});

		await bindReservationToTaskId(c, userId, reservation, id);
		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status,
			assets,
			raw: {
				provider: "sora2api",
				vendor: vendorForLog,
				model,
				response: payload,
				rawBody: rawText,
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
	}

	async function runSora2ApiChatCompletionsVideoTask(
		c: AppContext,
		userId: string,
		req: TaskRequestDto,
		options: { model: string; progressVendor: string },
	): Promise<TaskResult> {
		const progressCtx = extractProgressContext(req, options.progressVendor);
		emitProgress(userId, progressCtx, { status: "queued", progress: 0 });

		const ctx = await resolveVendorContext(c, userId, "sora2api");
		const baseUrl = normalizeBaseUrl(ctx.baseUrl) || "http://localhost:8000";
		const apiKey = ctx.apiKey.trim();
		if (!apiKey) {
			throw new AppError("未配置 sora2api API Key", {
				status: 400,
				code: "sora2api_api_key_missing",
			});
		}

		const extras = (req.extras || {}) as Record<string, any>;
		const model = options.model;

		const firstFrameUrl =
			typeof extras.firstFrameUrl === "string" && extras.firstFrameUrl.trim()
				? extras.firstFrameUrl.trim()
				: undefined;
		const lastFrameUrl =
			typeof extras.lastFrameUrl === "string" && extras.lastFrameUrl.trim()
				? extras.lastFrameUrl.trim()
				: undefined;

		const rawUrls: string[] = [];
		const appendUrl = (value: any) => {
			if (typeof value === "string" && value.trim()) rawUrls.push(value.trim());
		};
		if (Array.isArray(extras.referenceImages))
			extras.referenceImages.forEach(appendUrl);
		if (Array.isArray(extras.urls)) extras.urls.forEach(appendUrl);
		const referenceImages = Array.from(new Set(rawUrls)).filter(Boolean);

		const parts: any[] = [{ type: "text", text: req.prompt }];

		// Mode rules (aligned with local sora2api implementation notes):
		// - t2v: ignore images
		// - i2v: must provide 1~2 images (first=START, second=END)
		// - r2v: provide 0~N reference images
		const isI2v = !!firstFrameUrl;
		if (isI2v) {
			const startDataUrl = await resolveSora2ApiImageUrl(c, firstFrameUrl!);
			parts.push({ type: "image_url", image_url: { url: startDataUrl } });
			if (lastFrameUrl) {
				const endDataUrl = await resolveSora2ApiImageUrl(c, lastFrameUrl);
				parts.push({ type: "image_url", image_url: { url: endDataUrl } });
			}
		} else if (referenceImages.length) {
			for (const url of referenceImages.slice(0, 8)) {
				const dataUrl = await resolveSora2ApiImageUrl(c, url);
				parts.push({ type: "image_url", image_url: { url: dataUrl } });
			}
		}

		const body: any = {
			model,
			messages: [
				{
					role: "user",
					content: parts.length === 1 ? req.prompt : parts,
				},
			],
			stream: true,
		};

		emitProgress(userId, progressCtx, { status: "running", progress: 5 });

		let res: Response;
		let rawText = "";
		try {
			res = await fetchWithHttpDebugLog(
				c,
				`${baseUrl.replace(/\/+$/, "")}/v1/chat/completions`,
				{
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Accept: "text/event-stream,application/json",
						Authorization: `Bearer ${apiKey}`,
					},
					body: JSON.stringify(body),
				},
				{ tag: "sora2api:chatCompletions" },
			);
			rawText = await res.text().catch(() => "");
		} catch (error: any) {
			throw new AppError("sora2api 视频请求失败", {
				status: 502,
				code: "sora2api_request_failed",
				details: { message: error?.message ?? String(error) },
			});
		}

		const ct = (res.headers.get("content-type") || "").toLowerCase();
		const parsedBody = (() => {
			if (ct.includes("application/json")) {
				return safeParseJsonForTask(rawText) || null;
			}
			return parseSseJsonPayloadForTask(rawText) || safeParseJsonForTask(rawText);
		})();

		if (res.status < 200 || res.status >= 300) {
			const msg =
				(parsedBody &&
					(parsedBody.error?.message ||
						parsedBody.message ||
						parsedBody.error)) ||
				`sora2api 视频调用失败: ${res.status}`;
			throw new AppError(msg, {
				status: res.status,
				code: "sora2api_request_failed",
				details: { upstreamStatus: res.status, upstreamData: parsedBody ?? rawText },
			});
		}

		const payload = parsedBody;
		const urls = (() => {
			const collected = new Set<string>();

			const appendFromText = (value: any) => {
				if (!value) return;
				if (typeof value === "string") {
					extractHtmlVideoUrlsFromText(value).forEach((url) =>
						collected.add(url),
					);
					extractMarkdownLinkUrlsFromText(value)
						.filter(looksLikeVideoUrl)
						.forEach((url) => collected.add(url));
					return;
				}
				if (Array.isArray(value)) {
					value.forEach((part) => {
						if (!part) return;
						if (typeof part === "string") {
							extractHtmlVideoUrlsFromText(part).forEach((url) =>
								collected.add(url),
							);
							extractMarkdownLinkUrlsFromText(part)
								.filter(looksLikeVideoUrl)
								.forEach((url) => collected.add(url));
							return;
						}
						if (typeof part === "object" && typeof part.text === "string") {
							extractHtmlVideoUrlsFromText(part.text).forEach((url) =>
								collected.add(url),
							);
							extractMarkdownLinkUrlsFromText(part.text)
								.filter(looksLikeVideoUrl)
								.forEach((url) => collected.add(url));
						}
					});
				}
			};

			appendFromText(payload?.content);
			if (Array.isArray(payload?.choices)) {
				for (const choice of payload.choices) {
					appendFromText(choice?.delta?.content);
					appendFromText(choice?.message?.content);
					appendFromText(choice?.content);
				}
			}

			if (collected.size === 0 && typeof rawText === "string" && rawText.trim()) {
				extractHtmlVideoUrlsFromText(rawText).forEach((url) =>
					collected.add(url),
				);
				extractMarkdownLinkUrlsFromText(rawText)
					.filter(looksLikeVideoUrl)
					.forEach((url) => collected.add(url));
			}

			return Array.from(collected);
		})();

		const assets = urls.map((url) =>
			TaskAssetSchema.parse({ type: "video", url, thumbnailUrl: null }),
		);

		const id =
			(typeof payload?.id === "string" && payload.id.trim()) ||
			`veo-${Date.now().toString(36)}`;
		const status: "succeeded" | "failed" = assets.length ? "succeeded" : "failed";

		emitProgress(userId, progressCtx, {
			status,
			progress: 100,
			assets,
			raw: { response: payload },
		});

		return TaskResultSchema.parse({
			id,
			kind: "text_to_video",
			status,
			assets,
			raw: {
				provider: "sora2api",
				model,
				response: payload,
				rawBody: rawText,
			},
		});
	}

	// ---- Anthropic 文案（仅 chat/prompt_refine） ----

async function runAnthropicTextTask(
	c: AppContext,
	userId: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const ctx = await resolveVendorContext(c, userId, "anthropic");
	const apiKey = ctx.apiKey.trim();
	if (!apiKey) {
		throw new AppError("未配置 Anthropic API Key", {
			status: 400,
			code: "anthropic_api_key_missing",
		});
	}

	const base =
		normalizeBaseUrl(ctx.baseUrl) || "https://api.anthropic.com/v1";
	const model =
		pickModelKey(req, { modelKey: undefined }) ||
		"claude-3.5-sonnet-latest";
	const required = await resolveTeamCreditsCostForTask(c, {
		taskKind: req.kind,
		modelKey: model,
	});
	const reservation = await requireSufficientTeamCredits(c, userId, {
		required,
		taskKind: req.kind,
		vendor: "anthropic",
		modelKey: model,
	});

	try {
		const systemPrompt =
			req.kind === "prompt_refine"
				? pickSystemPrompt(
						req,
						"你是一个提示词修订助手。请在保持原意的前提下优化并返回脚本正文。",
					)
				: pickSystemPrompt(req, "请用中文回答。");

		const messages = [
			{
				role: "user",
				content: req.prompt,
			},
		];

		const body: any = {
			model,
			max_tokens: 4096,
			messages,
		};
		if (systemPrompt) {
			body.system = systemPrompt;
		}

	const url = /\/v\d+\/messages$/i.test(base)
		? base
		: `${base.replace(/\/+$/, "")}/messages`;

	const data = await callJsonApi(
		c,
		url,
		{
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`,
				"anthropic-version": "2023-06-01",
			},
			body: JSON.stringify(body),
		},
		{ provider: "anthropic" },
	);

	const parts = Array.isArray(data?.content)
		? data.content
		: [];
	const text = parts
		.map((p: any) =>
			typeof p?.text === "string" ? p.text : "",
		)
		.join("\n")
		.trim();

	const id =
		(typeof data?.id === "string" && data.id.trim()) ||
		`anth-${Date.now().toString(36)}`;

		await bindReservationToTaskId(c, userId, reservation, id);

		return TaskResultSchema.parse({
			id,
			kind: req.kind,
			status: "succeeded",
			assets: [],
			raw: {
			provider: "anthropic",
			model,
			response: data,
			text: text || "Anthropic 调用成功",
			},
		});
	} catch (err) {
		return await releaseReservationOnThrow(c, userId, reservation, err);
	}
}

export async function runGenericTaskForVendor(
	c: AppContext,
	userId: string,
	vendor: string,
	req: TaskRequestDto,
): Promise<TaskResult> {
	const v = normalizeVendorKey(vendor);
	const progressCtx = extractProgressContext(req, v);
	const startedAtMs = Date.now();

	// 所有厂商统一：/tasks 视为“创建任务”，立即发出 queued/running 事件
	emitProgress(userId, progressCtx, { status: "queued", progress: 0 });

	try {
		emitProgress(userId, progressCtx, {
			status: "running",
			progress: 5,
		});

		let result: TaskResult;

		if (v === "openai") {
			if (req.kind === "image_to_prompt") {
				result = await runOpenAiImageToPromptTask(c, userId, req);
			} else if (req.kind === "text_to_image" || req.kind === "image_edit") {
				// OpenAI 文生图在 Worker 侧通过 Gemini Banana / sora2api 代理实现
				throw new AppError(
					"OpenAI 目前仅支持 chat/prompt_refine/image_to_prompt",
					{ status: 400, code: "unsupported_task_kind" },
				);
			} else if (
				req.kind === "chat" ||
				req.kind === "prompt_refine"
			) {
				result = await runOpenAiTextTask(c, userId, req);
			} else {
				throw new AppError(
					"OpenAI 仅支持 chat/prompt_refine/image_to_prompt",
					{
						status: 400,
						code: "unsupported_task_kind",
					},
				);
			}
		} else if (v === "gemini") {
			if (req.kind === "text_to_image" || req.kind === "image_edit") {
				result = await runGeminiBananaImageTask(c, userId, req);
			} else if (req.kind === "chat" || req.kind === "prompt_refine") {
				result = await runGeminiTextTask(c, userId, req);
			} else {
				throw new AppError(
					"Gemini 目前仅在 Worker 中支持文案任务与 Banana 图像任务",
					{
						status: 400,
						code: "unsupported_task_kind",
					},
				);
			}
		} else if (v === "qwen") {
			if (req.kind === "text_to_image") {
				result = await runQwenTextToImageTask(c, userId, req);
			} else {
				throw new AppError(
					"Qwen 目前仅在 Worker 中支持 text_to_image",
					{
						status: 400,
						code: "unsupported_task_kind",
					},
				);
			}
		} else if (v === "sora2api") {
			if (req.kind === "text_to_image" || req.kind === "image_edit") {
				result = await runSora2ApiImageTask(c, userId, req);
			} else {
				throw new AppError(
					"sora2api 目前仅在 Worker 中支持 text_to_image/image_edit 或 text_to_video",
					{ status: 400, code: "unsupported_task_kind" },
				);
			}
		} else if (v === "anthropic") {
			if (req.kind === "chat" || req.kind === "prompt_refine") {
				result = await runAnthropicTextTask(c, userId, req);
			} else {
				throw new AppError(
					"Anthropic 目前仅在 Worker 中支持文案任务",
					{
						status: 400,
						code: "unsupported_task_kind",
					},
				);
			}
		} else {
			if (req.kind === "chat" || req.kind === "prompt_refine") {
				const nonTextVendors = new Set([
					"apimart",
					"veo",
					"sora2api",
					"qwen",
					"minimax",
					"grsai",
					"comfly",
					"yunwu",
				]);
				if (nonTextVendors.has(v)) {
					throw new AppError(`Unsupported vendor: ${vendor}`, {
						status: 400,
						code: "unsupported_vendor",
					});
				}
				result = await runOpenAiCompatibleTextTaskForVendor(c, userId, v, req);
			} else if (req.kind === "text_to_image" || req.kind === "image_edit") {
				result = await runOpenAiCompatibleImageTaskForVendor(c, userId, v, req);
			} else if (req.kind === "text_to_video" || req.kind === "image_to_video") {
				if (v === "tuzi") {
					result = await runTuziVideoTask(c, userId, req);
				} else {
					result = await runOpenAiCompatibleVideoTaskForVendor(c, userId, v, req);
				}
			} else {
				throw new AppError(`Unsupported vendor: ${vendor}`, {
					status: 400,
					code: "unsupported_vendor",
				});
			}
		}

		const apiVendor = pickApiVendorForTask(result, v);
		const persistAssets =
			typeof (req.extras as any)?.persistAssets === "boolean"
				? (req.extras as any).persistAssets
				: true;

		if (result.status === "succeeded" && result.assets && result.assets.length > 0) {
			// 将生成结果写入 assets（默认托管到 OSS/R2 并替换 URL；ASSET_HOSTING_DISABLED=1 时保持源 URL）
			try {
				const hostedAssets = await hostTaskAssetsInWorker({
					c,
					userId,
					assets: result.assets,
					meta: {
						taskKind: req.kind,
						prompt: req.prompt,
						vendor: apiVendor,
						modelKey:
							(typeof (req.extras as any)?.modelKey === "string" &&
								(req.extras as any).modelKey) ||
							undefined,
						taskId:
							(typeof result.id === "string" && result.id.trim()) ||
							null,
					},
				});
				result = TaskResultSchema.parse({
					...result,
					assets: hostedAssets,
				});
			} catch (err: any) {
				// Hosting failed: do not charge; keep reserved and allow clients to retry polling.
				const message =
					typeof err?.message === "string" && err.message.trim()
						? err.message.trim()
						: "OSS 托管失败，稍后自动重试";
				result = TaskResultSchema.parse({
					...result,
					status: "running",
					raw: {
						...(result.raw as any),
						hosting: { status: "pending", message },
						persistAssets,
					},
				});
				emitProgress(userId, progressCtx, {
					status: "running",
					progress: 95,
					message: `托管中：${message}`,
					taskId: result.id,
				});
			}
		}

		// 统一发出完成事件，便于前端通过 /tasks/stream 或 /tasks/pending 聚合观察
			emitProgress(userId, progressCtx, {
				status: result.status,
				progress: result.status === "succeeded" ? 100 : undefined,
				taskId: result.id,
				assets: result.assets,
				raw: result.raw,
			});

			await recordVendorCallPayloads(c, {
				userId,
				vendor: apiVendor,
				taskId: result.id,
				taskKind: req.kind,
				request: { vendor: v, request: req },
				upstreamResponse: { status: result.status, raw: result.raw },
			});

			await recordVendorCallFromTaskResult(c, {
				userId,
				vendor: apiVendor,
				taskKind: req.kind,
			result,
			durationMs: Date.now() - startedAtMs,
		});

		return result;
	} catch (err: any) {
		// 失败时也发一条 failed snapshot，方便前端统一处理
		const message =
			typeof err?.message === "string"
				? err.message
				: "任务执行失败";
		emitProgress(userId, progressCtx, {
			status: "failed",
			progress: 0,
			message,
		});
		throw err;
	}
}
